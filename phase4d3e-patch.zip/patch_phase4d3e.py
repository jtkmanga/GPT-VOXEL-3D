from pathlib import Path
import shutil, time

root = Path('.')
server = root / 'vps' / 'game-server.js'
html = root / 'index.vps-test-v2.html'

for p in (server, html):
    if not p.exists():
        raise SystemExit(f'ERROR: missing {p}')

stamp = time.strftime('%Y%m%d-%H%M%S')
shutil.copy2(server, root / 'vps' / f'game-server.before-phase4d3e.{stamp}.js')
shutil.copy2(html, root / f'index.vps-test-v2.before-phase4d3e.{stamp}.html')

s = server.read_text()
if 'function sendVisibilitySnapshot(' not in s:
    marker = "function reconcileZoneVisibility(\n"
    helper = """function sendVisibilitySnapshot(\n  server,\n  sourcePlayer,\n  reason = 'sync'\n) {\n  if (!sourcePlayer?.authenticated) return;\n\n  send(sourcePlayer.ws, {\n    type: 'visibility_snapshot',\n    zone: sourcePlayer.zoneId,\n    reason,\n    players: visiblePlayersFor(\n      server,\n      sourcePlayer\n    ),\n    count: server.players.size\n  });\n}\n\n"""
    if marker not in s: raise SystemExit('ERROR: server visibility marker not found')
    s = s.replace(marker, helper + marker, 1)

if '// Phase 4D.3E: VPS uses one socket' not in s:
    old = """      registerPlayerZone(\n        gameServer,\n        player,\n        nextZoneId\n      );\n\n      reconcileZoneVisibility(\n        gameServer,\n        player,\n        previousZoneId,\n        nextZoneId\n      );\n\n      broadcastNearby(\n"""
    new = """      registerPlayerZone(\n        gameServer,\n        player,\n        nextZoneId\n      );\n\n      reconcileZoneVisibility(\n        gameServer,\n        player,\n        previousZoneId,\n        nextZoneId\n      );\n\n      if (\n        previousZoneId &&\n        nextZoneId !== previousZoneId\n      ) {\n        // Phase 4D.3E: VPS uses one socket for the whole session.\n        // Tell the client which server-authoritative Zone it is now in,\n        // then send a compact nearby snapshot to heal any brief join/leave race.\n        send(ws, {\n          type: 'zone_change',\n          fromZone: previousZoneId,\n          toZone: nextZoneId,\n          zone: nextZoneId\n        });\n\n        sendVisibilitySnapshot(\n          gameServer,\n          player,\n          'zone_change'\n        );\n      }\n\n      broadcastNearby(\n"""
    if old not in s: raise SystemExit('ERROR: server move marker not found')
    s = s.replace(old,new,1)
server.write_text(s)

h = html.read_text()
if 'secureRemoteLeaveTimers' not in h:
    old = """        const secureRemoteSources = new Map();\n        const secureGhostMembersByZone = new Map();\n"""
    new = """        const secureRemoteSources = new Map();\n        const secureGhostMembersByZone = new Map();\n        const secureRemoteLeaveTimers = new Map();\n        const SECURE_REMOTE_LEAVE_GRACE_MS = 900;\n"""
    if old not in h: raise SystemExit('ERROR: client declarations marker not found')
    h = h.replace(old,new,1)

if 'secureRemoteLeaveTimers.forEach' not in h:
    old = """        function secureClearRemoteState() {\n            secureRemoteSources.clear();\n            secureGhostMembersByZone.clear();\n            removeAllOtherPlayers();\n        }\n"""
    new = """        function secureClearRemoteState() {\n            secureRemoteLeaveTimers.forEach(timer => clearTimeout(timer));\n            secureRemoteLeaveTimers.clear();\n            secureRemoteSources.clear();\n            secureGhostMembersByZone.clear();\n            removeAllOtherPlayers();\n        }\n"""
    if old not in h: raise SystemExit('ERROR: clear remote marker not found')
    h = h.replace(old,new,1)

if 'const pendingLeave = secureRemoteLeaveTimers.get(id);' not in h:
    old = """        function secureTrackRemotePlayer(id, sourceKey, rawPlayer) {\n            id = String(id || '');\n            if (!id || id === state.serverPlayerId) return;\n            const p = secureNormalizePlayer(rawPlayer);\n"""
    new = """        function secureTrackRemotePlayer(id, sourceKey, rawPlayer) {\n            id = String(id || '');\n            if (!id || id === state.serverPlayerId) return;\n\n            const pendingLeave = secureRemoteLeaveTimers.get(id);\n            if (pendingLeave) {\n                clearTimeout(pendingLeave);\n                secureRemoteLeaveTimers.delete(id);\n            }\n\n            const p = secureNormalizePlayer(rawPlayer);\n"""
    if old not in h: raise SystemExit('ERROR: remote track marker not found')
    h = h.replace(old,new,1)

if 'function secureApplyVisibilitySnapshot' not in h:
    marker = "        function secureReplaceGhostSnapshot(message) {\n"
    insert = """        function secureScheduleRemoteLeave(\n            id,\n            sourceKey = 'local',\n            delayMs = SECURE_REMOTE_LEAVE_GRACE_MS\n        ) {\n            id = String(id || '');\n            if (!id) return;\n\n            const existing = secureRemoteLeaveTimers.get(id);\n            if (existing) clearTimeout(existing);\n\n            const timer = setTimeout(() => {\n                secureRemoteLeaveTimers.delete(id);\n                secureUntrackRemotePlayer(id, sourceKey);\n            }, Math.max(0, Number(delayMs) || 0));\n\n            secureRemoteLeaveTimers.set(id, timer);\n        }\n\n        function secureApplyVisibilitySnapshot(message) {\n            const zoneId = secureNormalizeZoneId(message?.zone);\n            if (zoneId) secureCurrentZoneId = zoneId;\n\n            const nextVisible = new Set();\n            (Array.isArray(message?.players) ? message.players : []).forEach(raw => {\n                const p = secureNormalizePlayer(raw);\n                if (!p.id || p.id === state.serverPlayerId) return;\n                nextVisible.add(p.id);\n                secureTrackRemotePlayer(p.id, 'local', p);\n            });\n\n            for (const [id, sources] of secureRemoteSources.entries()) {\n                if (sources.has('local') && !nextVisible.has(id)) {\n                    secureScheduleRemoteLeave(id, 'local');\n                }\n            }\n        }\n\n"""
    if marker not in h: raise SystemExit('ERROR: visibility snapshot marker not found')
    h = h.replace(marker, insert + marker, 1)

if "case 'visibility_snapshot':" not in h:
    old = """                case 'leave':\n                    if (message.id) secureUntrackRemotePlayer(String(message.id), 'local');\n                    break;\n                case 'ghost_snapshot':\n"""
    new = """                case 'leave':\n                    // Do not remove the model immediately at a Zone boundary.\n                    // If a join/move follows during the short grace window,\n                    // secureTrackRemotePlayer() cancels this pending removal.\n                    if (message.id) secureScheduleRemoteLeave(String(message.id), 'local');\n                    break;\n                case 'visibility_snapshot':\n                    secureApplyVisibilitySnapshot(message);\n                    break;\n                case 'ghost_snapshot':\n"""
    if old not in h: raise SystemExit('ERROR: leave case marker not found')
    h = h.replace(old,new,1)

if '// VPS keeps one WebSocket across all Zones' not in h:
    old = """            const positionZone = secureZoneFromPosition(playerPos.x, playerPos.z);\n            if (positionZone && positionZone === secureCurrentZoneId) {\n                secureRememberStablePosition();\n            }\n\n            secureGameSocket.send(JSON.stringify({\n"""
    new = """            const positionZone = secureZoneFromPosition(playerPos.x, playerPos.z);\n            if (positionZone) {\n                if (secureUsingVpsBackend()) {\n                    // VPS keeps one WebSocket across all Zones, so local Zone state\n                    // can follow movement immediately while the server independently\n                    // confirms it with zone_change/visibility_snapshot.\n                    secureCurrentZoneId = positionZone;\n                    secureRememberStablePosition();\n                } else if (positionZone === secureCurrentZoneId) {\n                    secureRememberStablePosition();\n                }\n            }\n\n            secureGameSocket.send(JSON.stringify({\n"""
    if old not in h: raise SystemExit('ERROR: position zone marker not found')
    h = h.replace(old,new,1)

html.write_text(h)
print('OK: Phase 4D.3E visibility continuity installed')
print('Backups created with timestamp:', stamp)
