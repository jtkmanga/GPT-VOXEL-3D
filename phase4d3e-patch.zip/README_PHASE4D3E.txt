Phase 4D.3E - VPS Zone visibility continuity

Changes:
1) VPS server sends zone_change + visibility_snapshot after authoritative Zone crossing.
2) Client keeps one VPS WebSocket and updates its Zone state continuously.
3) Client delays remote leave by 900 ms; a join/move cancels pending removal.
4) Visibility snapshot heals brief boundary races without touching score/coins/VIP/login logic.

Recommended apply command from repository root:
  python3 patch_phase4d3e.py

Then validate:
  node --check vps/game-server.js

Run server the same way as before and test two devices standing together 30 seconds, then crossing the same Zone boundary together.
