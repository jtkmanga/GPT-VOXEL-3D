#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import re, sys, shutil

CLIENT = Path("index.vps-test-v2.html")
WORKER = Path("worker.js")
MARKER = "PHASE_4E4G1_SECURE_PAYMENT_QR"

for p in (CLIENT, WORKER):
    if not p.exists():
        raise SystemExit(f"ERROR: missing {p}")

stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
client_backup = CLIENT.with_name(f"{CLIENT.stem}.before-phase4e4g1-fix.{stamp}{CLIENT.suffix}")
worker_backup = WORKER.with_name(f"{WORKER.stem}.before-phase4e4g1-fix.{stamp}{WORKER.suffix}")
shutil.copy2(CLIENT, client_backup)
shutil.copy2(WORKER, worker_backup)

client = CLIENT.read_text(encoding="utf-8", errors="replace")
worker = WORKER.read_text(encoding="utf-8", errors="replace")

if MARKER in client or MARKER in worker:
    print("INFO: Phase 4E.4G1 already appears installed; nothing changed.")
    sys.exit(0)

# ---------- Client ----------
client2 = re.sub(
    r'^\s*const\s+SECURE_PAYMENT_PROMPTPAY_TARGET\s*=\s*["\']0999999999["\'];[^\n]*\n',
    "        // PHASE_4E4G1_SECURE_PAYMENT_QR: receiver stays on Worker only.\n",
    client,
    count=1,
    flags=re.M
)

client2 = re.sub(
    r'^\s*const\s+promptpayTarget\s*=\s*["\']0999999999["\'];[^\n]*\n',
    "            // PHASE_4E4G1_SECURE_PAYMENT_QR: receiver stays on Worker only.\n",
    client2,
    count=1,
    flags=re.M
)

secure_qr_rx = re.compile(
    r'document\.getElementById\([\'"]promptpay-qr-img[\'"]\)\.src\s*=\s*'
    r'`https://promptpay\.io/\$\{SECURE_PAYMENT_PROMPTPAY_TARGET\}/\$\{cfg\.price\}\.png`;'
)
client2, n_secure = secure_qr_rx.subn(
    "document.getElementById('promptpay-qr-img').src = "
    "SECURE_WORKER_HTTP_BASE + '/payment-qr?type=' + encodeURIComponent(type) + '&v=' + Date.now();",
    client2,
    count=1
)

legacy_qr_rx = re.compile(
    r'document\.getElementById\([\'"]promptpay-qr-img[\'"]\)\.src\s*=\s*'
    r'`https://promptpay\.io/\$\{promptpayTarget\}/\$\{price\}\.png`;'
)
client2, _ = legacy_qr_rx.subn(
    "document.getElementById('promptpay-qr-img').src = "
    "SECURE_WORKER_HTTP_BASE + '/payment-qr?type=' + encodeURIComponent(type) + '&v=' + Date.now();",
    client2,
    count=1
)

if n_secure != 1:
    raise SystemExit("ERROR: secure QR line not found exactly once; active files were NOT written.")
if "0999999999" in client2:
    raise SystemExit("ERROR: placeholder still exists in active client candidate; active files were NOT written.")

# ---------- Worker helper ----------
helper = r'''
// PHASE_4E4G1_SECURE_PAYMENT_QR
async function phase4e4g1PaymentQr(request, env) {
  const reqUrl = new URL(request.url);
  const type = String(reqUrl.searchParams.get("type") || "");
  const item = (typeof ITEMS !== "undefined" && ITEMS) ? ITEMS[type] : null;

  if (!item || !Number.isFinite(Number(item.price))) {
    return new Response(JSON.stringify({ ok:false, error:"Invalid payment item" }), {
      status: 400,
      headers: { "Content-Type":"application/json; charset=utf-8", "Cache-Control":"no-store" }
    });
  }

  const receiver = String(
    env.PAYMENT_RECEIVER_ACCOUNT ||
    env.PROMPTPAY_TARGET ||
    ""
  ).trim();

  if (!receiver) {
    console.error("[PAYMENT-QR] receiver env missing");
    return new Response(JSON.stringify({ ok:false, error:"Payment receiver not configured" }), {
      status: 503,
      headers: { "Content-Type":"application/json; charset=utf-8", "Cache-Control":"no-store" }
    });
  }

  const qrUrl =
    "https://promptpay.io/" +
    encodeURIComponent(receiver) + "/" +
    encodeURIComponent(String(Number(item.price))) +
    ".png";

  let upstream;
  try {
    upstream = await fetch(qrUrl, {
      method: "GET",
      headers: { "Accept":"image/png,image/*;q=0.9,*/*;q=0.1" }
    });
  } catch (_) {
    return new Response(JSON.stringify({ ok:false, error:"QR provider unavailable" }), {
      status: 502,
      headers: { "Content-Type":"application/json; charset=utf-8", "Cache-Control":"no-store" }
    });
  }

  if (!upstream.ok) {
    return new Response(JSON.stringify({ ok:false, error:"QR provider rejected request" }), {
      status: 502,
      headers: { "Content-Type":"application/json; charset=utf-8", "Cache-Control":"no-store" }
    });
  }

  const contentType = upstream.headers.get("Content-Type") || "image/png";
  if (!contentType.toLowerCase().startsWith("image/")) {
    return new Response(JSON.stringify({ ok:false, error:"Invalid QR response" }), {
      status: 502,
      headers: { "Content-Type":"application/json; charset=utf-8", "Cache-Control":"no-store" }
    });
  }

  return new Response(upstream.body, {
    status: 200,
    headers: {
      "Content-Type": contentType,
      "Cache-Control":"private, no-store, max-age=0",
      "Pragma":"no-cache",
      "X-Content-Type-Options":"nosniff",
      "Referrer-Policy":"no-referrer"
    }
  });
}

'''

export_pos = worker.find("export default")
if export_pos < 0:
    raise SystemExit("ERROR: export default not found; active files were NOT written.")
worker2 = worker[:export_pos] + helper + worker[export_pos:]

# Put route immediately before first line containing /verify-slip.
lines = worker2.splitlines(True)
verify_line = None
for i, line in enumerate(lines):
    if "/verify-slip" in line:
        verify_line = i
        break

if verify_line is None:
    raise SystemExit("ERROR: /verify-slip route not found; active files were NOT written.")

indent = re.match(r'^(\s*)', lines[verify_line]).group(1)
route = (
    f'{indent}// PHASE_4E4G1_SECURE_PAYMENT_QR\n'
    f'{indent}if (request.method === "GET" && new URL(request.url).pathname === "/payment-qr") {{\n'
    f'{indent}  return phase4e4g1PaymentQr(request, env);\n'
    f'{indent}}}\n\n'
)
lines.insert(verify_line, route)
worker2 = "".join(lines)

if worker2.count("PHASE_4E4G1_SECURE_PAYMENT_QR") < 2:
    raise SystemExit("ERROR: marker sanity check failed; active files were NOT written.")
if '"/payment-qr"' not in worker2:
    raise SystemExit("ERROR: /payment-qr route missing; active files were NOT written.")

CLIENT.write_text(client2, encoding="utf-8")
WORKER.write_text(worker2, encoding="utf-8")

print("OK: Phase 4E.4G1 FIX installed")
print(f"Client backup: {client_backup}")
print(f"Worker backup: {worker_backup}")
print("NEXT:")
print("  node --check worker.js")
print("  grep -n \"0999999999\\|PHASE_4E4G1_SECURE_PAYMENT_QR\\|/payment-qr\" index.vps-test-v2.html worker.js | head -100")
print("  python3 audit_phase4e4g_payment_security.py | tail -80")
