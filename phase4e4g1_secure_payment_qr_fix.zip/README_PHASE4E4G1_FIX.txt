Phase 4E.4G1 FIX

The previous installer stopped safely before writing active files.
This fixed installer does not depend on the Worker's URL variable being named `url`.

Install:

cd /workspaces/GPT-VOXEL-3D
git fetch origin
git checkout origin/main -- phase4e4g1_secure_payment_qr_fix.zip
unzip -o phase4e4g1_secure_payment_qr_fix.zip
python3 patch_phase4e4g1_secure_payment_qr_fix.py

Then validate:

node --check worker.js

grep -n "0999999999\|PHASE_4E4G1_SECURE_PAYMENT_QR\|/payment-qr" \
  index.vps-test-v2.html worker.js | head -100

python3 audit_phase4e4g_payment_security.py | tail -80

Do NOT deploy if node --check reports an error.

If syntax and audit are good:

npx wrangler deploy

Then test:

curl -s -o /tmp/payment-qr.png -w "%{http_code} %{content_type}\n" \
  "https://voxel-run-v2-demo.hjinffv5426.workers.dev/payment-qr?type=speed"

Expected: 200 and image/*

Do not paste receiver account, API secrets, or tokens into chat.
