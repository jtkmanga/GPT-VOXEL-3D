from pathlib import Path
from datetime import datetime

SERVER = Path("vps/game-server.js")
CLIENT = Path("index.vps-test-v2.html")
LUCKY = Path("vps/lucky-box-store.js")

for p in (SERVER, CLIENT, LUCKY):
    if not p.exists():
        raise SystemExit(f"ERROR: ไม่พบ {p}")

server = SERVER.read_text(encoding="utf-8")
client = CLIENT.read_text(encoding="utf-8")
lucky = LUCKY.read_text(encoding="utf-8")

if "PHASE_4E4D_REPLAY_PROTECTION" in server:
    print("INFO: Phase 4E.4D already installed")
    raise SystemExit(0)

if "PHASE_4E4C_PROTOCOL_VALIDATION" not in server:
    raise SystemExit("ERROR: ต้องติดตั้ง Phase 4E.4C ก่อน")

stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
sb = SERVER.with_name(f"game-server.before-phase4e4d.{stamp}.js")
cb = CLIENT.with_name(f"index.vps-test-v2.before-phase4e4d.{stamp}.html")
lb = LUCKY.with_name(f"lucky-box-store.before-phase4e4d.{stamp}.js")
sb.write_text(server, encoding="utf-8")
cb.write_text(client, encoding="utf-8")
lb.write_text(lucky, encoding="utf-8")

anchor = "  if (msg.type === 'collect_box' || msg.type === 'spin_box') {\n"
if anchor not in server:
    raise SystemExit("ERROR: ไม่พบ Lucky Box validator anchor")

meta_validation = '''  if (
    msg.type === 'coin_collect' ||
    msg.type === 'collect_box' ||
    msg.type === 'spin_box'
  ) {
    if (
      typeof msg.actionSession !== 'string' ||
      msg.actionSession.length < 16 ||
      msg.actionSession.length > 96 ||
      !/^[A-Za-z0-9_-]+$/.test(msg.actionSession)
    ) {
      return 'BAD_ACTION_SESSION';
    }

    if (
      !Number.isSafeInteger(msg.actionSeq) ||
      msg.actionSeq < 1 ||
      msg.actionSeq > Number.MAX_SAFE_INTEGER
    ) {
      return 'BAD_ACTION_SEQ';
    }
  }

'''
server = server.replace(anchor, meta_validation + anchor, 1)

marker = "// PHASE_4E4B_PACKET_RATE_LIMIT"
pos = server.find(marker)
if pos < 0:
    raise SystemExit("ERROR: ไม่พบ Phase 4E.4B marker")

helpers = r'''// PHASE_4E4D_REPLAY_PROTECTION
// Side-effect commands receive a server-issued actionSession and strictly
// increasing actionSeq. WebSocket preserves message ordering, so an old or
// duplicated packet cannot be applied twice inside the same session. A new
// connection gets a new actionSession, so captured packets from old sessions
// are rejected too.
const PHASE4E4D_PROTECTED_ACTIONS = new Set([
  'coin_collect',
  'collect_box',
  'spin_box'
]);
const PHASE4E4D_REPLAY_WINDOW_MS = 30000;
const PHASE4E4D_REPLAY_KICK_AFTER = 8;

function phase4e4dStartSession(player) {
  player.actionSession = crypto.randomUUID();
  player.lastActionSeq = 0;
  player.__phase4e4dReplayState = {
    startedAt: Date.now(),
    rejected: 0
  };
}

function phase4e4dReject(ws, player, msg, reason) {
  const now = Date.now();
  let state = player.__phase4e4dReplayState;

  if (
    !state ||
    now - Number(state.startedAt || 0) >= PHASE4E4D_REPLAY_WINDOW_MS
  ) {
    state = { startedAt: now, rejected: 0 };
    player.__phase4e4dReplayState = state;
  }

  state.rejected = Number(state.rejected || 0) + 1;

  console.warn('[ANTI-REPLAY] duplicate/stale action rejected', {
    uid: player?.uid || null,
    nickname: player?.nickname || null,
    action: msg?.type || null,
    reason,
    seq: Number(msg?.actionSeq || 0),
    lastSeq: Number(player?.lastActionSeq || 0),
    rejected: state.rejected
  });

  send(ws, {
    type: 'action_replay_rejected',
    action: String(msg?.type || ''),
    reason,
    actionSeq: Number(msg?.actionSeq || 0),
    serverNow: now
  });

  if (state.rejected >= PHASE4E4D_REPLAY_KICK_AFTER) {
    console.warn('[ANTI-REPLAY] repeated replay attempts - disconnecting', {
      uid: player?.uid || null,
      nickname: player?.nickname || null,
      rejected: state.rejected
    });
    try {
      if (ws?.readyState === WebSocket.OPEN) {
        ws.close(1008, 'Replay protection');
      }
    } catch (_) {}
  }

  return false;
}

function phase4e4dAllowAction(ws, player, msg) {
  if (!PHASE4E4D_PROTECTED_ACTIONS.has(msg?.type)) return true;

  if (
    !player?.actionSession ||
    msg.actionSession !== player.actionSession
  ) {
    return phase4e4dReject(ws, player, msg, 'STALE_SESSION');
  }

  const seq = Number(msg.actionSeq);
  const last = Number(player.lastActionSeq || 0);

  if (seq <= last) {
    return phase4e4dReject(ws, player, msg, 'DUPLICATE_OR_OLD_SEQ');
  }

  // WebSocket is ordered/reliable. A gap therefore means a tampered or
  // fabricated action stream rather than ordinary packet reordering.
  if (seq !== last + 1) {
    return phase4e4dReject(ws, player, msg, 'OUT_OF_ORDER_SEQ');
  }

  player.lastActionSeq = seq;
  return true;
}

'''
server = server[:pos] + helpers + "\n" + server[pos:]

old = '''      player.entitlements = entitlementData.entitlements || {};
      player.vipActive = vipActive;
      player.authenticated = true;

      const score = gameDb.ensurePlayer(
'''
new = '''      player.entitlements = entitlementData.entitlements || {};
      player.vipActive = vipActive;
      player.authenticated = true;
      phase4e4dStartSession(player);

      const score = gameDb.ensurePlayer(
'''
if old not in server:
    raise SystemExit("ERROR: ไม่พบ auth success block")
server = server.replace(old, new, 1)

old = '''        protocol: 4,
        id: player.id,
        nickname: player.nickname,
'''
new = '''        protocol: 4,
        id: player.id,
        nickname: player.nickname,
        actionSession: player.actionSession,
'''
if old not in server:
    raise SystemExit("ERROR: ไม่พบ welcome block")
server = server.replace(old, new, 1)

old = '''      ws.close(1008, 'Authentication expired');
      return;
    }

    if (msg.type === 'coin_collect') {
'''
new = '''      ws.close(1008, 'Authentication expired');
      return;
    }

    if (!phase4e4dAllowAction(ws, player, msg)) return;

    if (msg.type === 'coin_collect') {
'''
if old not in server:
    raise SystemExit("ERROR: ไม่พบ post-auth handler anchor")
server = server.replace(old, new, 1)

old_spin = '''    if (msg.type === 'spin_box') {
      if (!phase4e4bAllowAction(ws, player, 'spin_box')) return;
      const now = Date.now();
      const spinPermission = luckyBoxStore.canSpin(serverId, player.uid, now);

      if (!spinPermission.ok) {
        send(ws, { type: 'box_state', box: spinPermission.box, serverNow: now });
        send(ws, { type: 'box_error', message: spinPermission.reason || 'Lucky Box claim expired' });
        return;
      }

      const reward = luckyBoxStore.pickReward();
      let newScore;
      try {
        newScore = gameDb.addScore(serverId, player.uid, player.nickname, reward);
      } catch (err) {
        console.error('Lucky Box score update failed:', err);
        send(ws, { type: 'box_error', message: 'Could not save Lucky Box reward' });
        return;
      }

      const finished = luckyBoxStore.finishSpin(serverId, player.uid, now);
      if (!finished.ok) {
        console.error('Lucky Box finishSpin failed after score update', serverId, player.uid);
        send(ws, { type: 'box_error', message: 'Lucky Box state update failed' });
        return;
      }

      player.score = newScore;
      const leaderboard = gameDb.getLeaderboard(serverId);

      broadcast(gameServer, { type: 'box_state', box: finished.box, serverNow: now });
      broadcast(gameServer, { type: 'leaderboard', top: leaderboard });
      send(ws, {
        type: 'box_reward',
        reward,
        score: newScore,
        leaderboard,
        serverNow: now
      });
      return;
    }
'''
new_spin = '''    if (msg.type === 'spin_box') {
      if (!phase4e4bAllowAction(ws, player, 'spin_box')) return;
      const now = Date.now();

      let awarded;
      try {
        awarded = luckyBoxStore.spinAndAward(
          serverId,
          player.uid,
          player.nickname,
          now
        );
      } catch (err) {
        console.error('Lucky Box atomic spin failed:', err);
        send(ws, { type: 'box_error', message: 'Could not save Lucky Box reward' });
        return;
      }

      if (!awarded.ok) {
        send(ws, { type: 'box_state', box: awarded.box, serverNow: now });
        send(ws, {
          type: 'box_error',
          message: awarded.reason || 'Lucky Box claim expired'
        });
        return;
      }

      player.score = awarded.score;
      const leaderboard = gameDb.getLeaderboard(serverId);

      broadcast(gameServer, {
        type: 'box_state',
        box: awarded.box,
        serverNow: now
      });
      broadcast(gameServer, { type: 'leaderboard', top: leaderboard });
      send(ws, {
        type: 'box_reward',
        reward: awarded.reward,
        score: awarded.score,
        leaderboard,
        serverNow: now
      });
      return;
    }
'''
if old_spin not in server:
    raise SystemExit("ERROR: ไม่พบ spin_box handler รูปแบบปัจจุบัน")
server = server.replace(old_spin, new_spin, 1)

insert_after = '''`);

const getStmt = db.prepare(`
'''
if insert_after not in lucky:
    raise SystemExit("ERROR: ไม่พบตำแหน่งหลัง lucky_boxes CREATE TABLE")
score_table = '''`);

db.exec(`
  CREATE TABLE IF NOT EXISTS scores (
    server_id TEXT NOT NULL,
    uid TEXT NOT NULL,
    nickname TEXT NOT NULL,
    score INTEGER NOT NULL DEFAULT 0,
    updated_at INTEGER NOT NULL,
    PRIMARY KEY (server_id, uid)
  );
`);

const getStmt = db.prepare(`
'''
lucky = lucky.replace(insert_after, score_table, 1)

stmt_anchor = '''const finishSpinStmt = db.prepare(`
  UPDATE lucky_boxes
  SET active = 0,
      claimed_by = NULL,
      claim_expires_at = 0,
      next_spawn_at = ?,
      updated_at = ?
  WHERE server_id = ?
    AND active = 1
    AND claimed_by = ?
    AND claim_expires_at > ?
    AND next_spawn_at = 0
`);
'''
if stmt_anchor not in lucky:
    raise SystemExit("ERROR: ไม่พบ finishSpinStmt")
score_stmts = stmt_anchor + '''

const ensureScoreStmt = db.prepare(`
  INSERT INTO scores (
    server_id, uid, nickname, score, updated_at
  )
  VALUES (?, ?, ?, 0, ?)
  ON CONFLICT(server_id, uid)
  DO UPDATE SET nickname = excluded.nickname
`);

const addLuckyScoreStmt = db.prepare(`
  UPDATE scores
  SET score = score + ?,
      nickname = ?,
      updated_at = ?
  WHERE server_id = ? AND uid = ?
`);

const getLuckyScoreStmt = db.prepare(`
  SELECT score
  FROM scores
  WHERE server_id = ? AND uid = ?
`);
'''
lucky = lucky.replace(stmt_anchor, score_stmts, 1)

func_anchor = "function tick(serverId, now = Date.now()) {\n"
if func_anchor not in lucky:
    raise SystemExit("ERROR: ไม่พบ tick() anchor")

atomic_func = r'''// PHASE_4E4D_REPLAY_PROTECTION
// Consume the current claim and award its random reward atomically.
function spinAndAward(serverId, uid, nickname, now = Date.now()) {
  let transactionOpen = false;

  try {
    db.exec('BEGIN IMMEDIATE');
    transactionOpen = true;

    const normalized = normalize(serverId, now);
    const row = normalized.row;

    const allowed = Boolean(
      row &&
      row.active &&
      row.claimed_by === String(uid) &&
      Number(row.claim_expires_at || 0) > now &&
      Number(row.next_spawn_at || 0) === 0
    );

    if (!allowed) {
      db.exec('COMMIT');
      transactionOpen = false;
      return {
        ok: false,
        box: publicBox(row, now),
        reason: 'CLAIM_EXPIRED'
      };
    }

    const reward = pickReward();
    const nextSpawnAt = now + RESPAWN_MS;

    const finished = finishSpinStmt.run(
      nextSpawnAt,
      now,
      serverId,
      String(uid),
      now
    );

    if (Number(finished.changes || 0) !== 1) {
      db.exec('ROLLBACK');
      transactionOpen = false;
      const latest = getStmt.get(serverId);
      return {
        ok: false,
        box: publicBox(latest, now),
        reason: 'CLAIM_ALREADY_CONSUMED'
      };
    }

    ensureScoreStmt.run(
      serverId,
      String(uid),
      String(nickname || 'Player'),
      now
    );

    addLuckyScoreStmt.run(
      reward,
      String(nickname || 'Player'),
      now,
      serverId,
      String(uid)
    );

    const scoreRow = getLuckyScoreStmt.get(
      serverId,
      String(uid)
    );
    const score = Number(scoreRow?.score || 0);

    db.exec('COMMIT');
    transactionOpen = false;

    const finalRow = getStmt.get(serverId);

    return {
      ok: true,
      reward,
      score,
      box: publicBox(finalRow, now)
    };
  } catch (err) {
    if (transactionOpen) {
      try { db.exec('ROLLBACK'); } catch (_) {}
    }
    throw err;
  }
}

'''
lucky = lucky.replace(func_anchor, atomic_func + func_anchor, 1)

export_anchor = '''  canSpin,
  finishSpin,
  tick,
  pickReward
};
'''
export_new = '''  canSpin,
  finishSpin,
  spinAndAward,
  tick,
  pickReward
};
'''
if export_anchor not in lucky:
    raise SystemExit("ERROR: ไม่พบ lucky-box-store exports")
lucky = lucky.replace(export_anchor, export_new, 1)

old = '''        let secureGameSocket = null;
        let secureGameReady = false;
        let secureLastMoveSentAt = 0;
'''
new = '''        let secureGameSocket = null;
        let secureGameReady = false;
        let secureActionSession = '';
        let secureActionSeq = 0;
        let secureLastMoveSentAt = 0;
'''
if old not in client:
    raise SystemExit("ERROR: ไม่พบ secure socket vars")
client = client.replace(old, new, 1)

anchor = '''        function secureSetServerNow(serverNow) {
            const n = Number(serverNow);
            if (Number.isFinite(n) && n > 0) {
                secureServerTimeOffset = n - Date.now();
            }
        }

'''
if anchor not in client:
    raise SystemExit("ERROR: ไม่พบ secureSetServerNow")
client_helpers = anchor + r'''        // PHASE_4E4D_REPLAY_PROTECTION
        function secureNextActionMeta() {
            if (!secureActionSession) {
                console.warn('Replay-protected action session is not ready.');
                return null;
            }

            secureActionSeq += 1;
            return {
                actionSession: secureActionSession,
                actionSeq: secureActionSeq
            };
        }

'''
client = client.replace(anchor, client_helpers, 1)

old = '''                    state.serverPlayerId = String(message.id || '');
                    state.score = Number(message.score) || 0;
'''
new = '''                    state.serverPlayerId = String(message.id || '');
                    secureActionSession = String(message.actionSession || '');
                    secureActionSeq = 0;
                    state.score = Number(message.score) || 0;
'''
if old not in client:
    raise SystemExit("ERROR: ไม่พบ welcome client state")
client = client.replace(old, new, 1)

anchor = '''                case 'protocol_error': {
          console.warn('Server rejected an invalid protocol message.');
          break;
        }

'''
if anchor not in client:
    raise SystemExit("ERROR: ไม่พบ protocol_error case")
new_case = anchor + '''        case 'action_replay_rejected': {
          console.warn(
            'Server replay protection:',
            message.action || 'action',
            message.reason || 'REJECTED',
            'seq:',
            Number(message.actionSeq || 0)
          );
          break;
        }

'''
client = client.replace(anchor, new_case, 1)

old = '''                    secureGameReady = false;
                    secureGameSocket = null;
                    const intentional = secureIntentionalSockets.has(ws);
'''
new = '''                    secureGameReady = false;
                    secureGameSocket = null;
                    secureActionSession = '';
                    secureActionSeq = 0;
                    const intentional = secureIntentionalSockets.has(ws);
'''
if old not in client:
    raise SystemExit("ERROR: ไม่พบ socket close client block")
client = client.replace(old, new, 1)

old = '''            secureGameReady = false;
            secureHandoffInProgress = false;
'''
new = '''            secureGameReady = false;
            secureActionSession = '';
            secureActionSeq = 0;
            secureHandoffInProgress = false;
'''
if old not in client:
    raise SystemExit("ERROR: ไม่พบ secureReturnToMenu reset")
client = client.replace(old, new, 1)

old = '''            try {
                secureGameSocket.send(JSON.stringify({
                    type: 'coin_collect',
                    id,
                    x: Math.round(playerPos.x * 100) / 100,
                    y: Math.round(playerPos.y * 100) / 100,
                    z: Math.round(playerPos.z * 100) / 100,
                    r: Math.round(playerRotation * 1000) / 1000
                }));
'''
new = '''            try {
                const actionMeta = secureNextActionMeta();
                if (!actionMeta) throw new Error('Action session not ready');

                secureGameSocket.send(JSON.stringify({
                    type: 'coin_collect',
                    id,
                    ...actionMeta,
                    x: Math.round(playerPos.x * 100) / 100,
                    y: Math.round(playerPos.y * 100) / 100,
                    z: Math.round(playerPos.z * 100) / 100,
                    r: Math.round(playerRotation * 1000) / 1000
                }));
'''
if old not in client:
    raise SystemExit("ERROR: ไม่พบ coin_collect send")
client = client.replace(old, new, 1)

old = '''            luckyBox.collecting = true;
            setTimeout(() => { if (luckyBox) luckyBox.collecting = false; }, 1200);
            secureGameSocket.send(JSON.stringify({ type: 'collect_box' }));
'''
new = '''            luckyBox.collecting = true;
            setTimeout(() => { if (luckyBox) luckyBox.collecting = false; }, 1200);

            const actionMeta = secureNextActionMeta();
            if (!actionMeta) {
                luckyBox.collecting = false;
                return;
            }

            secureGameSocket.send(JSON.stringify({
                type: 'collect_box',
                ...actionMeta
            }));
'''
if old not in client:
    raise SystemExit("ERROR: ไม่พบ collect_box send")
client = client.replace(old, new, 1)

old = '''            state.wheelSpinning = true;
            document.getElementById('btn-spin-wheel').classList.add('hidden');
            document.getElementById('wheel-result-msg').innerText = 'กำลังขอผลสุ่มจาก Server...';
            secureGameSocket.send(JSON.stringify({ type: 'spin_box' }));
'''
new = '''            const actionMeta = secureNextActionMeta();
            if (!actionMeta) {
                alert('Action Session ยังไม่พร้อม กรุณาเข้าเกมใหม่');
                return;
            }

            state.wheelSpinning = true;
            document.getElementById('btn-spin-wheel').classList.add('hidden');
            document.getElementById('wheel-result-msg').innerText = 'กำลังขอผลสุ่มจาก Server...';
            secureGameSocket.send(JSON.stringify({
                type: 'spin_box',
                ...actionMeta
            }));
'''
if old not in client:
    raise SystemExit("ERROR: ไม่พบ spin_box send")
client = client.replace(old, new, 1)

SERVER.write_text(server, encoding="utf-8")
CLIENT.write_text(client, encoding="utf-8")
LUCKY.write_text(lucky, encoding="utf-8")

print("OK: Phase 4E.4D Replay / Duplicate Action Protection installed")
print("Server backup:", sb)
print("Client backup:", cb)
print("Lucky Box backup:", lb)
print("Protected actions: coin_collect, collect_box, spin_box")
print("Replay session: server-issued UUID + strict monotonic actionSeq")
print("Lucky Box spin: atomic claim-consume + score award transaction")
print("NOTE: Run node --check on both JS server modules before restart")
