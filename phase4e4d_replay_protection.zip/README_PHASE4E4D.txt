Phase 4E.4D — Replay / Duplicate Action Protection

ติดตั้ง:
cd /workspaces/GPT-VOXEL-3D

git fetch origin
git checkout origin/main -- phase4e4d_replay_protection.zip
unzip -o phase4e4d_replay_protection.zip

python3 patch_phase4e4d_replay_protection.py

ตรวจ syntax:
node --check vps/game-server.js
node --check vps/lucky-box-store.js

grep -n -E "PHASE_4E4D_REPLAY_PROTECTION|ANTI-REPLAY|actionSession|actionSeq|spinAndAward" \
  vps/game-server.js vps/lucky-box-store.js index.vps-test-v2.html | head -160

Restart VPS พร้อม log ใหม่:
pkill -f "node vps/game-server.js" || true
rm -f vps/game-server.log

FIREBASE_PROJECT_ID=lucky-game-6936b \
ENTITLEMENTS_BASE=https://voxel-run-v2-demo.hjinffv5426.workers.dev \
nohup node vps/game-server.js > vps/game-server.log 2>&1 &

ตรวจ Server:
curl -s http://127.0.0.1:8080/health ; echo
curl -s http://127.0.0.1:8080/status ; echo

NORMAL PLAY TEST ก่อน:
- เข้า Free Server
- เดินปกติ 60 วินาที และข้าม Zone หลายครั้ง
- เก็บเหรียญ 5-10 เหรียญ
- ตรวจว่าแต่ละเหรียญเพิ่ม 1 คะแนน (หรือ 2 เมื่อ Coin x2 ใช้งานจริง)
- ถ้า Lucky Box พร้อม ให้เก็บและหมุน 1 ครั้ง
- ตรวจว่ารางวัลเพิ่มเพียง 1 ครั้ง
- ออกจาก Server แล้วเข้าใหม่ 1 รอบ

จากนั้นรัน:
grep -n -A 10 "\[ANTI-REPLAY\]" vps/game-server.log | tail -100

ผลที่ต้องการระหว่าง Normal Play:
ไม่มี output

ถ้ามี [ANTI-REPLAY] ระหว่างเล่นปกติ ให้หยุดและส่งภาพ Terminal มา
ยังไม่ต้องทำ Replay Attack Test จนกว่า Normal Play จะผ่าน
