Phase 4E.4A — Controlled Speed Hack Test

This adds a TEMPORARY purple "TEST SPEED x4 BURST" button.
It appears only when the URL contains anticheat_test=1.

Install:
cd /workspaces/GPT-VOXEL-3D
python3 patch_phase4e4a_speed_test.py

Check:
grep -n "PHASE_4E4A_SPEED_TEST_BUTTON" index.vps-test-v2.html

Test:
1. Open index.vps-test-v2.html?anticheat_test=1
2. Enter Free Server.
3. Stand still for ~3 seconds.
4. Tap TEST SPEED x4 BURST ONE time.
5. Expected:
   - character must not move through the fake positions;
   - VPS should reject several packets;
   - because this is sustained cheating, the socket MAY be kicked after enough strikes.

Check VPS log:
grep -n -A 8 "\[ANTI-CHEAT\] movement rejected" vps/game-server.log | tail -100

Expected log:
- multiple movement rejected entries
- distance > allowed
- strikes rising toward 8+
- if strikes reach the configured kick threshold, disconnect is expected

IMPORTANT:
This helper is for your own test server only.
Remove all Anti-Cheat test buttons before production launch.
