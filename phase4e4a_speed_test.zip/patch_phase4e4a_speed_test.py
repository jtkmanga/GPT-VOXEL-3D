from pathlib import Path
from datetime import datetime

p = Path("index.vps-test-v2.html")
if not p.exists():
    raise SystemExit("ERROR: ไม่พบ index.vps-test-v2.html")

s = p.read_text(encoding="utf-8")

if "PHASE_4E4A_SPEED_TEST_BUTTON" in s:
    print("INFO: speed test button already installed")
    raise SystemExit(0)

if "PHASE_4E4A_TELEPORT_TEST_BUTTON" not in s:
    raise SystemExit(
        "ERROR: ไม่พบ Teleport test helper เดิม กรุณาติดตั้ง Phase 4E.4A Teleport Test ก่อน"
    )

stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
backup = p.with_name(f"index.vps-test-v2.before-speed-test.{stamp}.html")
backup.write_text(s, encoding="utf-8")

marker = "</body>"
if marker not in s:
    raise SystemExit("ERROR: ไม่พบ </body> ใน index.vps-test-v2.html")

snippet = r'''
<!-- PHASE_4E4A_SPEED_TEST_BUTTON
     Temporary controlled speed-hack test.
     Visible only with ?anticheat_test=1.
     Remove before production. -->
<script>
(() => {
  const params = new URLSearchParams(location.search);
  if (params.get('anticheat_test') !== '1') return;

  window.addEventListener('load', () => {
    const btn = document.createElement('button');
    btn.id = 'phase4e4a-speed-test';
    btn.type = 'button';
    btn.textContent = 'TEST SPEED x4 BURST';
    btn.style.cssText =
      'position:fixed;right:12px;bottom:145px;z-index:100000;' +
      'background:#7c3aed;color:#fff;border:2px solid #fff;' +
      'padding:10px 12px;border-radius:10px;font-weight:700;';

    const note = document.createElement('div');
    note.id = 'phase4e4a-speed-status';
    note.style.cssText =
      'position:fixed;right:12px;bottom:190px;z-index:100000;' +
      'background:#111;color:#fff;padding:7px 10px;border-radius:8px;' +
      'font:12px sans-serif;max-width:240px;';
    note.textContent = 'Speed test ready';

    btn.addEventListener('click', () => {
      try {
        if (
          !secureGameSocket ||
          secureGameSocket.readyState !== WebSocket.OPEN ||
          !secureGameReady
        ) {
          note.textContent = 'Game Server ยังไม่พร้อม';
          return;
        }

        const baseX = Number(playerPos.x);
        const baseY = Number(playerPos.y);
        const baseZ = Number(playerPos.z);
        const rot = Number(playerRotation) || 0;

        // Keep all fake positions within the VPS ±750 world boundary.
        const dir = baseX <= 620 ? 1 : -1;

        // Send a burst of impossible high-speed positions.
        // Because these packets arrive almost together, the VPS should reject
        // them and accumulate movement violations. Sustained cheating may be kicked.
        for (let i = 1; i <= 10; i++) {
          const fakeX = baseX + dir * (10 * i);
          secureGameSocket.send(JSON.stringify({
            type: 'move',
            x: Math.round(fakeX * 100) / 100,
            y: Math.round(baseY * 100) / 100,
            z: Math.round(baseZ * 100) / 100,
            r: Math.round(rot * 1000) / 1000
          }));
        }

        note.textContent =
          'ส่ง Speed x4 burst แล้ว — Server ควร reject หลาย packet และอาจตัดการเชื่อมต่อ';
        console.warn('[TEST] Sent controlled speed-hack burst', {
          baseX,
          z: baseZ,
          packets: 10
        });
      } catch (err) {
        note.textContent = 'TEST ERROR: ' + (err?.message || err);
        console.error(err);
      }
    });

    document.body.append(note, btn);
  });
})();
</script>
'''

s = s.replace(marker, snippet + "\n" + marker, 1)
p.write_text(s, encoding="utf-8")

print("OK: controlled speed-hack test button installed")
print("Backup:", backup)
print("Open the game with ?anticheat_test=1")
print("Button: TEST SPEED x4 BURST")
