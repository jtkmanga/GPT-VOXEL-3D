#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import re, shutil, subprocess, sys

WORKER = Path("worker.js")
if not WORKER.exists():
    raise SystemExit("ERROR: worker.js not found")

original = WORKER.read_text(encoding="utf-8", errors="replace")
stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
backup = WORKER.with_name(f"worker.before-phase4e4g1-fix2.{stamp}.js")
shutil.copy2(WORKER, backup)

bad_block_rx = re.compile(
    r'(?m)^[ \t]*// PHASE_4E4G1_SECURE_PAYMENT_QR\s*\n'
    r'^[ \t]*if\s*\(\s*request\.method\s*===\s*["\']GET["\']\s*&&\s*'
    r'new URL\(request\.url\)\.pathname\s*===\s*["\']/payment-qr["\']\s*\)\s*\{\s*\n'
    r'^[ \t]*return\s+phase4e4g1PaymentQr\(request,\s*env\);\s*\n'
    r'^[ \t]*\}\s*\n?'
)

# The broken installer inserted this block immediately before the Slip2Go URL.
# Remove only the occurrence that appears before the public export handler.
export_pos = original.find("export default")
if export_pos < 0:
    raise SystemExit("ERROR: export default not found; nothing changed")

prefix = original[:export_pos]
suffix = original[export_pos:]

matches = list(bad_block_rx.finditer(prefix))
if len(matches) != 1:
    raise SystemExit(
        f"ERROR: expected exactly 1 broken payment-qr block before export default, found {len(matches)}; nothing changed"
    )

fixed_prefix = prefix[:matches[0].start()] + prefix[matches[0].end():]
candidate = fixed_prefix + suffix

# Find the REAL public /verify-slip route inside export default -> fetch().
# Match url.pathname === '/verify-slip' (spaces/quote style can vary).
route_rx = re.compile(
    r'(?m)^(?P<indent>[ \t]*)if\s*\(\s*url\.pathname\s*===?\s*["\']/verify-slip["\']\s*\)\s*\{'
)
m = route_rx.search(candidate, candidate.find("export default"))
if not m:
    raise SystemExit(
        "ERROR: real public /verify-slip route not found after export default; nothing changed"
    )

# Avoid double inserting the valid route.
public_part = candidate[candidate.find("export default"):]
if 'url.pathname === "/payment-qr"' in public_part or "url.pathname === '/payment-qr'" in public_part:
    raise SystemExit("ERROR: a public /payment-qr route already exists; inspect manually; nothing changed")

indent = m.group("indent")
valid_route = (
    f'{indent}// PHASE_4E4G1_SECURE_PAYMENT_QR_PUBLIC_ROUTE\n'
    f'{indent}if (url.pathname === "/payment-qr") {{\n'
    f'{indent}  if (request.method === "OPTIONS")\n'
    f'{indent}    return new Response(null, {{ status: 204, headers: corsHeaders(request, env) }});\n'
    f'{indent}  if (request.method !== "GET")\n'
    f'{indent}    return jsonResponse(request, env, {{ ok:false, error:"Method not allowed" }}, 405);\n'
    f'{indent}  return phase4e4g1PaymentQr(request, env);\n'
    f'{indent}}}\n\n'
)

candidate = candidate[:m.start()] + valid_route + candidate[m.start():]

WORKER.write_text(candidate, encoding="utf-8")

# Transactional safety: if syntax still fails, restore original automatically.
check = subprocess.run(
    ["node", "--check", str(WORKER)],
    capture_output=True,
    text=True
)
if check.returncode != 0:
    WORKER.write_text(original, encoding="utf-8")
    print("ERROR: node --check still failed, so worker.js was automatically restored.")
    print(check.stderr.strip())
    print(f"Backup kept at: {backup}")
    sys.exit(1)

print("OK: Phase 4E.4G1 FIX2 repaired worker.js")
print("OK: node --check worker.js passed")
print(f"Backup: {backup}")
print("")
print("NEXT:")
print('  grep -n "payment-qr\\|PHASE_4E4G1" worker.js | head -80')
print("  python3 audit_phase4e4g_payment_security.py | tail -80")
print("")
print("If those look good, deploy:")
print("  npx wrangler deploy")
