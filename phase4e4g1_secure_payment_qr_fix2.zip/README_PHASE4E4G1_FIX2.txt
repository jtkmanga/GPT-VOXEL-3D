Phase 4E.4G1 FIX2

Why this exists:
The previous FIX inserted the /payment-qr route before the FIRST text occurrence
of `/verify-slip`. In the current worker.js, that first occurrence is the
Slip2Go upstream URL:
  https://connect.slip2go.com/api/verify-slip/qr-image/info
So JavaScript syntax broke.

FIX2:
- removes only that misplaced route block
- inserts /payment-qr before the REAL public `if (url.pathname === '/verify-slip')`
  route inside `export default -> fetch()`
- runs `node --check worker.js` automatically
- restores worker.js automatically if syntax still fails

Install:

cd /workspaces/GPT-VOXEL-3D
git fetch origin
git checkout origin/main -- phase4e4g1_secure_payment_qr_fix2.zip
unzip -o phase4e4g1_secure_payment_qr_fix2.zip
python3 patch_phase4e4g1_secure_payment_qr_fix2.py

Then:

grep -n "payment-qr\|PHASE_4E4G1" worker.js | head -80

python3 audit_phase4e4g_payment_security.py | tail -80

Do NOT deploy unless the installer prints:
  OK: node --check worker.js passed

Then:

npx wrangler deploy

After deploy:

curl -s -o /tmp/payment-qr.png -w "%{http_code} %{content_type}\n" \
  "https://voxel-run-v2-demo.hjinffv5426.workers.dev/payment-qr?type=speed"

Expected: HTTP 200 and image/*.
