from pathlib import Path
import re

ROOT = Path(".")
TARGETS = [
    Path("index.vps-test-v2.html"),
    Path("index.html"),
    Path("worker.js"),
    Path("vps/game-server.js"),
    Path("vps/game-db.js"),
    Path("vps/coin-store.js"),
    Path("vps/lucky-box-store.js"),
]

PATTERNS = [
    ("RTDB_WRITE", re.compile(r"\.(set|update|remove|transaction|push)\s*\(", re.I)),
    ("RTDB_REF", re.compile(r"\bdatabase\.ref\s*\(|firebase\.database\s*\(", re.I)),
    ("FIRESTORE_WRITE", re.compile(r"\b(addDoc|setDoc|updateDoc|deleteDoc|writeBatch|runTransaction)\s*\(", re.I)),
    ("FIRESTORE_REF", re.compile(r"\b(doc|collection)\s*\(", re.I)),
    ("LOCAL_SCORE", re.compile(r"localStorage.*(score|coin|vip|buff)|(?:score|coin|vip|buff).*localStorage", re.I)),
    ("PAYMENT_SECRET", re.compile(r"(Authorization\s*[:=].*(Bearer|Basic)|SLIP2GO|api[_-]?secret|secret[_-]?key)", re.I)),
    ("DIRECT_VIP", re.compile(r"(vip|entitlement).*\.(set|update|transaction)\s*\(", re.I)),
]

def iter_candidate_files():
    seen = set()
    for p in TARGETS:
        if p.exists() and p.is_file():
            rp = p.resolve()
            if rp not in seen:
                seen.add(rp)
                yield p
    for pat in ("*.rules", "firebase.json", ".firebaserc"):
        for p in ROOT.rglob(pat):
            if p.is_file():
                rp = p.resolve()
                if rp not in seen:
                    seen.add(rp)
                    yield p

results = []
files = list(iter_candidate_files())

print("=== Phase 4E.4F Firebase / Authorization READ-ONLY AUDIT ===")
print("Files scanned:", len(files))
for p in files:
    print(" -", p)

for p in files:
    try:
        text = p.read_text(encoding="utf-8", errors="replace")
    except Exception as e:
        print(f"WARN cannot read {p}: {e}")
        continue

    for i, line in enumerate(text.splitlines(), start=1):
        for name, rx in PATTERNS:
            if rx.search(line):
                # redact very long lines / obvious credentials from display
                shown = line.strip()
                shown = re.sub(
                    r'([A-Za-z0-9_\-]{20,}:[A-Za-z0-9_\-]{20,})',
                    '[REDACTED_CREDENTIAL]',
                    shown
                )
                if len(shown) > 220:
                    shown = shown[:217] + "..."
                results.append((name, str(p), i, shown))

print()
print("=== MATCHES ===")
if not results:
    print("NO MATCHES")
else:
    for name, path, line, shown in results:
        print(f"[{name}] {path}:{line}: {shown}")

print()
print("=== SUMMARY ===")
from collections import Counter
c = Counter(r[0] for r in results)
for key in [
    "RTDB_WRITE","RTDB_REF","FIRESTORE_WRITE","FIRESTORE_REF",
    "LOCAL_SCORE","PAYMENT_SECRET","DIRECT_VIP"
]:
    print(f"{key}: {c.get(key, 0)}")

print()
print("IMPORTANT:")
print("- This script changes NOTHING.")
print("- Do not paste API secrets/tokens into chat.")
print("- If PAYMENT_SECRET > 0, send only the count + file/line screenshot with secrets hidden.")
print("- If Firebase rules files are not in the repo, the next step is to inspect the rules in Firebase Console.")
