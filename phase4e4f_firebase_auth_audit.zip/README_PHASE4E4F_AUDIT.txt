Phase 4E.4F — Firebase Rules / Authorization Final Lockdown
STEP 1: Read-only audit

This step DOES NOT modify the game.

Install/run:
cd /workspaces/GPT-VOXEL-3D

git fetch origin
git checkout origin/main -- phase4e4f_firebase_auth_audit.zip
unzip -o phase4e4f_firebase_auth_audit.zip

python3 audit_phase4e4f_firebase_authorization.py | tee phase4e4f-audit.txt

Then show/send:
tail -120 phase4e4f-audit.txt

What we are looking for:
- direct Realtime Database writes from browser code
- direct Firestore writes from browser code
- score/coin/VIP/buff stored in localStorage as authoritative data
- payment/API secrets left in browser code
- Firebase rules files present in the repository

Do NOT send any secret/token/API authorization value.
If a secret appears in the report, hide/redact it before sharing.

After this audit we will decide exactly which Firebase paths can remain client-readable
and which must become server-only.
