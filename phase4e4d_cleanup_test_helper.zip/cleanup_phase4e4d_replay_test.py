from pathlib import Path
from datetime import datetime
import re

p = Path("index.vps-test-v2.html")
if not p.exists():
    raise SystemExit("ERROR: ไม่พบ index.vps-test-v2.html")

s = p.read_text(encoding="utf-8")

stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
backup = p.with_name(f"index.vps-test-v2.before-phase4e4d-cleanup.{stamp}.html")
backup.write_text(s, encoding="utf-8")

pattern = r"\s*<!-- PHASE_4E4D_REPLAY_TEST[\s\S]*?</script>\s*"
s, removed = re.subn(pattern, "\n", s, count=1)

if removed != 1:
    raise SystemExit(
        f"ERROR: คาดว่าจะพบ replay test helper 1 block แต่พบ {removed} block"
    )

p.write_text(s, encoding="utf-8")

print("OK: Phase 4E.4D temporary replay test helper removed")
print("Backup:", backup)
print("Core Phase 4E.4D replay protection remains enabled")
