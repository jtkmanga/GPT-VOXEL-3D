Phase 4E.4D Cleanup

Run:
cd /workspaces/GPT-VOXEL-3D
python3 cleanup_phase4e4d_replay_test.py

Verify temporary helper is gone:
grep -n -E "PHASE_4E4D_REPLAY_TEST|TEST REPLAY x2" index.vps-test-v2.html

Expected: no output.

Verify core protection still exists:
grep -n -E "PHASE_4E4D_REPLAY_PROTECTION|ANTI-REPLAY|actionSession|actionSeq|spinAndAward"   vps/game-server.js vps/lucky-box-store.js index.vps-test-v2.html | head -120

Expected: output should still be present.

This removes only the temporary red test button/script.
