Phase 4E.4D — Controlled Replay Attack Test

Install:
cd /workspaces/GPT-VOXEL-3D

git fetch origin
git checkout origin/main -- phase4e4d_replay_test.zip
unzip -o phase4e4d_replay_test.zip

python3 patch_phase4e4d_replay_test.py

Verify:
grep -n "PHASE_4E4D_REPLAY_TEST" index.vps-test-v2.html

Open game:
https://<PORT-3000-HOST>/index.vps-test-v2.html?replay_test=1

Test:
1. เข้า Free Server ตามปกติ
2. ยืนนิ่ง 3 วินาที
3. จดคะแนนก่อนทดสอบ
4. กด TEST REPLAY x2 เพียง 1 ครั้ง
5. คะแนนต้องไม่เพิ่ม

The helper sends:
A) Same coin_collect packet twice, with the exact same actionSession/actionSeq.
   - First copy uses fake coin id 99999 and cannot grant score.
   - Second copy must be rejected as DUPLICATE_OR_OLD_SEQ.

B) A packet with a fake old actionSession.
   - Must be rejected as STALE_SESSION.

Check VPS log:
grep -n -A 10 "\[ANTI-REPLAY\]" vps/game-server.log | tail -120

Expected:
[ANTI-REPLAY] duplicate/stale action rejected
reason: 'DUPLICATE_OR_OLD_SEQ'

and another rejection:
reason: 'STALE_SESSION'

The player should remain connected because this controlled test causes only
2 replay violations, below the disconnect threshold.

Also confirm:
- score unchanged
- game does not crash
- normal movement still works after the test

Do not press the button repeatedly.
This is a temporary test helper and will be removed after PASS.
