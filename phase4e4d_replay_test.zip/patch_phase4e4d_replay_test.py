from pathlib import Path
from datetime import datetime

p = Path("index.vps-test-v2.html")
if not p.exists():
    raise SystemExit("ERROR: ไม่พบ index.vps-test-v2.html")

s = p.read_text(encoding="utf-8")

if "PHASE_4E4D_REPLAY_TEST" in s:
    print("INFO: Phase 4E.4D replay test already installed")
    raise SystemExit(0)

if "PHASE_4E4D_REPLAY_PROTECTION" not in s:
    raise SystemExit("ERROR: ไม่พบ Phase 4E.4D client protection ในไฟล์ล่าสุด")

stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
backup = p.with_name(f"index.vps-test-v2.before-phase4e4d-replay-test.{stamp}.html")
backup.write_text(s, encoding="utf-8")

marker = "</body>"
if marker not in s:
    raise SystemExit("ERROR: ไม่พบ </body>")

snippet = r'''
<!-- PHASE_4E4D_REPLAY_TEST
     Temporary controlled replay test.
     Visible only with ?replay_test=1.
     It does NOT grant score or Lucky Box rewards. -->
<script>
(() => {
  const params = new URLSearchParams(location.search);
  if (params.get('replay_test') !== '1') return;

  window.addEventListener('load', () => {
    const wrap = document.createElement('div');
    wrap.style.cssText =
      'position:fixed;right:12px;bottom:92px;z-index:100002;' +
      'display:flex;flex-direction:column;gap:7px;align-items:flex-end;';

    const status = document.createElement('div');
    status.textContent = 'Replay test ready';
    status.style.cssText =
      'background:#111;color:#fff;padding:7px 10px;border-radius:8px;' +
      'font:12px sans-serif;max-width:300px;';

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.textContent = 'TEST REPLAY x2';
    btn.style.cssText =
      'background:#dc2626;color:#fff;border:2px solid #fff;' +
      'padding:10px 12px;border-radius:10px;font-weight:700;';

    btn.addEventListener('click', async () => {
      try {
        if (
          !secureGameSocket ||
          secureGameSocket.readyState !== WebSocket.OPEN ||
          !secureGameReady ||
          !secureActionSession
        ) {
          status.textContent = 'Game Server / Action Session ยังไม่พร้อม';
          return;
        }

        btn.disabled = true;

        const beforeScore = Number(state.score || 0);

        // Test 1: send the exact same side-effect action twice.
        // id 99999 is deliberately not a real coin, so the first copy cannot
        // grant score. The second identical packet must be caught as replay.
        const duplicateSeq = Number(secureActionSeq || 0) + 1;
        secureActionSeq = duplicateSeq;

        const duplicatePacket = JSON.stringify({
          type: 'coin_collect',
          id: 99999,
          actionSession: secureActionSession,
          actionSeq: duplicateSeq
        });

        status.textContent = 'กำลังทดสอบ duplicate packet...';
        secureGameSocket.send(duplicatePacket);
        await new Promise(resolve => setTimeout(resolve, 220));
        secureGameSocket.send(duplicatePacket);

        await new Promise(resolve => setTimeout(resolve, 350));

        // Test 2: packet captured from an old/different session.
        // Do NOT advance secureActionSeq here, because the server must reject
        // this before consuming the current session's next sequence number.
        const staleSeq = Number(secureActionSeq || 0) + 1;
        const stalePacket = JSON.stringify({
          type: 'coin_collect',
          id: 99999,
          actionSession: 'OLD_SESSION_REPLAY_1234567890',
          actionSeq: staleSeq
        });

        status.textContent = 'กำลังทดสอบ stale session packet...';
        secureGameSocket.send(stalePacket);

        await new Promise(resolve => setTimeout(resolve, 500));

        const afterScore = Number(state.score || 0);
        status.textContent =
          'ส่ง Replay Test แล้ว | Score ' + beforeScore + ' → ' + afterScore +
          ' | ตรวจ [ANTI-REPLAY] ใน VPS log';

        console.warn('[TEST] Phase 4E.4D replay test sent', {
          beforeScore,
          afterScore,
          duplicateSeq,
          staleSeq
        });
      } catch (err) {
        status.textContent = 'TEST ERROR: ' + (err?.message || err);
        console.error(err);
      } finally {
        setTimeout(() => { btn.disabled = false; }, 2500);
      }
    });

    wrap.append(status, btn);
    document.body.appendChild(wrap);
  });
})();
</script>
'''

s = s.replace(marker, snippet + "\n" + marker, 1)
p.write_text(s, encoding="utf-8")

print("OK: Phase 4E.4D controlled replay test installed")
print("Backup:", backup)
print("Open with ?replay_test=1")
print("Button: TEST REPLAY x2")
print("Expected score change: 0")
