from pathlib import Path
from datetime import datetime
import re

root = Path.cwd()
server_path = root / 'vps' / 'game-server.js'
coin_path = root / 'vps' / 'coin-store.js'

if not server_path.exists():
    raise SystemExit('ERROR: vps/game-server.js not found. Run this from /workspaces/GPT-VOXEL-3D')

stamp = datetime.now().strftime('%Y%m%d-%H%M%S')
backup = root / 'vps' / f'game-server.before-phase4e1.{stamp}.js'
backup.write_text(server_path.read_text())

coin_code = r'''const { DatabaseSync } = require('node:sqlite');
const crypto = require('crypto');
const path = require('path');

const DB_PATH = process.env.COIN_DB_PATH || path.join(__dirname, 'voxel-coins.sqlite');
const COIN_COUNT = 200;
const RESPAWN_MS = 60_000;
const MAP_HALF = 740;

const db = new DatabaseSync(DB_PATH);
db.exec(`
  PRAGMA journal_mode = WAL;
  CREATE TABLE IF NOT EXISTS coins (
    server_id TEXT NOT NULL,
    coin_id INTEGER NOT NULL,
    x REAL NOT NULL,
    z REAL NOT NULL,
    active INTEGER NOT NULL DEFAULT 1,
    respawn_at INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (server_id, coin_id)
  );
`);

const countStmt = db.prepare('SELECT COUNT(*) AS n FROM coins WHERE server_id = ?');
const allStmt = db.prepare('SELECT coin_id, x, z, active, respawn_at FROM coins WHERE server_id = ? ORDER BY coin_id');
const getStmt = db.prepare('SELECT coin_id, x, z, active, respawn_at FROM coins WHERE server_id = ? AND coin_id = ?');
const insertStmt = db.prepare('INSERT OR IGNORE INTO coins(server_id, coin_id, x, z, active, respawn_at) VALUES (?, ?, ?, ?, 1, 0)');
const collectStmt = db.prepare('UPDATE coins SET active = 0, respawn_at = ? WHERE server_id = ? AND coin_id = ? AND active = 1');
const dueStmt = db.prepare('SELECT coin_id FROM coins WHERE server_id = ? AND active = 0 AND respawn_at > 0 AND respawn_at <= ? ORDER BY coin_id');
const respawnStmt = db.prepare('UPDATE coins SET x = ?, z = ?, active = 1, respawn_at = 0 WHERE server_id = ? AND coin_id = ?');

function randCoord() {
  return crypto.randomInt(-MAP_HALF * 10, MAP_HALF * 10 + 1) / 10;
}

function randomPosition() {
  return { x: randCoord(), z: randCoord() };
}

function normalize(row) {
  return {
    id: Number(row.coin_id),
    x: Number(row.x),
    z: Number(row.z),
    active: Number(row.active) === 1,
    respawnAt: Number(row.respawn_at) || 0
  };
}

function ensureServer(serverId) {
  const count = Number(countStmt.get(serverId)?.n || 0);
  if (count >= COIN_COUNT) return;

  for (let id = 0; id < COIN_COUNT; id++) {
    const p = randomPosition();
    insertStmt.run(serverId, id, p.x, p.z);
  }
}

function respawnDue(serverId, now = Date.now()) {
  ensureServer(serverId);
  const due = dueStmt.all(serverId, now);
  const changed = [];

  for (const row of due) {
    const id = Number(row.coin_id);
    const p = randomPosition();
    respawnStmt.run(p.x, p.z, serverId, id);
    changed.push({ id, x: p.x, z: p.z, active: true, respawnAt: 0 });
  }

  return changed;
}

function snapshot(serverId, now = Date.now()) {
  ensureServer(serverId);
  respawnDue(serverId, now);
  return allStmt.all(serverId).map(normalize);
}

function getCoin(serverId, coinId) {
  ensureServer(serverId);
  const row = getStmt.get(serverId, coinId);
  return row ? normalize(row) : null;
}

function collect(serverId, coinId, now = Date.now()) {
  ensureServer(serverId);
  const coin = getCoin(serverId, coinId);
  if (!coin || !coin.active) return null;

  const respawnAt = now + RESPAWN_MS;
  const result = collectStmt.run(respawnAt, serverId, coinId);
  if (!Number(result.changes || 0)) return null;

  return {
    ...coin,
    active: false,
    respawnAt
  };
}

module.exports = {
  COIN_COUNT,
  RESPAWN_MS,
  snapshot,
  getCoin,
  collect,
  respawnDue
};
'''
coin_path.write_text(coin_code)

s = server_path.read_text()

# 1) require coin store after game-db
if "require('./coin-store')" not in s:
    marker = "const gameDb = require('./game-db');"
    if marker not in s:
        raise SystemExit('ERROR: game-db require marker not found')
    s = s.replace(marker, marker + "\nconst coinStore = require('./coin-store');", 1)

# 2) welcome snapshot
if 'coins: coinStore.snapshot(serverId)' not in s:
    pattern = re.compile(r"(\n\s*score,\s*\n\s*leaderboard)(\s*\n\s*\}\);)")
    m = pattern.search(s)
    if not m:
        raise SystemExit('ERROR: welcome score/leaderboard marker not found')
    repl = m.group(1) + ",\n        coins: coinStore.snapshot(serverId),\n        serverNow: Date.now()" + m.group(2)
    s = s[:m.start()] + repl + s[m.end():]

# 3) coin collect handler before move handler
if "msg.type === 'coin_collect'" not in s:
    move_marker = "    if (msg.type === 'move') {"
    if move_marker not in s:
        raise SystemExit("ERROR: move handler marker not found")

    handler = r'''    if (msg.type === 'coin_collect') {
      const coinId = Number(msg.id);
      if (!Number.isInteger(coinId) || coinId < 0 || coinId >= coinStore.COIN_COUNT) {
        send(ws, { type: 'coin_collect_result', ok: false, reason: 'INVALID_COIN' });
        return;
      }

      const now = Date.now();
      const coin = coinStore.getCoin(serverId, coinId);
      if (!coin || !coin.active) {
        send(ws, {
          type: 'coin_collect_result',
          ok: false,
          reason: 'INACTIVE',
          id: coinId,
          coin,
          serverNow: now
        });
        return;
      }

      const dx = Number(player.x) - Number(coin.x);
      const dz = Number(player.z) - Number(coin.z);
      const maxCollectDistance = 3.2;
      if (!Number.isFinite(dx) || !Number.isFinite(dz) || (dx * dx + dz * dz) > maxCollectDistance * maxCollectDistance) {
        send(ws, {
          type: 'coin_collect_result',
          ok: false,
          reason: 'TOO_FAR',
          id: coinId,
          serverNow: now
        });
        return;
      }

      const collected = coinStore.collect(serverId, coinId, now);
      if (!collected) {
        send(ws, {
          type: 'coin_collect_result',
          ok: false,
          reason: 'ALREADY_COLLECTED',
          id: coinId,
          serverNow: now
        });
        return;
      }

      const coinBuffActive = Number(player.entitlements?.coinExpires || 0) > now;
      const addAmount = coinBuffActive ? 2 : 1;
      const newScore = gameDb.addScore(serverId, player.uid, player.nickname, addAmount);
      player.score = newScore;
      const leaderboard = gameDb.getLeaderboard(serverId);

      broadcast(gameServer, {
        type: 'coin_state',
        event: 'collected',
        coin: collected,
        by: player.id,
        serverNow: now
      });

      send(ws, {
        type: 'coin_collect_result',
        ok: true,
        id: coinId,
        score: newScore,
        add: addAmount,
        leaderboard,
        coin: collected,
        serverNow: now
      });

      return;
    }

'''
    s = s.replace(move_marker, handler + move_marker, 1)

# 4) respawn ticker before listen
if 'coinStore.respawnDue(serverId, now)' not in s:
    listen_marker = "httpServer.listen(PORT, '0.0.0.0', () => {"
    if listen_marker not in s:
        raise SystemExit('ERROR: httpServer.listen marker not found')

    ticker = r'''setInterval(() => {
  const now = Date.now();

  for (const [serverId, gameServer] of Object.entries(SERVERS)) {
    const respawned = coinStore.respawnDue(serverId, now);
    for (const coin of respawned) {
      broadcast(gameServer, {
        type: 'coin_state',
        event: 'respawned',
        coin,
        serverNow: now
      });
    }
  }
}, 1000).unref();

'''
    s = s.replace(listen_marker, ticker + listen_marker, 1)

server_path.write_text(s)
print('OK: Phase 4E.1 VPS authoritative coins installed')
print('Created: vps/coin-store.js')
print('Backup :', backup)
print('Next   : node --check vps/coin-store.js && node --check vps/game-server.js')
