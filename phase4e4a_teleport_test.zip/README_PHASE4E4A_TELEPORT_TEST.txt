Phase 4E.4A — Controlled Teleport Attack Test

This adds a TEMPORARY red test button to index.vps-test-v2.html.
It appears only when the URL has anticheat_test=1.

Install:
cd /workspaces/GPT-VOXEL-3D
python3 patch_phase4e4a_teleport_test.py

Check:
grep -n "PHASE_4E4A_TELEPORT_TEST_BUTTON" index.vps-test-v2.html

Open:
https://<your-port-3000-host>/index.vps-test-v2.html?anticheat_test=1

Test:
1. Enter Free Server normally.
2. Stand still about 3 seconds.
3. Tap the red "TEST TELEPORT +120" button ONE time.
4. The real character must NOT jump 120 units.
5. The game should remain connected.
6. Check log:

grep -n -A 8 "\[ANTI-CHEAT\] movement rejected" vps/game-server.log | tail -30

Expected:
- one rejection
- distance around 120
- allowed much lower than 120
- strikes normally 1
- no disconnect

IMPORTANT:
This is a temporary test helper. Remove it before production launch.
