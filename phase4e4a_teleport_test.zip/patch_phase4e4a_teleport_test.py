from pathlib import Path
from datetime import datetime

p = Path("index.vps-test-v2.html")
if not p.exists():
    raise SystemExit("ERROR: ไม่พบ index.vps-test-v2.html")

s = p.read_text(encoding="utf-8")
if "PHASE_4E4A_TELEPORT_TEST_BUTTON" in s:
    print("INFO: test button already installed")
    raise SystemExit(0)

stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
backup = p.with_name(f"index.vps-test-v2.before-teleport-test.{stamp}.html")
backup.write_text(s, encoding="utf-8")

marker = "</body>"
if marker not in s:
    raise SystemExit("ERROR: ไม่พบ </body> ใน index.vps-test-v2.html")

snippet = r'''
<!-- PHASE_4E4A_TELEPORT_TEST_BUTTON
     Temporary controlled anti-cheat test.
     Visible only when URL contains ?anticheat_test=1 or &anticheat_test=1.
     Remove before production launch. -->
<script>
(() => {
  const params = new URLSearchParams(location.search);
  if (params.get('anticheat_test') !== '1') return;

  window.addEventListener('load', () => {
    const wrap = document.createElement('div');
    wrap.id = 'phase4e4a-teleport-test';
    wrap.style.cssText =
      'position:fixed;right:12px;bottom:90px;z-index:99999;' +
      'display:flex;flex-direction:column;gap:6px;align-items:flex-end;';

    const status = document.createElement('div');
    status.textContent = 'Anti-Cheat test ready';
    status.style.cssText =
      'background:#111;color:#fff;padding:7px 10px;border-radius:8px;' +
      'font:12px sans-serif;max-width:220px;';

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.textContent = 'TEST TELEPORT +120';
    btn.style.cssText =
      'background:#b91c1c;color:#fff;border:2px solid #fff;' +
      'padding:10px 12px;border-radius:10px;font-weight:700;';

    btn.addEventListener('click', () => {
      try {
        if (
          !secureGameSocket ||
          secureGameSocket.readyState !== WebSocket.OPEN ||
          !secureGameReady
        ) {
          status.textContent = 'Game Server ยังไม่พร้อม';
          return;
        }

        const baseX = Number(playerPos.x);
        const baseY = Number(playerPos.y);
        const baseZ = Number(playerPos.z);
        const rot = Number(playerRotation) || 0;

        // Keep the fake target inside the VPS world boundary +/-750.
        const fakeX = baseX <= 600 ? baseX + 120 : baseX - 120;

        secureGameSocket.send(JSON.stringify({
          type: 'move',
          x: Math.round(fakeX * 100) / 100,
          y: Math.round(baseY * 100) / 100,
          z: Math.round(baseZ * 100) / 100,
          r: Math.round(rot * 1000) / 1000
        }));

        status.textContent =
          'ส่ง Teleport ปลอม +120 แล้ว — ตัวละครจริงต้องไม่วาร์ป';
        console.warn('[TEST] Sent controlled teleport packet', {
          fromX: baseX,
          fakeX,
          z: baseZ
        });
      } catch (err) {
        status.textContent = 'TEST ERROR: ' + (err?.message || err);
        console.error(err);
      }
    });

    wrap.append(status, btn);
    document.body.appendChild(wrap);
  });
})();
</script>
'''

s = s.replace(marker, snippet + "\n" + marker, 1)
p.write_text(s, encoding="utf-8")

print("OK: controlled teleport test button installed")
print("Backup:", backup)
print("Open the game with ?anticheat_test=1")
