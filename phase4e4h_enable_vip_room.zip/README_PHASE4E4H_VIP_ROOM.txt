Phase 4E.4H — เปิด VIP Server ในตัวเกม

รัน:
cd /workspaces/GPT-VOXEL-3D
python3 patch_phase4e4h_enable_vip_room.py

จากนั้นตรวจ:
grep -n -A 30 -B 8 "PHASE_4E4H_VIP_ROOM_ROUTING\|vipAllowed\|selectVipServer = async" index.vps-test-v2.html | head -220

สิ่งที่ patch ทำ:
- ส่ง server=free1/vip1 ไป VPS พร้อม zone
- ให้ selectVipServer เลือก VIP จริงหลังตรวจ entitlement
- เอา return ที่ทำให้ Start Game หยุดก่อนเข้า VIP ออก
- ให้ map init ใช้ห้องที่เลือก
- ยกเลิก client-side temporary block ของ VIP ถ้ายังอยู่

ฝั่ง VPS ยังเป็นผู้ตัดสินสิทธิ์ VIP ขั้นสุดท้าย และ maxPlayers=100 ยังอยู่เหมือนเดิม
