#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import re, shutil

TARGET = Path("index.vps-test-v2.html")
if not TARGET.exists():
    raise SystemExit("ERROR: ไม่พบ index.vps-test-v2.html — ให้รันจาก /workspaces/GPT-VOXEL-3D")

src = TARGET.read_text(encoding="utf-8")

def must_replace(old, new, label):
    global src
    if old not in src:
        raise SystemExit(f"ERROR: ไม่พบจุดแก้ {label} — ยังไม่ได้เขียนไฟล์")
    src = src.replace(old, new, 1)

# 1) Zone socket: send room/server as well as zone.
old_zone = """function secureZoneSocketUrl(zoneId) {
            const normalized = secureNormalizeZoneId(zoneId);
            if (!normalized) throw new Error('Zone ไม่ถูกต้อง');
            return `${SECURE_WORKER_WS_BASE}?zone=${encodeURIComponent(normalized)}`;
        }"""

new_zone = """function secureZoneSocketUrl(zoneId) {
            const normalized = secureNormalizeZoneId(zoneId);
            if (!normalized) throw new Error('Zone ไม่ถูกต้อง');

            // PHASE_4E4H_VIP_ROOM_ROUTING
            const selectedServer = state.selectedServerId === 'vip1' ? 'vip1' : 'free1';

            return `${SECURE_WORKER_WS_BASE}?server=${encodeURIComponent(selectedServer)}&zone=${encodeURIComponent(normalized)}`;
        }"""

must_replace(old_zone, new_zone, "secureZoneSocketUrl")

# 2) selectVipServer: remove temporary disabled alert, actually select VIP.
pattern = re.compile(
    r"""selectVipServer\s*=\s*async\s+function\([^)]*\)\s*\{.*?\n\s*\};\s*\n\s*function\s+securePlayerNameFromId""",
    re.S
)
replacement = """selectVipServer = async function(serverId = 'vip1', options = {}) {
            const silent = Boolean(options && options.silent);

            if (String(serverId) !== 'vip1') return false;

            try {
                await secureLoadEntitlements(true);
            } catch (err) {
                if (!silent) alert('ตรวจสอบสิทธิ์ VIP กับ Server ไม่สำเร็จ: ' + err.message);
                return false;
            }

            const vipSub = state.userVipSubscriptions.vip1;
            const expiry = Number(vipSub?.expireTime || 0);

            if (expiry <= secureNow()) {
                if (!silent) alert('คุณยังไม่มีสิทธิ์ VIP ที่ใช้งานได้');
                return false;
            }

            state.selectedServerId = 'vip1';
            renderServersUI();
            return true;
        };

        function securePlayerNameFromId"""

src2, n = pattern.subn(replacement, src, count=1)
if n != 1:
    raise SystemExit(f"ERROR: ไม่พบ selectVipServer รูปแบบที่คาดไว้ (matches={n}) — ยังไม่ได้เขียนไฟล์")
src = src2

# 3) Start Game: after entitlement validation, continue into the game.
old_start = """if (state.selectedServerId === 'vip1') {
                await selectVipServer('vip1');
                return;
            }"""
new_start = """if (state.selectedServerId === 'vip1') {
                const vipAllowed = await selectVipServer('vip1', { silent: true });
                if (!vipAllowed) {
                    alert('สิทธิ์ VIP ไม่พร้อมใช้งาน กรุณาตรวจสอบการชำระเงินหรือวันหมดอายุ');
                    return;
                }
            }"""
must_replace(old_start, new_start, "startGame VIP early return")

# 4) Map/world setup must follow selected room instead of always free1.
must_replace(
    "initServerMapData('free1');",
    "initServerMapData(state.selectedServerId === 'vip1' ? 'vip1' : 'free1');",
    "initServerMapData selected room"
)

# 5) Remove temporary client-side VIP purchase hard-block, if still present.
tmp_block = re.compile(
    r"""\n\s*if\s*\(type\s*===\s*['"]vip1['"]\)\s*\{\s*
        alert\([^;]*Security Test[^;]*\);\s*
        return;\s*
    \}\s*""",
    re.X | re.S
)
src, _ = tmp_block.subn("\n", src, count=1)

# 6) Allow vip1 through secure verify-slip, if old condition still blocks it.
src = src.replace(
    "if (!SECURE_PAYMENT_ITEMS[item] || item === 'vip1') {",
    "if (!SECURE_PAYMENT_ITEMS[item]) {",
    1
)

checks = [
    "PHASE_4E4H_VIP_ROOM_ROUTING",
    "?server=${encodeURIComponent(selectedServer)}&zone=${encodeURIComponent(normalized)}",
    "const vipAllowed = await selectVipServer('vip1', { silent: true });",
    "initServerMapData(state.selectedServerId === 'vip1' ? 'vip1' : 'free1');",
    "state.selectedServerId = 'vip1';",
]
missing = [x for x in checks if x not in src]
if missing:
    raise SystemExit("ERROR: sanity check ไม่ผ่าน: " + " | ".join(missing))

stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
backup = TARGET.with_name(f"{TARGET.stem}.before-phase4e4h-vip.{stamp}{TARGET.suffix}")
shutil.copy2(TARGET, backup)
TARGET.write_text(src, encoding="utf-8")

print("OK: Phase 4E.4H VIP room client routing enabled")
print("Backup:", backup)
print("NEXT:")
print("  grep -n -A 30 -B 8 \"PHASE_4E4H_VIP_ROOM_ROUTING\\|vipAllowed\\|selectVipServer = async\" index.vps-test-v2.html | head -220")
