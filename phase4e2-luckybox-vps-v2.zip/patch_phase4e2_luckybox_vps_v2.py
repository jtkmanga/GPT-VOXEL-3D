from pathlib import Path
import shutil
import time

ROOT = Path.cwd()
SERVER = ROOT / 'vps' / 'game-server.js'
STORE = ROOT / 'vps' / 'lucky-box-store.js'

if not SERVER.exists():
    raise SystemExit('ERROR: ไม่พบ vps/game-server.js — ให้รันจาก root ของ GPT-VOXEL-3D')

stamp = time.strftime('%Y%m%d-%H%M%S')
backup = ROOT / 'vps' / f'game-server.before-phase4e2.{stamp}.js'
shutil.copy2(SERVER, backup)

store_code = r'''
'use strict';

const path = require('path');
const crypto = require('crypto');
const { DatabaseSync } = require('node:sqlite');

const DB_PATH = path.join(__dirname, 'voxel-game.sqlite');
const db = new DatabaseSync(DB_PATH);

const RESPAWN_MS = 4 * 60 * 60 * 1000;
const CLAIM_MS = 30 * 1000;
const MAP_HALF = 720;

db.exec(`
  CREATE TABLE IF NOT EXISTS lucky_boxes (
    server_id TEXT PRIMARY KEY,
    x REAL NOT NULL,
    z REAL NOT NULL,
    active INTEGER NOT NULL DEFAULT 1,
    claimed_by TEXT,
    claim_expires_at INTEGER NOT NULL DEFAULT 0,
    next_spawn_at INTEGER NOT NULL DEFAULT 0,
    spawn_cycle INTEGER NOT NULL DEFAULT 1,
    updated_at INTEGER NOT NULL
  )
`);

const getStmt = db.prepare(`
  SELECT server_id, x, z, active, claimed_by, claim_expires_at,
         next_spawn_at, spawn_cycle, updated_at
  FROM lucky_boxes
  WHERE server_id = ?
`);

const insertStmt = db.prepare(`
  INSERT OR IGNORE INTO lucky_boxes
  (server_id, x, z, active, claimed_by, claim_expires_at,
   next_spawn_at, spawn_cycle, updated_at)
  VALUES (?, ?, ?, 1, NULL, 0, 0, 1, ?)
`);

const releaseExpiredClaimStmt = db.prepare(`
  UPDATE lucky_boxes
  SET claimed_by = NULL,
      claim_expires_at = 0,
      active = 1,
      updated_at = ?
  WHERE server_id = ?
    AND claimed_by IS NOT NULL
    AND claim_expires_at > 0
    AND claim_expires_at <= ?
    AND next_spawn_at = 0
`);

const respawnStmt = db.prepare(`
  UPDATE lucky_boxes
  SET x = ?,
      z = ?,
      active = 1,
      claimed_by = NULL,
      claim_expires_at = 0,
      next_spawn_at = 0,
      spawn_cycle = spawn_cycle + 1,
      updated_at = ?
  WHERE server_id = ?
    AND next_spawn_at > 0
    AND next_spawn_at <= ?
`);

const claimStmt = db.prepare(`
  UPDATE lucky_boxes
  SET claimed_by = ?,
      claim_expires_at = ?,
      active = 1,
      updated_at = ?
  WHERE server_id = ?
    AND active = 1
    AND next_spawn_at = 0
    AND (claimed_by IS NULL OR claim_expires_at <= ?)
`);

const finishSpinStmt = db.prepare(`
  UPDATE lucky_boxes
  SET active = 0,
      claimed_by = NULL,
      claim_expires_at = 0,
      next_spawn_at = ?,
      updated_at = ?
  WHERE server_id = ?
    AND active = 1
    AND claimed_by = ?
    AND claim_expires_at > ?
    AND next_spawn_at = 0
`);

function randomCoord() {
  return crypto.randomInt(-MAP_HALF * 10, MAP_HALF * 10 + 1) / 10;
}

function ensureRow(serverId, now = Date.now()) {
  let row = getStmt.get(serverId);
  if (!row) {
    insertStmt.run(serverId, randomCoord(), randomCoord(), now);
    row = getStmt.get(serverId);
  }
  return row;
}

function publicBox(row, now = Date.now()) {
  const claimed = Boolean(row.claimed_by && Number(row.claim_expires_at || 0) > now);
  const waitingRespawn = Number(row.next_spawn_at || 0) > now;
  return {
    x: Number(row.x),
    z: Number(row.z),
    active: Boolean(row.active) && !waitingRespawn,
    claimed,
    claimExpiresAt: Number(row.claim_expires_at || 0),
    nextSpawnTimestamp: Number(row.next_spawn_at || 0),
    spawnCycle: Number(row.spawn_cycle || 0)
  };
}

function normalize(serverId, now = Date.now()) {
  let row = ensureRow(serverId, now);
  let changed = false;

  if (Number(row.next_spawn_at || 0) > 0 && Number(row.next_spawn_at) <= now) {
    const result = respawnStmt.run(randomCoord(), randomCoord(), now, serverId, now);
    changed = Number(result.changes || 0) > 0;
    row = getStmt.get(serverId);
  }

  if (row.claimed_by && Number(row.claim_expires_at || 0) > 0 && Number(row.claim_expires_at) <= now && Number(row.next_spawn_at || 0) === 0) {
    const result = releaseExpiredClaimStmt.run(now, serverId, now);
    changed = changed || Number(result.changes || 0) > 0;
    row = getStmt.get(serverId);
  }

  return { row, changed };
}

function snapshot(serverId, now = Date.now()) {
  const { row } = normalize(serverId, now);
  return publicBox(row, now);
}

function claim(serverId, uid, now = Date.now()) {
  normalize(serverId, now);
  const expiresAt = now + CLAIM_MS;
  const result = claimStmt.run(String(uid), expiresAt, now, serverId, now);
  const ok = Number(result.changes || 0) === 1;
  const row = getStmt.get(serverId);
  return { ok, box: publicBox(row, now), reason: ok ? null : 'BOX_UNAVAILABLE' };
}

function canSpin(serverId, uid, now = Date.now()) {
  const { row } = normalize(serverId, now);
  const ok = Boolean(
    row && row.active && row.claimed_by === String(uid) &&
    Number(row.claim_expires_at || 0) > now && Number(row.next_spawn_at || 0) === 0
  );
  return { ok, box: publicBox(row, now), reason: ok ? null : 'CLAIM_EXPIRED' };
}

function finishSpin(serverId, uid, now = Date.now()) {
  const nextSpawnAt = now + RESPAWN_MS;
  const result = finishSpinStmt.run(nextSpawnAt, now, serverId, String(uid), now);
  const ok = Number(result.changes || 0) === 1;
  const row = getStmt.get(serverId);
  return { ok, box: publicBox(row, now), reason: ok ? null : 'CLAIM_EXPIRED' };
}

function tick(serverId, now = Date.now()) {
  const result = normalize(serverId, now);
  return { changed: result.changed, box: publicBox(result.row, now) };
}

function pickReward() {
  const n = crypto.randomInt(1000);
  if (n < 500) return 100;
  if (n < 800) return 500;
  if (n < 990) return 1000;
  if (n < 999) return 5000;
  return 9999;
}

module.exports = {
  RESPAWN_MS,
  CLAIM_MS,
  snapshot,
  claim,
  canSpin,
  finishSpin,
  tick,
  pickReward
};
'''

STORE.write_text(store_code, encoding='utf-8')

s = SERVER.read_text(encoding='utf-8')

if 'PHASE_4E2_LUCKY_BOX_VPS' in s:
    print('INFO: Phase 4E.2 มีอยู่แล้วใน game-server.js')
    print(f'Backup: {backup}')
    raise SystemExit(0)

anchor = "const gameDb = require('./game-db');"
if anchor not in s:
    raise SystemExit('ERROR: ไม่พบ gameDb require marker')
s = s.replace(anchor, anchor + "\nconst luckyBoxStore = require('./lucky-box-store');", 1)

anchor = 'coins: coinStore.snapshot(serverId),'
if anchor not in s:
    raise SystemExit('ERROR: ไม่พบ welcome coin snapshot marker')
s = s.replace(anchor, anchor + "\n      box: luckyBoxStore.snapshot(serverId, Date.now()),", 1)

move_marker = "    if (msg.type === 'move') {"
if move_marker not in s:
    raise SystemExit('ERROR: ไม่พบ move handler marker')

handlers = r'''
    // PHASE_4E2_LUCKY_BOX_VPS
    if (msg.type === 'collect_box') {
      const now = Date.now();
      const currentBox = luckyBoxStore.snapshot(serverId, now);

      if (!currentBox.active || currentBox.claimed) {
        send(ws, { type: 'box_state', box: currentBox, serverNow: now });
        send(ws, { type: 'box_error', message: 'Lucky Box is not available' });
        return;
      }

      const dx = Number(player.x) - Number(currentBox.x);
      const dz = Number(player.z) - Number(currentBox.z);
      const maxCollectDistance = 3.5;

      if (!Number.isFinite(dx) || !Number.isFinite(dz) || (dx * dx + dz * dz) > maxCollectDistance * maxCollectDistance) {
        send(ws, { type: 'box_state', box: currentBox, serverNow: now });
        send(ws, { type: 'box_error', message: 'Too far from Lucky Box' });
        return;
      }

      const claimed = luckyBoxStore.claim(serverId, player.uid, now);
      if (!claimed.ok) {
        send(ws, { type: 'box_state', box: claimed.box, serverNow: now });
        send(ws, { type: 'box_error', message: claimed.reason || 'Lucky Box already claimed' });
        return;
      }

      broadcast(gameServer, { type: 'box_state', box: claimed.box, serverNow: now });
      send(ws, { type: 'box_spin_ready', box: claimed.box, serverNow: now });
      return;
    }

    if (msg.type === 'spin_box') {
      const now = Date.now();
      const spinPermission = luckyBoxStore.canSpin(serverId, player.uid, now);

      if (!spinPermission.ok) {
        send(ws, { type: 'box_state', box: spinPermission.box, serverNow: now });
        send(ws, { type: 'box_error', message: spinPermission.reason || 'Lucky Box claim expired' });
        return;
      }

      const reward = luckyBoxStore.pickReward();
      let newScore;
      try {
        newScore = gameDb.addScore(serverId, player.uid, player.nickname, reward);
      } catch (err) {
        console.error('Lucky Box score update failed:', err);
        send(ws, { type: 'box_error', message: 'Could not save Lucky Box reward' });
        return;
      }

      const finished = luckyBoxStore.finishSpin(serverId, player.uid, now);
      if (!finished.ok) {
        console.error('Lucky Box finishSpin failed after score update', serverId, player.uid);
        send(ws, { type: 'box_error', message: 'Lucky Box state update failed' });
        return;
      }

      player.score = newScore;
      const leaderboard = gameDb.getLeaderboard(serverId);

      broadcast(gameServer, { type: 'box_state', box: finished.box, serverNow: now });
      broadcast(gameServer, { type: 'leaderboard', top: leaderboard });
      send(ws, {
        type: 'box_reward',
        reward,
        score: newScore,
        leaderboard,
        serverNow: now
      });
      return;
    }

'''

s = s.replace(move_marker, handlers + move_marker, 1)

listen_marker = 'httpServer.listen(PORT'
if listen_marker not in s:
    raise SystemExit('ERROR: ไม่พบ httpServer.listen marker')

ticker = r'''
// PHASE_4E2_LUCKY_BOX_TICK
setInterval(() => {
  const now = Date.now();
  for (const [serverId, gameServer] of Object.entries(SERVERS)) {
    try {
      const result = luckyBoxStore.tick(serverId, now);
      if (result.changed) {
        broadcast(gameServer, { type: 'box_state', box: result.box, serverNow: now });
      }
    } catch (err) {
      console.error('Lucky Box tick failed:', serverId, err);
    }
  }
}, 1000).unref();

'''

s = s.replace(listen_marker, ticker + listen_marker, 1)
SERVER.write_text(s, encoding='utf-8')

print('OK: Phase 4E.2 Lucky Box VPS installed')
print('Created: vps/lucky-box-store.js')
print(f'Backup: {backup}')
print('Protocol: collect_box -> box_spin_ready -> spin_box -> box_reward')
print('Respawn: 4 hours, persisted in SQLite')
print('Rewards: 100/500/1000/5000/9999 = 50/30/19/0.9/0.1%')
