from pathlib import Path
from datetime import datetime
import re

p = Path("index.vps-test-v2.html")
if not p.exists():
    raise SystemExit("ERROR: ไม่พบ index.vps-test-v2.html")

s = p.read_text(encoding="utf-8")
stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
backup = p.with_name(f"index.vps-test-v2.before-phase4e4b-cleanup.{stamp}.html")
backup.write_text(s, encoding="utf-8")

patterns = [
    r"\s*<!-- PHASE_4E4B_ACTION_SPAM_TEST[\s\S]*?</script>\s*",
    r"\s*<!-- PHASE_4E4B_PACKET_FLOOD_TEST[\s\S]*?</script>\s*",
]

removed = 0
for pat in patterns:
    s, n = re.subn(pat, "\n", s, count=1)
    removed += n

if removed == 0:
    raise SystemExit("ERROR: ไม่พบ Phase 4E.4B test helper ที่ต้องลบ")

p.write_text(s, encoding="utf-8")

print("OK: Phase 4E.4B temporary spam-test helpers removed")
print("Backup:", backup)
print("Removed blocks:", removed)
print("Core VPS Anti-Spam protection remains enabled")
