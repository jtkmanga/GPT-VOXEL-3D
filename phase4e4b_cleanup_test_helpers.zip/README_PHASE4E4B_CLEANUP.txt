Phase 4E.4B Cleanup

Run:
cd /workspaces/GPT-VOXEL-3D
python3 cleanup_phase4e4b_test_helpers.py

Verify:
grep -n -E "PHASE_4E4B_(ACTION_SPAM|PACKET_FLOOD)_TEST|TEST MOVE SPAM|TEST PACKET FLOOD"   index.vps-test-v2.html

Expected: no output.

This removes only temporary test buttons/scripts.
The real VPS Phase 4E.4B Anti-Spam protection in vps/game-server.js remains enabled.
