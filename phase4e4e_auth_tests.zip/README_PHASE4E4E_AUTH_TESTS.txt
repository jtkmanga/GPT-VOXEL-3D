Phase 4E.4E — Controlled Session/Auth Tests

Install:
cd /workspaces/GPT-VOXEL-3D

git fetch origin
git checkout origin/main -- phase4e4e_auth_tests.zip
unzip -o phase4e4e_auth_tests.zip
python3 patch_phase4e4e_auth_tests.py

Verify:
grep -n -E "PHASE_4E4E_AUTH_TEST_HELPER|TEST AUTH REFRESH|TEST UNAUTH 15s" index.vps-test-v2.html

Open:
https://<PORT-3000-HOST>/index.vps-test-v2.html?auth_test=1

Test 1 — AUTH REFRESH
1. Enter Free Server normally.
2. Wait 3 seconds.
3. Press TEST AUTH REFRESH once.
4. Expected on-screen status: AUTH REFRESH PASS.
5. Score/gameplay must remain normal.

Test 2 — UNAUTH 15s
1. Stay in the game.
2. Press TEST UNAUTH 15s once.
3. The helper opens a second raw WebSocket and deliberately sends no auth.
4. Expected: the raw socket closes around 15 seconds with close code 4000.
5. Main game session must remain connected.

Check VPS log after Test 2:
grep -n -A 8 "\[AUTH-HARDEN\]" vps/game-server.log | tail -120

Expected for Test 2:
[AUTH-HARDEN] authentication deadline exceeded

Test 3 — DUPLICATE UID SESSION (manual)
1. Keep device/tab A inside Free Server.
2. Open the same game in a second browser tab/device B using the SAME Google account.
3. Enter the SAME Free Server on B.
4. Expected: old session A receives session_replaced and returns to menu; B remains active.
5. VPS log should contain:
[AUTH-HARDEN] duplicate UID session replaced

Check:
grep -n -A 10 "\[AUTH-HARDEN\]" vps/game-server.log | tail -160

Do not repeatedly press test buttons. They are temporary test helpers and should be removed after PASS.
