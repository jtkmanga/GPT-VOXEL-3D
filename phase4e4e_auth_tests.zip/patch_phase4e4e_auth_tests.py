from pathlib import Path
from datetime import datetime

p = Path('index.vps-test-v2.html')
if not p.exists():
    raise SystemExit('ERROR: ไม่พบ index.vps-test-v2.html')
s = p.read_text(encoding='utf-8')
if 'PHASE_4E4E_AUTH_TEST_HELPER' in s:
    print('INFO: Phase 4E.4E auth test helper already installed')
    raise SystemExit(0)
if 'PHASE_4E4E_SESSION_AUTH_HARDENING' not in s:
    raise SystemExit('ERROR: ไม่พบ Phase 4E.4E client code')
stamp = datetime.now().strftime('%Y%m%d-%H%M%S')
backup = p.with_name(f'index.vps-test-v2.before-phase4e4e-auth-tests.{stamp}.html')
backup.write_text(s, encoding='utf-8')

# Dispatch a temporary browser event when the real server confirms auth refresh.
anchor = """                case 'auth_refreshed':\n                    if (message.serverNow) secureSetServerNow(message.serverNow);\n                    secureScheduleAuthRefresh(message.tokenExpiresAt);\n"""
replacement = """                case 'auth_refreshed':\n                    if (message.serverNow) secureSetServerNow(message.serverNow);\n                    secureScheduleAuthRefresh(message.tokenExpiresAt);\n                    // PHASE_4E4E_AUTH_TEST_HELPER_EVENT\n                    window.dispatchEvent(new CustomEvent('phase4e4e-auth-refreshed', { detail: message }));\n"""
if anchor not in s:
    raise SystemExit("ERROR: ไม่พบ auth_refreshed case")
s = s.replace(anchor, replacement, 1)

marker = '</body>'
if marker not in s:
    raise SystemExit('ERROR: ไม่พบ </body>')

snippet = r'''
<!-- PHASE_4E4E_AUTH_TEST_HELPER
     Temporary controlled auth-hardening tests.
     Visible only with ?auth_test=1. Remove after PASS. -->
<script>
(() => {
  const params = new URLSearchParams(location.search);
  if (params.get('auth_test') !== '1') return;

  window.addEventListener('load', () => {
    const wrap = document.createElement('div');
    wrap.style.cssText =
      'position:fixed;right:12px;bottom:92px;z-index:100002;' +
      'display:flex;flex-direction:column;gap:7px;align-items:flex-end;';

    const status = document.createElement('div');
    status.textContent = 'Auth test ready';
    status.style.cssText =
      'background:#111;color:#fff;padding:7px 10px;border-radius:8px;' +
      'font:12px sans-serif;max-width:320px;';

    const refreshBtn = document.createElement('button');
    refreshBtn.type = 'button';
    refreshBtn.textContent = 'TEST AUTH REFRESH';
    refreshBtn.style.cssText =
      'background:#2563eb;color:#fff;border:2px solid #fff;' +
      'padding:10px 12px;border-radius:10px;font-weight:700;';

    const idleBtn = document.createElement('button');
    idleBtn.type = 'button';
    idleBtn.textContent = 'TEST UNAUTH 15s';
    idleBtn.style.cssText =
      'background:#9333ea;color:#fff;border:2px solid #fff;' +
      'padding:10px 12px;border-radius:10px;font-weight:700;';

    let refreshTimer = null;

    const onRefreshed = ev => {
      if (refreshTimer) clearTimeout(refreshTimer);
      refreshTimer = null;
      const exp = Number(ev?.detail?.tokenExpiresAt || 0);
      status.textContent =
        'AUTH REFRESH PASS ✓ | tokenExpiresAt=' + (exp || 'received');
      refreshBtn.disabled = false;
    };
    window.addEventListener('phase4e4e-auth-refreshed', onRefreshed);

    refreshBtn.addEventListener('click', async () => {
      if (
        !secureGameSocket ||
        secureGameSocket.readyState !== WebSocket.OPEN ||
        !secureGameReady ||
        !auth.currentUser
      ) {
        status.textContent = 'เข้า Free Server ก่อนทดสอบ Auth Refresh';
        return;
      }

      refreshBtn.disabled = true;
      status.textContent = 'กำลังบังคับ Firebase token refresh...';

      try {
        await secureRefreshGameAuth();
        refreshTimer = setTimeout(() => {
          status.textContent = 'AUTH REFRESH TIMEOUT — ตรวจ VPS/client log';
          refreshBtn.disabled = false;
        }, 8000);
      } catch (err) {
        status.textContent = 'AUTH REFRESH ERROR: ' + (err?.message || err);
        refreshBtn.disabled = false;
      }
    });

    idleBtn.addEventListener('click', () => {
      idleBtn.disabled = true;
      status.textContent = 'เปิด socket ที่ไม่ส่ง auth — รอประมาณ 15 วินาที...';

      let raw;
      let settled = false;
      const started = Date.now();

      try {
        const zone = secureCurrentZoneId || secureZoneFromPosition(playerPos.x, playerPos.z) || '5,5';
        raw = new WebSocket(secureGameplaySocketUrl(zone));
      } catch (err) {
        status.textContent = 'UNAUTH TEST ERROR: ' + (err?.message || err);
        idleBtn.disabled = false;
        return;
      }

      const hardTimeout = setTimeout(() => {
        if (settled) return;
        settled = true;
        try { raw.close(); } catch (_) {}
        status.textContent = 'UNAUTH TIMEOUT FAIL — socket ยังไม่ถูก Server ปิดใน 22s';
        idleBtn.disabled = false;
      }, 22000);

      raw.addEventListener('close', ev => {
        if (settled) return;
        settled = true;
        clearTimeout(hardTimeout);
        const elapsed = ((Date.now() - started) / 1000).toFixed(1);
        if (Number(ev.code) === 4000) {
          status.textContent =
            'UNAUTH 15s PASS ✓ | close=4000 | ' + elapsed + 's';
        } else {
          status.textContent =
            'UNAUTH closed | code=' + ev.code + ' | ' + elapsed +
            's — ตรวจ VPS log';
        }
        idleBtn.disabled = false;
      });

      raw.addEventListener('error', () => {
        // close event is authoritative for this test.
      });
    });

    wrap.append(status, refreshBtn, idleBtn);
    document.body.appendChild(wrap);
  });
})();
</script>
'''

s = s.replace(marker, snippet + '\n' + marker, 1)
p.write_text(s, encoding='utf-8')
print('OK: Phase 4E.4E controlled auth test helper installed')
print('Backup:', backup)
print('Open with ?auth_test=1')
print('Buttons: TEST AUTH REFRESH, TEST UNAUTH 15s')
