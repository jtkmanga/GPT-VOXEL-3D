Phase 4E.4E — Session / Authentication Hardening

This phase adds:
- 15-second authentication deadline for idle unauthenticated WebSockets
- Firebase claim freshness checks
- one active Firebase UID session per game server
- server-side token-expiry timer even while the player is idle
- secure in-session Firebase token refresh before expiry
- refreshed token must belong to the same Firebase UID
- entitlement/VIP access is rechecked during token refresh
- auth_refresh rate limiting

Install:
cd /workspaces/GPT-VOXEL-3D

git fetch origin
git checkout origin/main -- phase4e4e_session_auth_hardening.zip
unzip -o phase4e4e_session_auth_hardening.zip

python3 patch_phase4e4e_session_auth_hardening.py

Syntax:
node --check vps/game-server.js
node --check vps/lucky-box-store.js

Verify:
grep -n -E "PHASE_4E4E_SESSION_AUTH_HARDENING|AUTH-HARDEN|auth_refresh|session_replaced|tokenExpiresAt"   vps/game-server.js index.vps-test-v2.html | head -160

Restart:
pkill -f "node vps/game-server.js" || true
rm -f vps/game-server.log

FIREBASE_PROJECT_ID=lucky-game-6936b ENTITLEMENTS_BASE=https://voxel-run-v2-demo.hjinffv5426.workers.dev nohup node vps/game-server.js > vps/game-server.log 2>&1 &

Check:
curl -s http://127.0.0.1:8080/health ; echo
curl -s http://127.0.0.1:8080/status ; echo

NORMAL PLAY TEST FIRST:
- Use only one active game tab/session for this first test.
- Enter Free Server.
- Walk normally for 60-90 seconds.
- Cross multiple Zones.
- Collect 5-10 coins.
- If Lucky Box is ready, collect/spin once.
- Exit to menu and enter again once.

Then:
grep -n -A 10 "\[AUTH-HARDEN\]" vps/game-server.log | tail -120

Expected during single-session normal play:
NO OUTPUT.

If you intentionally open the same Firebase account in another active game
session, an AUTH-HARDEN duplicate-session log is expected; do not use that
during the first normal-play test.

After normal play passes, the next controlled tests should verify:
1) forced auth refresh
2) duplicate same-UID session replacement
3) unauthenticated socket timeout
