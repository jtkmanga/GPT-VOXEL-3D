from pathlib import Path
from datetime import datetime

SERVER = Path("vps/game-server.js")
CLIENT = Path("index.vps-test-v2.html")

for p in (SERVER, CLIENT):
    if not p.exists():
        raise SystemExit(f"ERROR: ไม่พบ {p}")

server = SERVER.read_text(encoding="utf-8")
client = CLIENT.read_text(encoding="utf-8")

if "PHASE_4E4E_SESSION_AUTH_HARDENING" in server:
    print("INFO: Phase 4E.4E already installed")
    raise SystemExit(0)

if "PHASE_4E4D_REPLAY_PROTECTION" not in server:
    raise SystemExit("ERROR: ต้องติดตั้ง Phase 4E.4D ก่อน")

stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
server_backup = SERVER.with_name(f"game-server.before-phase4e4e.{stamp}.js")
client_backup = CLIENT.with_name(f"index.vps-test-v2.before-phase4e4e.{stamp}.html")
server_backup.write_text(server, encoding="utf-8")
client_backup.write_text(client, encoding="utf-8")

# ---------------------------------------------------------------
# 1) Protocol validation: allow secure in-session Firebase refresh.
# ---------------------------------------------------------------
old = 'const PHASE4E4C_ALLOWED_TYPES = new Set(["auth", "coin_collect", "collect_box", "move", "spin_box"]);'
new = 'const PHASE4E4C_ALLOWED_TYPES = new Set(["auth", "auth_refresh", "coin_collect", "collect_box", "move", "spin_box"]);'
if old not in server:
    raise SystemExit("ERROR: ไม่พบ PHASE4E4C_ALLOWED_TYPES รูปแบบปัจจุบัน")
server = server.replace(old, new, 1)

old = """  if (msg.type === 'auth') {
    if (
      typeof msg.token !== 'string' ||
      msg.token.length < 20 ||
      msg.token.length > PHASE4E4C_MAX_STRING_LENGTH
    ) {
      return 'BAD_AUTH_TOKEN';
    }

    if (
      msg.nickname !== undefined &&
      (typeof msg.nickname !== 'string' ||
        msg.nickname.length < 1 ||
        msg.nickname.length > 40)
    ) {
      return 'BAD_NICKNAME';
    }
  }
"""
new = """  if (msg.type === 'auth' || msg.type === 'auth_refresh') {
    if (
      typeof msg.token !== 'string' ||
      msg.token.length < 20 ||
      msg.token.length > PHASE4E4C_MAX_STRING_LENGTH
    ) {
      return 'BAD_AUTH_TOKEN';
    }

    if (
      msg.type === 'auth' &&
      msg.nickname !== undefined &&
      (typeof msg.nickname !== 'string' ||
        msg.nickname.length < 1 ||
        msg.nickname.length > 40)
    ) {
      return 'BAD_NICKNAME';
    }
  }
"""
if old not in server:
    raise SystemExit("ERROR: ไม่พบ auth protocol validator")
server = server.replace(old, new, 1)

# ---------------------------------------------------------------
# 2) Rate-limit token refresh attempts.
# ---------------------------------------------------------------
old = """  auth:         { windowMs: 10000, max: 5,  kickAfter: 10 },
  move:         { windowMs: 1000,  max: 30, kickAfter: 20 },
"""
new = """  auth:         { windowMs: 10000, max: 5,  kickAfter: 10 },
  auth_refresh: { windowMs: 60000, max: 3,  kickAfter: 6  },
  move:         { windowMs: 1000,  max: 30, kickAfter: 20 },
"""
if old not in server:
    raise SystemExit("ERROR: ไม่พบ PHASE4E4B_ACTION_LIMITS auth/move anchor")
server = server.replace(old, new, 1)

# ---------------------------------------------------------------
# 3) Server-side session/auth hardening helpers.
# ---------------------------------------------------------------
marker = "// Phase 4E.4A — server-authoritative movement anti-cheat"
pos = server.find(marker)
if pos < 0:
    raise SystemExit("ERROR: ไม่พบ Phase 4E.4A marker")

helpers = r'''// PHASE_4E4E_SESSION_AUTH_HARDENING
// Security policy:
// 1) idle unauthenticated sockets are closed quickly;
// 2) Firebase claims must be fresh and structurally sane;
// 3) one active Firebase UID session per game server;
// 4) a verified token expiry closes even an idle authenticated socket;
// 5) long-running sessions refresh Firebase auth in-place, but UID cannot change.
const PHASE4E4E_AUTH_DEADLINE_MS = 15000;
const PHASE4E4E_MIN_TOKEN_REMAINING_SEC = 30;
const PHASE4E4E_MAX_TOKEN_LIFETIME_SEC = 2 * 60 * 60;
const PHASE4E4E_IAT_FUTURE_GRACE_SEC = 120;

function phase4e4eUidSessions(server) {
  if (!(server.uidSessions instanceof Map)) {
    server.uidSessions = new Map();
  }
  return server.uidSessions;
}

function phase4e4eValidateClaims(verified, expectedUid = '') {
  const nowSec = Math.floor(Date.now() / 1000);
  const uid = String(verified?.uid || verified?.sub || '').trim();
  const exp = Number(verified?.exp);
  const iat = Number(verified?.iat || 0);

  if (!uid || uid.length > 256) {
    return { ok: false, reason: 'BAD_UID' };
  }

  if (!Number.isSafeInteger(exp)) {
    return { ok: false, reason: 'BAD_EXP' };
  }

  if (exp <= nowSec + PHASE4E4E_MIN_TOKEN_REMAINING_SEC) {
    return { ok: false, reason: 'TOKEN_TOO_CLOSE_TO_EXPIRY' };
  }

  if (Number.isFinite(iat) && iat > 0) {
    if (iat > nowSec + PHASE4E4E_IAT_FUTURE_GRACE_SEC) {
      return { ok: false, reason: 'IAT_IN_FUTURE' };
    }

    if (exp - iat > PHASE4E4E_MAX_TOKEN_LIFETIME_SEC) {
      return { ok: false, reason: 'TOKEN_LIFETIME_TOO_LONG' };
    }
  }

  if (expectedUid && uid !== String(expectedUid)) {
    return { ok: false, reason: 'UID_CHANGED' };
  }

  return { ok: true, uid, exp, iat };
}

function phase4e4eClearTimers(player) {
  if (player?.authDeadlineTimer) {
    clearTimeout(player.authDeadlineTimer);
    player.authDeadlineTimer = null;
  }
  if (player?.tokenExpiryTimer) {
    clearTimeout(player.tokenExpiryTimer);
    player.tokenExpiryTimer = null;
  }
}

function phase4e4eScheduleTokenExpiry(ws, player) {
  if (player.tokenExpiryTimer) clearTimeout(player.tokenExpiryTimer);

  const expiresAtMs = Number(player.tokenExpiresAt || 0) * 1000;
  const delayMs = Math.max(1, expiresAtMs - Date.now() + 250);

  player.tokenExpiryTimer = setTimeout(() => {
    if (!player.authenticated || player.sessionRevoked) return;

    player.sessionRevoked = true;
    console.warn('[AUTH-HARDEN] verified Firebase token expired', {
      uid: player.uid || null,
      nickname: player.nickname || null,
      server: player.serverId || null
    });

    send(ws, {
      type: 'auth_error',
      code: 'TOKEN_EXPIRED',
      message: 'Authentication expired',
      serverNow: Date.now()
    });

    try {
      if (ws.readyState === WebSocket.OPEN) {
        ws.close(4003, 'Authentication expired');
      }
    } catch (_) {}
  }, delayMs);

  if (typeof player.tokenExpiryTimer?.unref === 'function') {
    player.tokenExpiryTimer.unref();
  }
}

function phase4e4eCleanupPlayer(gameServer, player) {
  if (!player || player.cleanedUp) return false;
  player.cleanedUp = true;
  phase4e4eClearTimers(player);

  if (player.authenticated) {
    removePlayerFromZone(gameServer, player);
    gameServer.players.delete(player.id);

    const sessions = phase4e4eUidSessions(gameServer);
    if (player.uid && sessions.get(player.uid) === player.id) {
      sessions.delete(player.uid);
    }

    broadcastNearby(
      gameServer,
      player,
      {
        type: 'leave',
        id: player.id,
        count: gameServer.players.size
      }
    );
  }

  return true;
}

function phase4e4eClaimUidSession(gameServer, player) {
  const sessions = phase4e4eUidSessions(gameServer);
  const previousId = sessions.get(player.uid);

  if (previousId && previousId !== player.id) {
    const previous = gameServer.players.get(previousId);

    if (previous) {
      previous.sessionRevoked = true;

      console.warn('[AUTH-HARDEN] duplicate UID session replaced', {
        uid: player.uid,
        oldPlayerId: previous.id,
        newPlayerId: player.id,
        server: player.serverId
      });

      send(previous.ws, {
        type: 'session_replaced',
        message: 'This account signed in from another game session',
        serverNow: Date.now()
      });

      phase4e4eCleanupPlayer(gameServer, previous);

      try {
        if (previous.ws?.readyState === WebSocket.OPEN) {
          previous.ws.close(4001, 'Session replaced');
        }
      } catch (_) {}
    }
  }

  sessions.set(player.uid, player.id);
}

'''
server = server[:pos] + helpers + server[pos:]

# ---------------------------------------------------------------
# 4) Close unauthenticated idle sockets.
# ---------------------------------------------------------------
old = """  ws.player = player;

  send(ws, {
"""
new = """  ws.player = player;

  player.authDeadlineTimer = setTimeout(() => {
    if (player.authenticated || player.cleanedUp) return;

    console.warn('[AUTH-HARDEN] authentication deadline exceeded', {
      playerId: player.id,
      server: serverId
    });

    try {
      if (ws.readyState === WebSocket.OPEN) {
        ws.close(4000, 'Authentication timeout');
      }
    } catch (_) {}
  }, PHASE4E4E_AUTH_DEADLINE_MS);

  if (typeof player.authDeadlineTimer?.unref === 'function') {
    player.authDeadlineTimer.unref();
  }

  send(ws, {
"""
if old not in server:
    raise SystemExit("ERROR: ไม่พบ ws.player connection anchor")
server = server.replace(old, new, 1)

# ---------------------------------------------------------------
# 5) Initial auth: cancel idle deadline once auth starts and validate claims.
# ---------------------------------------------------------------
old = """    if (msg.type === 'auth') {
      if (!phase4e4bAllowAction(ws, player, 'auth')) return;
      if (player.authenticated) return;

      player.authAttempts =
"""
new = """    if (msg.type === 'auth') {
      if (!phase4e4bAllowAction(ws, player, 'auth')) return;
      if (player.authenticated) return;

      if (player.authDeadlineTimer) {
        clearTimeout(player.authDeadlineTimer);
        player.authDeadlineTimer = null;
      }

      player.authAttempts =
"""
if old not in server:
    raise SystemExit("ERROR: ไม่พบ auth handler start")
server = server.replace(old, new, 1)

old = """      const nickname =
        String(msg.nickname || 'Player')
          .trim()
          .slice(0, 24) || 'Player';

      player.uid = verified.uid;
      player.tokenExpiresAt = verified.exp;
      player.nickname = nickname;
"""
new = """      const claims = phase4e4eValidateClaims(verified);
      if (!claims.ok) {
        console.warn('[AUTH-HARDEN] rejected Firebase token claims', {
          reason: claims.reason,
          server: serverId
        });
        send(ws, {
          type: 'auth_error',
          code: claims.reason,
          message: 'Firebase session is not fresh enough'
        });
        ws.close(1008, 'Invalid Firebase session');
        return;
      }

      const nickname =
        String(msg.nickname || 'Player')
          .trim()
          .slice(0, 24) || 'Player';

      player.uid = claims.uid;
      player.tokenExpiresAt = claims.exp;
      player.tokenIssuedAt = claims.iat;
      player.nickname = nickname;
"""
if old not in server:
    raise SystemExit("ERROR: ไม่พบ initial verified token assignment")
server = server.replace(old, new, 1)

old = """      player.entitlements = entitlementData.entitlements || {};
      player.vipActive = vipActive;
      player.authenticated = true;
      phase4e4dStartSession(player);

      const score = gameDb.ensurePlayer(
"""
new = """      player.entitlements = entitlementData.entitlements || {};
      player.vipActive = vipActive;
      player.authenticated = true;
      player.sessionRevoked = false;
      phase4e4dStartSession(player);

      const score = gameDb.ensurePlayer(
"""
if old not in server:
    raise SystemExit("ERROR: ไม่พบ authenticated entitlement block")
server = server.replace(old, new, 1)

old = """      const leaderboard =
        gameDb.getLeaderboard(serverId);

      gameServer.players.set(player.id, player);
"""
new = """      const leaderboard =
        gameDb.getLeaderboard(serverId);

      // Only replace an older session after this new login has fully passed
      // Firebase verification, entitlement checks, and DB initialization.
      phase4e4eClaimUidSession(gameServer, player);
      phase4e4eScheduleTokenExpiry(ws, player);
      gameServer.players.set(player.id, player);
"""
if old not in server:
    raise SystemExit("ERROR: ไม่พบ leaderboard/player registration anchor")
server = server.replace(old, new, 1)

old = """        actionSession: player.actionSession,
        server: serverId,
"""
new = """        actionSession: player.actionSession,
        tokenExpiresAt: player.tokenExpiresAt,
        sessionPolicy: 'single_uid_per_server',
        server: serverId,
"""
if old not in server:
    raise SystemExit("ERROR: ไม่พบ welcome actionSession anchor")
server = server.replace(old, new, 1)

# ---------------------------------------------------------------
# 6) Secure in-session Firebase token refresh.
# ---------------------------------------------------------------
anchor = """      return;
    }

    if (
      !player.authenticated ||
      !player.uid ||
      Math.floor(Date.now() / 1000) >= player.tokenExpiresAt
    ) {
"""
if anchor not in server:
    raise SystemExit("ERROR: ไม่พบ post-auth guard anchor")

refresh_handler = r'''      return;
    }

    if (msg.type === 'auth_refresh') {
      if (!phase4e4bAllowAction(ws, player, 'auth_refresh')) return;

      if (
        !player.authenticated ||
        !player.uid ||
        player.sessionRevoked ||
        Math.floor(Date.now() / 1000) >= Number(player.tokenExpiresAt || 0)
      ) {
        send(ws, {
          type: 'auth_error',
          code: 'SESSION_NOT_ACTIVE',
          message: 'Sign in required'
        });
        ws.close(1008, 'Authentication expired');
        return;
      }

      let refreshed;
      try {
        refreshed = await verifyFirebaseIdToken(
          msg.token,
          FIREBASE_PROJECT_ID
        );
      } catch (_) {
        console.warn('[AUTH-HARDEN] Firebase token refresh verification failed', {
          uid: player.uid,
          server: serverId
        });
        send(ws, {
          type: 'auth_error',
          code: 'REFRESH_INVALID',
          message: 'Firebase token refresh failed'
        });
        ws.close(1008, 'Invalid refreshed token');
        return;
      }

      const refreshClaims = phase4e4eValidateClaims(refreshed, player.uid);
      if (!refreshClaims.ok) {
        console.warn('[AUTH-HARDEN] rejected refreshed token claims', {
          uid: player.uid,
          reason: refreshClaims.reason,
          server: serverId
        });
        send(ws, {
          type: 'auth_error',
          code: refreshClaims.reason,
          message: 'Refreshed Firebase session rejected'
        });
        ws.close(1008, 'Refreshed session rejected');
        return;
      }

      let refreshedEntitlements;
      try {
        refreshedEntitlements = await loadEntitlements(msg.token);
      } catch (_) {
        send(ws, {
          type: 'auth_error',
          code: 'ENTITLEMENT_REFRESH_FAILED',
          message: 'Unable to refresh account access'
        });
        ws.close(1013, 'Entitlement refresh unavailable');
        return;
      }

      const refreshedServerNow =
        Number(refreshedEntitlements?.serverNow) || Date.now();
      const refreshedVipExpires =
        Number(refreshedEntitlements?.entitlements?.vip1Expires) || 0;
      const refreshedVipActive =
        refreshedEntitlements?.active?.vip1 === true &&
        refreshedVipExpires > refreshedServerNow;

      if (serverId === 'vip1' && !refreshedVipActive) {
        send(ws, {
          type: 'auth_error',
          code: 'VIP_EXPIRED',
          message: 'VIP access expired'
        });
        ws.close(1008, 'VIP access expired');
        return;
      }

      player.tokenExpiresAt = refreshClaims.exp;
      player.tokenIssuedAt = refreshClaims.iat;
      player.entitlements = refreshedEntitlements.entitlements || {};
      player.vipActive = refreshedVipActive;
      phase4e4eScheduleTokenExpiry(ws, player);

      send(ws, {
        type: 'auth_refreshed',
        tokenExpiresAt: player.tokenExpiresAt,
        entitlements: player.entitlements,
        vipActive: player.vipActive,
        serverNow: refreshedServerNow
      });
      return;
    }

    if (
      !player.authenticated ||
      !player.uid ||
      player.sessionRevoked ||
      Math.floor(Date.now() / 1000) >= player.tokenExpiresAt
    ) {
'''
server = server.replace(anchor, refresh_handler, 1)

# ---------------------------------------------------------------
# 7) Idempotent disconnect cleanup also clears session registries/timers.
# ---------------------------------------------------------------
old = """  ws.on('close', () => {
    if (!player.authenticated) return;

    removePlayerFromZone(
      gameServer,
      player
    );

    gameServer.players.delete(player.id);

    broadcastNearby(
      gameServer,
      player,
      {
        type: 'leave',
        id: player.id,
        count: gameServer.players.size
      }
    );
  });
"""
new = """  ws.on('close', () => {
    phase4e4eCleanupPlayer(gameServer, player);
  });
"""
if old not in server:
    raise SystemExit("ERROR: ไม่พบ ws close cleanup block")
server = server.replace(old, new, 1)

# ---------------------------------------------------------------
# 8) Client: schedule token refresh and handle session replacement.
# ---------------------------------------------------------------
old = """        let secureActionSession = '';
        let secureActionSeq = 0;
        let secureLastMoveSentAt = 0;
"""
new = """        let secureActionSession = '';
        let secureActionSeq = 0;
        let secureTokenExpiresAt = 0;
        let secureAuthRefreshTimer = null;
        let secureAuthRefreshInFlight = false;
        let secureSessionWasReplaced = false;
        let secureLastMoveSentAt = 0;
"""
if old not in client:
    raise SystemExit("ERROR: ไม่พบ secure replay/session vars")
client = client.replace(old, new, 1)

marker = "        // PHASE_4E4D_REPLAY_PROTECTION\n"
pos = client.find(marker)
if pos < 0:
    raise SystemExit("ERROR: ไม่พบ Phase 4E.4D client marker")

client_helpers = r'''        // PHASE_4E4E_SESSION_AUTH_HARDENING
        const SECURE_AUTH_REFRESH_EARLY_MS = 5 * 60 * 1000;
        const SECURE_AUTH_REFRESH_RETRY_MS = 30 * 1000;

        function secureClearAuthRefreshTimer() {
            if (secureAuthRefreshTimer) clearTimeout(secureAuthRefreshTimer);
            secureAuthRefreshTimer = null;
        }

        function secureScheduleAuthRefresh(tokenExpiresAt) {
            secureClearAuthRefreshTimer();
            secureTokenExpiresAt = Number(tokenExpiresAt || 0);
            if (!Number.isFinite(secureTokenExpiresAt) || secureTokenExpiresAt <= 0) return;

            const targetMs = secureTokenExpiresAt * 1000 - SECURE_AUTH_REFRESH_EARLY_MS;
            const delayMs = Math.max(30_000, targetMs - secureNow());

            secureAuthRefreshTimer = setTimeout(() => {
                secureRefreshGameAuth().catch(err => {
                    console.warn('Game auth refresh failed:', err);
                });
            }, delayMs);
        }

        async function secureRefreshGameAuth() {
            if (secureAuthRefreshInFlight) return;
            if (!state.isPlaying || !secureGameReady) return;
            if (!secureGameSocket || secureGameSocket.readyState !== WebSocket.OPEN) return;
            if (!auth.currentUser) return;

            secureAuthRefreshInFlight = true;
            secureClearAuthRefreshTimer();

            try {
                const token = await auth.currentUser.getIdToken(true);
                if (!secureGameSocket || secureGameSocket.readyState !== WebSocket.OPEN) return;

                secureGameSocket.send(JSON.stringify({
                    type: 'auth_refresh',
                    token
                }));

                // Fallback retry. A successful auth_refreshed message replaces this
                // with a fresh schedule based on the server-verified expiry time.
                secureAuthRefreshTimer = setTimeout(() => {
                    secureRefreshGameAuth().catch(() => {});
                }, SECURE_AUTH_REFRESH_RETRY_MS);
            } finally {
                secureAuthRefreshInFlight = false;
            }
        }

'''
client = client[:pos] + client_helpers + client[pos:]

old = """                    state.serverPlayerId = String(message.id || '');
                    secureActionSession = String(message.actionSession || '');
                    secureActionSeq = 0;
                    state.score = Number(message.score) || 0;
"""
new = """                    state.serverPlayerId = String(message.id || '');
                    secureActionSession = String(message.actionSession || '');
                    secureActionSeq = 0;
                    secureSessionWasReplaced = false;
                    secureScheduleAuthRefresh(message.tokenExpiresAt);
                    state.score = Number(message.score) || 0;
"""
if old not in client:
    raise SystemExit("ERROR: ไม่พบ client welcome state block")
client = client.replace(old, new, 1)

old = """                case 'auth_error':
                    console.warn('Game auth:', message.message || message);
                    break;
                case 'server_error':
"""
new = """                case 'auth_refreshed':
                    if (message.serverNow) secureSetServerNow(message.serverNow);
                    secureScheduleAuthRefresh(message.tokenExpiresAt);
                    if (message.entitlements) {
                        secureApplyEntitlements(message.entitlements, null, message.serverNow);
                    }
                    console.log('Game authentication refreshed securely.');
                    break;
                case 'session_replaced':
                    secureSessionWasReplaced = true;
                    secureClearAuthRefreshTimer();
                    alert('บัญชีนี้ถูกเข้าเล่นจากอุปกรณ์หรือแท็บอื่น Session เดิมจึงถูกปิด');
                    secureReturnToMenu();
                    break;
                case 'auth_error':
                    console.warn('Game auth:', message.message || message);
                    break;
                case 'server_error':
"""
if old not in client:
    raise SystemExit("ERROR: ไม่พบ auth_error client case")
client = client.replace(old, new, 1)

old = """                    secureGameReady = false;
                    secureGameSocket = null;
                    secureActionSession = '';
                    secureActionSeq = 0;
                    const intentional = secureIntentionalSockets.has(ws);
                    if (!intentional && state.isPlaying && !secureHandoffInProgress) {
                        alert('การเชื่อมต่อ Game Server หลุด กรุณาเข้าเกมใหม่');
                        secureReturnToMenu();
                    }
"""
new = """                    secureGameReady = false;
                    secureGameSocket = null;
                    secureActionSession = '';
                    secureActionSeq = 0;
                    secureTokenExpiresAt = 0;
                    secureClearAuthRefreshTimer();
                    const intentional = secureIntentionalSockets.has(ws);
                    const replaced = secureSessionWasReplaced;
                    secureSessionWasReplaced = false;
                    if (!intentional && !replaced && state.isPlaying && !secureHandoffInProgress) {
                        alert('การเชื่อมต่อ Game Server หลุด กรุณาเข้าเกมใหม่');
                        secureReturnToMenu();
                    }
"""
if old not in client:
    raise SystemExit("ERROR: ไม่พบ active socket close block")
client = client.replace(old, new, 1)

old = """            secureGameReady = false;
            secureActionSession = '';
            secureActionSeq = 0;
            secureHandoffInProgress = false;
"""
new = """            secureGameReady = false;
            secureActionSession = '';
            secureActionSeq = 0;
            secureTokenExpiresAt = 0;
            secureSessionWasReplaced = false;
            secureClearAuthRefreshTimer();
            secureHandoffInProgress = false;
"""
if old not in client:
    raise SystemExit("ERROR: ไม่พบ secure session connect reset block")
client = client.replace(old, new, 1)

old = """            secureGameReady = false;
            secureHandoffInProgress = false;
            if (secureHandoffResumeTimer) clearTimeout(secureHandoffResumeTimer);
"""
new = """            secureGameReady = false;
            secureActionSession = '';
            secureActionSeq = 0;
            secureTokenExpiresAt = 0;
            secureClearAuthRefreshTimer();
            secureHandoffInProgress = false;
            if (secureHandoffResumeTimer) clearTimeout(secureHandoffResumeTimer);
"""
if old not in client:
    raise SystemExit("ERROR: ไม่พบ secureReturnToMenu reset block")
client = client.replace(old, new, 1)

SERVER.write_text(server, encoding="utf-8")
CLIENT.write_text(client, encoding="utf-8")

print("OK: Phase 4E.4E Session / Authentication Hardening installed")
print("Server backup:", server_backup)
print("Client backup:", client_backup)
print("Auth deadline: 15 seconds")
print("Session policy: one active Firebase UID per game server")
print("Long-session auth: secure Firebase token refresh before expiry")
print("Idle expired sessions: server closes them even without movement packets")
print("NOTE: Run node --check vps/game-server.js before restarting VPS")
