from pathlib import Path
import re
from collections import defaultdict

FILES = [
    ("ACTIVE_CLIENT", Path("index.vps-test-v2.html")),
    ("LEGACY_CLIENT", Path("index.html")),
]

def safe_line(s):
    s = s.strip()
    s = re.sub(r'([A-Za-z0-9_\-]{24,}:[A-Za-z0-9_\-]{20,})', '[REDACTED_CREDENTIAL]', s)
    if len(s) > 260:
        s = s[:257] + "..."
    return s

def scan_file(label, path):
    if not path.exists():
        print(f"\n=== {label}: {path} NOT FOUND ===")
        return

    text = path.read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines()

    print(f"\n=== {label}: {path} ===")

    ref_vars = {}
    ref_hits = []

    assign_rx = re.compile(
        r'(?:const|let|var)?\s*([A-Za-z_$][\w$]*)\s*=\s*database\.ref\s*\((.*?)\)',
        re.I
    )
    direct_rx = re.compile(r'database\.ref\s*\((.*?)\)', re.I)

    for i, line in enumerate(lines, 1):
        m = assign_rx.search(line)
        if m:
            var = m.group(1)
            expr = m.group(2)
            ref_vars[var] = expr
            ref_hits.append((i, var, expr, safe_line(line)))
        elif direct_rx.search(line):
            m2 = direct_rx.search(line)
            ref_hits.append((i, "(direct)", m2.group(1), safe_line(line)))

    print("\n-- Firebase RTDB refs --")
    if not ref_hits:
        print("NONE")
    else:
        for i, var, expr, shown in ref_hits:
            print(f"{path}:{i}  {var} -> {expr}")
            print(f"    {shown}")

    ops = ("set", "update", "remove", "transaction", "push", "on", "once", "off")
    op_counts = defaultdict(int)
    findings = []

    for i, line in enumerate(lines, 1):
        for var, expr in ref_vars.items():
            for op in ops:
                rx = re.compile(rf'\b{re.escape(var)}\.{op}\s*\(', re.I)
                if rx.search(line):
                    op_counts[op] += 1
                    findings.append((i, var, expr, op, safe_line(line)))

        for op in ops:
            if re.search(rf'database\.ref\s*\(.*?\)\s*\.\s*{op}\s*\(', line, re.I):
                op_counts[op] += 1
                findings.append((i, "(direct)", "(direct ref)", op, safe_line(line)))

    print("\n-- Operations on Firebase RTDB refs --")
    if not findings:
        print("NONE")
    else:
        for i, var, expr, op, shown in findings:
            mode = "WRITE" if op in {"set","update","remove","transaction","push"} else "READ/LISTEN"
            print(f"[{mode}] {path}:{i}  {var}.{op}()  ref={expr}")
            print(f"    {shown}")

    print("\n-- Firebase client surface --")
    checks = [
        ("firebase.initializeApp", r'firebase\.initializeApp\s*\('),
        ("firebase.auth", r'firebase\.auth\s*\('),
        ("firebase.database", r'firebase\.database\s*\('),
        ("getIdToken", r'\bgetIdToken\s*\('),
        ("localStorage score/coin/vip/buff", r'localStorage.*(?:score|coin|vip|buff)|(?:score|coin|vip|buff).*localStorage'),
    ]
    for name, rx in checks:
        hits = [i for i,l in enumerate(lines,1) if re.search(rx,l,re.I)]
        print(f"{name}: {len(hits)}" + (f"  lines={hits[:20]}" if hits else ""))

    writes = sum(op_counts[x] for x in ("set","update","remove","transaction","push"))
    reads = sum(op_counts[x] for x in ("on","once","off"))

    print("\n-- Classification --")
    print(f"Firebase ref variables found: {len(ref_vars)}")
    print(f"Firebase WRITE operations tied to those refs: {writes}")
    print(f"Firebase READ/LISTEN operations tied to those refs: {reads}")

    if label == "ACTIVE_CLIENT":
        if writes == 0:
            print("ACTIVE_CLIENT_WRITE_STATUS: PASS_NO_DIRECT_RTDB_WRITES_FOUND")
        else:
            print("ACTIVE_CLIENT_WRITE_STATUS: REVIEW_REQUIRED")
    else:
        if writes > 0:
            print("LEGACY_CLIENT_STATUS: CONTAINS_DIRECT_RTDB_WRITES")
        else:
            print("LEGACY_CLIENT_STATUS: NO_DIRECT_RTDB_WRITES_FOUND")

for label, path in FILES:
    scan_file(label, path)

print("\n=== NEXT SECURITY CHECK ===")
print("This audit only inspects source code in the repo.")
print("Firebase Realtime Database Rules / Firestore Rules must still be checked in Firebase Console.")
print("Do not send secrets or tokens.")
