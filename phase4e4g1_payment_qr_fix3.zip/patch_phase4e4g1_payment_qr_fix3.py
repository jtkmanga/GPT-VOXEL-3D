from pathlib import Path
from datetime import datetime
import shutil

p = Path("worker.js")
if not p.exists():
    raise SystemExit("ERROR: worker.js not found. Run from /workspaces/GPT-VOXEL-3D")

s = p.read_text(encoding="utf-8")
marker = "// PHASE_4E4G1_PAYMENT_QR_FIX3"
if marker in s:
    raise SystemExit("INFO: FIX3 already installed; no changes made.")

old = 'const item = (typeof ITEMS !== "undefined" && ITEMS) ? ITEMS[type] : null;'
anchor = "// PHASE_4E4G1_SECURE_PAYMENT_QR"
if old not in s:
    raise SystemExit("ERROR: expected payment-qr lookup not found; no changes made.")
if anchor not in s:
    raise SystemExit("ERROR: payment QR marker not found; no changes made.")

shared = '''// PHASE_4E4G1_PAYMENT_QR_FIX3
const PHASE4E4G1_QR_ITEMS = Object.freeze({
  speed: Object.freeze({ price: 10 }),
  coin:  Object.freeze({ price: 20 }),
  vip1:  Object.freeze({ price: 50 })
});

'''

backup = Path("worker.before-phase4e4g1-fix3." + datetime.now().strftime("%Y%m%d-%H%M%S") + ".js")
shutil.copy2(p, backup)

s = s.replace(anchor, shared + anchor, 1)
s = s.replace(old, 'const item = PHASE4E4G1_QR_ITEMS[type] || null;', 1)
p.write_text(s, encoding="utf-8")

print("OK: Payment QR FIX3 installed")
print("Backup:", backup)
print("NEXT: node --check worker.js")
print("NEXT: npx wrangler deploy --dry-run")
