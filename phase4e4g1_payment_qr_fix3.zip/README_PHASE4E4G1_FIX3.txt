PHASE 4E.4G1 Payment QR FIX3

Fixes /payment-qr returning 400 Invalid payment item because ITEMS[type] is undefined.

Current prices:
speed = 10 THB
coin = 20 THB
vip1 = 50 THB

Run:
cd /workspaces/GPT-VOXEL-3D
python3 patch_phase4e4g1_payment_qr_fix3.py
node --check worker.js
npx wrangler deploy --dry-run

Do not deploy if either check fails.
