from pathlib import Path
from datetime import datetime
import re

p = Path("index.vps-test-v2.html")
if not p.exists():
    raise SystemExit("ERROR: ไม่พบ index.vps-test-v2.html")

s = p.read_text(encoding="utf-8")

stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
backup = p.with_name(f"index.vps-test-v2.before-phase4e4e-cleanup.{stamp}.html")
backup.write_text(s, encoding="utf-8")

# Remove the temporary event dispatch line added only for the auth-refresh test.
s, event_removed = re.subn(
    r"\n\s*// PHASE_4E4E_AUTH_TEST_HELPER_EVENT\n"
    r"\s*window\.dispatchEvent\(new CustomEvent\('phase4e4e-auth-refreshed', \{ detail: message \}\)\);",
    "",
    s,
    count=1,
)

# Remove the temporary visible test helper block.
s, helper_removed = re.subn(
    r"\s*<!-- PHASE_4E4E_AUTH_TEST_HELPER[\s\S]*?</script>\s*",
    "\n",
    s,
    count=1,
)

if helper_removed != 1:
    raise SystemExit(
        f"ERROR: คาดว่าจะพบ auth test helper 1 block แต่พบ {helper_removed} block"
    )

if event_removed != 1:
    raise SystemExit(
        f"ERROR: คาดว่าจะพบ auth test event 1 จุด แต่พบ {event_removed} จุด"
    )

p.write_text(s, encoding="utf-8")

print("OK: Phase 4E.4E temporary auth test helper removed")
print("Backup:", backup)
print("Core Phase 4E.4E session/auth hardening remains enabled")
