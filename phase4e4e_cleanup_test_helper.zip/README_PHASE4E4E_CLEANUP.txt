Phase 4E.4E Cleanup

Run:
cd /workspaces/GPT-VOXEL-3D
python3 cleanup_phase4e4e_auth_tests.py

Verify temporary test code is gone:
grep -n -E "PHASE_4E4E_AUTH_TEST_HELPER|TEST AUTH REFRESH|TEST UNAUTH 15s|phase4e4e-auth-refreshed"   index.vps-test-v2.html

Expected: no output.

Verify core protection still exists:
grep -n -E "PHASE_4E4E_SESSION_AUTH_HARDENING|AUTH-HARDEN|auth_refresh|session_replaced|tokenExpiresAt"   vps/game-server.js index.vps-test-v2.html | head -160

Expected: output should still be present.

This removes only temporary auth test UI/event code.
