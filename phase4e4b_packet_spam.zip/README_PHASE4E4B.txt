Phase 4E.4B — Packet / Action Spam Protection

Install:
cd /workspaces/GPT-VOXEL-3D
python3 patch_phase4e4b_packet_spam.py

Validate:
node --check vps/game-server.js

grep -n -E "PHASE_4E4B_PACKET_RATE_LIMIT|PHASE4E4B_MAX_PACKETS|phase4e4bAllowAction|rate_limited" \
  vps/game-server.js index.vps-test-v2.html | head -80

Restart VPS with a fresh log:
pkill -f "node vps/game-server.js" || true
rm -f vps/game-server.log

FIREBASE_PROJECT_ID=lucky-game-6936b \
ENTITLEMENTS_BASE=https://voxel-run-v2-demo.hjinffv5426.workers.dev \
nohup node vps/game-server.js > vps/game-server.log 2>&1 &

Check:
curl -s http://127.0.0.1:8080/health ; echo
curl -s http://127.0.0.1:8080/status ; echo

Normal-play test FIRST:
- play for 60 seconds;
- walk continuously;
- cross Zones several times;
- collect 5-10 coins;
- use Lucky Box normally if available.

Then:
grep -n -A 10 "\[ANTI-SPAM\]" vps/game-server.log | tail -100

Expected for normal play:
NO OUTPUT.

If normal play produces [ANTI-SPAM] lines, stop and send a screenshot.
