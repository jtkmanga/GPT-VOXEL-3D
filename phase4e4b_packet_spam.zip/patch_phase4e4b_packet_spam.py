from pathlib import Path
from datetime import datetime
import re

SERVER = Path("vps/game-server.js")
CLIENT = Path("index.vps-test-v2.html")

if not SERVER.exists():
    raise SystemExit("ERROR: ไม่พบ vps/game-server.js")
if not CLIENT.exists():
    raise SystemExit("ERROR: ไม่พบ index.vps-test-v2.html")

server = SERVER.read_text(encoding="utf-8")
client = CLIENT.read_text(encoding="utf-8")

if "PHASE_4E4B_PACKET_RATE_LIMIT" in server:
    print("INFO: Phase 4E.4B already installed")
    raise SystemExit(0)

stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
sb = SERVER.with_name(f"game-server.before-phase4e4b.{stamp}.js")
cb = CLIENT.with_name(f"index.vps-test-v2.before-phase4e4b.{stamp}.html")
sb.write_text(server, encoding="utf-8")
cb.write_text(client, encoding="utf-8")

port_marker = "const PORT = Number(process.env.PORT || 8080);"
if port_marker not in server:
    raise SystemExit("ERROR: ไม่พบ const PORT = Number(process.env.PORT || 8080);")

helpers = """
// PHASE_4E4B_PACKET_RATE_LIMIT
// Server-side WebSocket packet/action rate limiting.
const PHASE4E4B_MAX_MESSAGE_BYTES = 16 * 1024;
const PHASE4E4B_PACKET_WINDOW_MS = 1000;
const PHASE4E4B_MAX_PACKETS_PER_WINDOW = 120;

const PHASE4E4B_ACTION_LIMITS = Object.freeze({
  auth:         { windowMs: 10000, max: 5,  kickAfter: 10 },
  move:         { windowMs: 1000,  max: 30, kickAfter: 20 },
  coin_collect: { windowMs: 1000,  max: 8,  kickAfter: 16 },
  collect_box:  { windowMs: 2000,  max: 4,  kickAfter: 10 },
  spin_box:     { windowMs: 5000,  max: 3,  kickAfter: 8 }
});

function phase4e4bRawSize(raw) {
  try {
    if (typeof raw === 'string') return Buffer.byteLength(raw, 'utf8');
    if (Buffer.isBuffer(raw)) return raw.length;
    if (raw?.byteLength != null) return Number(raw.byteLength) || 0;
    return Buffer.byteLength(String(raw ?? ''), 'utf8');
  } catch (_) {
    return PHASE4E4B_MAX_MESSAGE_BYTES + 1;
  }
}

function phase4e4bClose(ws, code, reason) {
  try {
    if (ws && ws.readyState === WebSocket.OPEN) ws.close(code, reason);
  } catch (_) {}
}

function phase4e4bSendRateLimited(ws, action, retryAfterMs) {
  try {
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({
        type: 'rate_limited',
        action,
        retryAfterMs: Math.max(0, Math.ceil(Number(retryAfterMs) || 0)),
        serverNow: Date.now()
      }));
    }
  } catch (_) {}
}

function phase4e4bAllowPacket(ws, raw) {
  const now = Date.now();
  const size = phase4e4bRawSize(raw);

  if (size > PHASE4E4B_MAX_MESSAGE_BYTES) {
    console.warn('[ANTI-SPAM] oversized websocket message', { size });
    phase4e4bClose(ws, 1009, 'Message too large');
    return false;
  }

  let state = ws.__phase4e4bPacketState;
  if (!state || now - state.startedAt >= PHASE4E4B_PACKET_WINDOW_MS) {
    state = { startedAt: now, count: 0 };
    ws.__phase4e4bPacketState = state;
  }

  state.count += 1;

  if (state.count > PHASE4E4B_MAX_PACKETS_PER_WINDOW) {
    if (state.count === PHASE4E4B_MAX_PACKETS_PER_WINDOW + 1) {
      console.warn('[ANTI-SPAM] websocket packet flood', {
        count: state.count,
        windowMs: PHASE4E4B_PACKET_WINDOW_MS
      });
      phase4e4bSendRateLimited(
        ws,
        'packet',
        PHASE4E4B_PACKET_WINDOW_MS - (now - state.startedAt)
      );
    }
    phase4e4bClose(ws, 1008, 'Packet rate limit exceeded');
    return false;
  }

  return true;
}

function phase4e4bAllowAction(ws, player, action) {
  const cfg = PHASE4E4B_ACTION_LIMITS[action];
  if (!cfg) return true;

  const now = Date.now();
  const holder = player || ws;

  if (!holder.__phase4e4bActions) {
    holder.__phase4e4bActions = Object.create(null);
  }

  let state = holder.__phase4e4bActions[action];

  if (!state || now - state.startedAt >= cfg.windowMs) {
    state = {
      startedAt: now,
      count: 0,
      rejected: Math.max(0, Number(state?.rejected || 0) - 2),
      notified: false
    };
    holder.__phase4e4bActions[action] = state;
  }

  state.count += 1;

  if (state.count <= cfg.max) return true;

  state.rejected += 1;

  if (!state.notified) {
    state.notified = true;
    const retryAfterMs = cfg.windowMs - (now - state.startedAt);

    console.warn('[ANTI-SPAM] action rate limited', {
      uid: player?.uid || null,
      nickname: player?.nickname || null,
      action,
      count: state.count,
      max: cfg.max,
      windowMs: cfg.windowMs,
      rejected: state.rejected
    });

    phase4e4bSendRateLimited(ws, action, retryAfterMs);
  }

  if (state.rejected >= cfg.kickAfter) {
    console.warn('[ANTI-SPAM] repeated action spam - disconnecting', {
      uid: player?.uid || null,
      nickname: player?.nickname || null,
      action,
      rejected: state.rejected
    });
    phase4e4bClose(ws, 1008, 'Action rate limit exceeded');
  }

  return false;
}
"""

server = server.replace(port_marker, port_marker + "\n" + helpers, 1)

message_rx = re.compile(
    r"""ws\.on\(\s*['"]message['"]\s*,\s*
        (?:async\s*)?
        (?:
            \(\s*([A-Za-z_$][\w$]*)[^)]*\)
            |
            ([A-Za-z_$][\w$]*)
        )
        \s*=>\s*\{
    """,
    re.X,
)
m = message_rx.search(server)
if not m:
    raise SystemExit("ERROR: ไม่พบ ws.on('message', ...) ใน vps/game-server.js")

raw_var = m.group(1) or m.group(2)
insert_at = m.end()
server = server[:insert_at] + f"\n    if (!phase4e4bAllowPacket(ws, {raw_var})) return;\n" + server[insert_at:]

def inject_action_guard(text, action, required=False):
    for marker in (f"if (msg.type === '{action}') {{", f'if (msg.type === "{action}") {{'):
        if marker in text:
            replacement = marker + f"\n      if (!phase4e4bAllowAction(ws, player, '{action}')) return;"
            return text.replace(marker, replacement, 1), True
    if required:
        raise SystemExit(f"ERROR: ไม่พบ handler ของ {action}")
    return text, False

installed = []
for action, required in [
    ("auth", False),
    ("coin_collect", True),
    ("collect_box", False),
    ("spin_box", False),
    ("move", True),
]:
    server, found = inject_action_guard(server, action, required)
    if found:
        installed.append(action)

if "case 'rate_limited':" not in client:
    idx = -1
    for marker in ("case 'movement_correction':", "case 'zone_change':", "case 'box_state':"):
        idx = client.find(marker)
        if idx >= 0:
            break

    if idx < 0:
        raise SystemExit("ERROR: ไม่พบตำแหน่งสำหรับเพิ่ม case 'rate_limited' ใน client")

    client_case = """case 'rate_limited': {
          console.warn(
            'Server rate limit:',
            message.action || 'packet',
            'retryAfterMs:',
            Number(message.retryAfterMs || 0)
          );
          break;
        }

        """
    client = client[:idx] + client_case + client[idx:]

SERVER.write_text(server, encoding="utf-8")
CLIENT.write_text(client, encoding="utf-8")

print("OK: Phase 4E.4B Packet / Action Spam protection installed")
print("Server backup:", sb)
print("Client backup:", cb)
print("Protected handlers:", ", ".join(installed))
print("Global packet limit: 120 packets / second")
print("Max WebSocket message: 16 KiB")
print("Move: 30 / sec")
print("Coin collect: 8 / sec")
print("Lucky Box collect: 4 / 2 sec (if handler exists)")
print("Lucky Box spin: 3 / 5 sec (if handler exists)")
