Phase 4E.4B — Global Packet Flood Test

Install:
cd /workspaces/GPT-VOXEL-3D
python3 patch_phase4e4b_packet_flood_test.py

Verify:
grep -n "PHASE_4E4B_PACKET_FLOOD_TEST" index.vps-test-v2.html

Open:
https://<PORT-3000-HOST>/index.vps-test-v2.html?antispam_test=1

Test:
1. Enter Free Server.
2. Stand still about 3 seconds.
3. Tap TEST PACKET FLOOD x150 exactly once.
4. The server should close the WebSocket when packet 121 exceeds the global
   120 packets/second limit.

Check:
grep -n -A 10 "\[ANTI-SPAM\]" vps/game-server.log | tail -80

Expected:
[ANTI-SPAM] websocket packet flood
count: 121
windowMs: 1000

A Game Server disconnect is EXPECTED for this controlled attack test.
