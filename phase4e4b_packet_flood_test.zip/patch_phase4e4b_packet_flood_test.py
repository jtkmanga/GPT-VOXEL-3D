from pathlib import Path
from datetime import datetime

p = Path("index.vps-test-v2.html")
if not p.exists():
    raise SystemExit("ERROR: ไม่พบ index.vps-test-v2.html")

s = p.read_text(encoding="utf-8")

if "PHASE_4E4B_PACKET_FLOOD_TEST" in s:
    print("INFO: Packet flood test already installed")
    raise SystemExit(0)

stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
backup = p.with_name(f"index.vps-test-v2.before-packet-flood-test.{stamp}.html")
backup.write_text(s, encoding="utf-8")

marker = "</body>"
if marker not in s:
    raise SystemExit("ERROR: ไม่พบ </body>")

snippet = r'''
<!-- PHASE_4E4B_PACKET_FLOOD_TEST
     Temporary controlled global packet-flood test.
     Visible only with ?antispam_test=1.
     Remove before production. -->
<script>
(() => {
  const params = new URLSearchParams(location.search);
  if (params.get('antispam_test') !== '1') return;

  window.addEventListener('load', () => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.textContent = 'TEST PACKET FLOOD x150';
    btn.style.cssText =
      'position:fixed;right:12px;bottom:145px;z-index:100001;' +
      'background:#7f1d1d;color:#fff;border:2px solid #fff;' +
      'padding:10px 12px;border-radius:10px;font-weight:700;';

    btn.addEventListener('click', () => {
      try {
        if (
          !secureGameSocket ||
          secureGameSocket.readyState !== WebSocket.OPEN ||
          !secureGameReady
        ) {
          alert('Game Server ยังไม่พร้อม');
          return;
        }

        for (let i = 0; i < 150; i++) {
          secureGameSocket.send(JSON.stringify({
            type: 'phase4e4b_packet_probe',
            n: i
          }));
        }

        console.warn('[TEST] Sent 150 packet flood probes');
      } catch (err) {
        console.error(err);
        alert('TEST ERROR: ' + (err?.message || err));
      }
    });

    document.body.appendChild(btn);
  });
})();
</script>
'''

s = s.replace(marker, snippet + "\n" + marker, 1)
p.write_text(s, encoding="utf-8")

print("OK: Phase 4E.4B packet flood test installed")
print("Backup:", backup)
print("Open with ?antispam_test=1")
print("Button: TEST PACKET FLOOD x150")
