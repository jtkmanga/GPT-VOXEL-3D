Phase 4E.4A — Cleanup temporary Anti-Cheat test buttons

Run:
cd /workspaces/GPT-VOXEL-3D
python3 cleanup_phase4e4a_test_helpers.py

Verify the temporary helpers are gone:
grep -n -E "PHASE_4E4A_(TELEPORT|SPEED)_TEST_BUTTON|TEST TELEPORT|TEST SPEED"   index.vps-test-v2.html

Expected: no output.

The real VPS anti-cheat in vps/game-server.js is NOT removed.
