#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import re, sys, shutil

CLIENT = Path("index.vps-test-v2.html")
WORKER = Path("worker.js")
MARKER = "PHASE_4E4G1_SECURE_PAYMENT_QR"

for p in (CLIENT, WORKER):
    if not p.exists():
        raise SystemExit(f"ERROR: missing {p}")

stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
client_backup = CLIENT.with_name(f"{CLIENT.stem}.before-phase4e4g1.{stamp}{CLIENT.suffix}")
worker_backup = WORKER.with_name(f"{WORKER.stem}.before-phase4e4g1.{stamp}{WORKER.suffix}")
shutil.copy2(CLIENT, client_backup)
shutil.copy2(WORKER, worker_backup)

client = CLIENT.read_text(encoding="utf-8", errors="replace")
worker = WORKER.read_text(encoding="utf-8", errors="replace")

if MARKER in client or MARKER in worker:
    print("INFO: Phase 4E.4G1 already appears installed; nothing changed.")
    sys.exit(0)

# ---------- Client ----------
client = re.sub(
    r'^\s*const\s+SECURE_PAYMENT_PROMPTPAY_TARGET\s*=\s*["\']0999999999["\'];[^\n]*\n',
    "        // PHASE_4E4G1_SECURE_PAYMENT_QR: receiver account is kept on the Worker only.\n",
    client,
    count=1,
    flags=re.M
)

client = re.sub(
    r'^\s*const\s+promptpayTarget\s*=\s*["\']0999999999["\'];[^\n]*\n',
    "            // PHASE_4E4G1_SECURE_PAYMENT_QR: no PromptPay receiver is stored in client code.\n",
    client,
    count=1,
    flags=re.M
)

secure_qr_rx = re.compile(
    r'document\.getElementById\([\'"]promptpay-qr-img[\'"]\)\.src\s*=\s*'
    r'`https://promptpay\.io/\$\{SECURE_PAYMENT_PROMPTPAY_TARGET\}/\$\{cfg\.price\}\.png`;'
)
client, n_secure = secure_qr_rx.subn(
    "document.getElementById('promptpay-qr-img').src = "
    "SECURE_WORKER_HTTP_BASE + '/payment-qr?type=' + encodeURIComponent(type) + '&v=' + Date.now();",
    client,
    count=1
)

legacy_qr_rx = re.compile(
    r'document\.getElementById\([\'"]promptpay-qr-img[\'"]\)\.src\s*=\s*'
    r'`https://promptpay\.io/\$\{promptpayTarget\}/\$\{price\}\.png`;'
)
client, n_legacy = legacy_qr_rx.subn(
    "document.getElementById('promptpay-qr-img').src = "
    "SECURE_WORKER_HTTP_BASE + '/payment-qr?type=' + encodeURIComponent(type) + '&v=' + Date.now();",
    client,
    count=1
)

if "0999999999" in client:
    raise SystemExit(
        "ERROR: placeholder 0999999999 still exists in client after patch. "
        "Backups were created; active files were NOT written."
    )

if n_secure != 1:
    raise SystemExit(
        "ERROR: secure PromptPay QR line not found exactly once. "
        "Backups were created; active files were NOT written."
    )

# ---------- Worker ----------
helper = r'''
// PHASE_4E4G1_SECURE_PAYMENT_QR
// The client never stores the PromptPay receiver identifier.
// Price is selected only from the trusted server-side ITEMS table.
async function phase4e4g1PaymentQr(request, env) {
  const url = new URL(request.url);
  const type = String(url.searchParams.get("type") || "");
  const item = (typeof ITEMS !== "undefined" && ITEMS) ? ITEMS[type] : null;

  if (!item || !Number.isFinite(Number(item.price))) {
    return new Response(JSON.stringify({ ok:false, error:"Invalid payment item" }), {
      status: 400,
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        "Cache-Control": "no-store"
      }
    });
  }

  const receiver = String(
    env.PAYMENT_RECEIVER_ACCOUNT ||
    env.PROMPTPAY_TARGET ||
    ""
  ).trim();

  if (!receiver) {
    console.error("[PAYMENT-QR] receiver environment variable is not configured");
    return new Response(JSON.stringify({ ok:false, error:"Payment receiver not configured" }), {
      status: 503,
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        "Cache-Control": "no-store"
      }
    });
  }

  const price = Number(item.price);
  const qrUrl =
    "https://promptpay.io/" +
    encodeURIComponent(receiver) +
    "/" +
    encodeURIComponent(String(price)) +
    ".png";

  let upstream;
  try {
    upstream = await fetch(qrUrl, {
      method: "GET",
      headers: { "Accept": "image/png,image/*;q=0.9,*/*;q=0.1" }
    });
  } catch (err) {
    console.error("[PAYMENT-QR] upstream fetch failed");
    return new Response(JSON.stringify({ ok:false, error:"QR provider unavailable" }), {
      status: 502,
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        "Cache-Control": "no-store"
      }
    });
  }

  if (!upstream.ok) {
    console.error("[PAYMENT-QR] upstream status", upstream.status);
    return new Response(JSON.stringify({ ok:false, error:"QR provider rejected request" }), {
      status: 502,
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        "Cache-Control": "no-store"
      }
    });
  }

  const contentType = upstream.headers.get("Content-Type") || "image/png";
  if (!contentType.toLowerCase().startsWith("image/")) {
    return new Response(JSON.stringify({ ok:false, error:"Invalid QR response" }), {
      status: 502,
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        "Cache-Control": "no-store"
      }
    });
  }

  return new Response(upstream.body, {
    status: 200,
    headers: {
      "Content-Type": contentType,
      "Cache-Control": "private, no-store, max-age=0",
      "Pragma": "no-cache",
      "X-Content-Type-Options": "nosniff",
      "Referrer-Policy": "no-referrer"
    }
  });
}

'''

export_pos = worker.find("export default")
if export_pos < 0:
    raise SystemExit("ERROR: export default not found in worker.js; active files were NOT written.")
worker = worker[:export_pos] + helper + worker[export_pos:]

verify_pos = worker.find("/verify-slip")
if verify_pos < 0:
    raise SystemExit("ERROR: /verify-slip route not found in worker.js; active files were NOT written.")

prefix = worker[:verify_pos]
matches = list(re.finditer(r'const\s+url\s*=\s*new\s+URL\s*\(\s*request\.url\s*\)\s*;', prefix))
if not matches:
    raise SystemExit("ERROR: public URL parser not found before /verify-slip; active files were NOT written.")

m = matches[-1]
insert_at = m.end()
route = r'''

    // PHASE_4E4G1_SECURE_PAYMENT_QR
    if (request.method === "GET" && url.pathname === "/payment-qr") {
      return phase4e4g1PaymentQr(request, env);
    }
'''
worker = worker[:insert_at] + route + worker[insert_at:]

if worker.count("PHASE_4E4G1_SECURE_PAYMENT_QR") < 2:
    raise SystemExit("ERROR: worker marker sanity check failed; active files were NOT written.")
if "/payment-qr" not in worker:
    raise SystemExit("ERROR: payment-qr route missing after patch; active files were NOT written.")

CLIENT.write_text(client, encoding="utf-8")
WORKER.write_text(worker, encoding="utf-8")

print("OK: Phase 4E.4G1 secure payment QR installed")
print(f"Client backup: {client_backup}")
print(f"Worker backup: {worker_backup}")
print("Changes:")
print(" - removed hard-coded 0999999999 from active client")
print(" - client loads PromptPay QR from Worker /payment-qr?type=...")
print(" - Worker uses server-side ITEMS price + receiver env var")
print(" - receiver identifier is no longer stored in active HTML")
print("")
print("NEXT:")
print("  node --check worker.js")
print("  grep -n \"0999999999\\|PHASE_4E4G1_SECURE_PAYMENT_QR\\|/payment-qr\" index.vps-test-v2.html worker.js | head -80")
print("  python3 audit_phase4e4g_payment_security.py | tail -80")
