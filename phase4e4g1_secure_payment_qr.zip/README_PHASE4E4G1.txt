Phase 4E.4G1 — Secure Payment QR

Purpose
- Remove the hard-coded PromptPay placeholder 0999999999 from the active client.
- Keep the receiver identifier on the Cloudflare Worker.
- Keep item prices server-authoritative via the Worker ITEMS table.
- Add GET /payment-qr?type=speed|coin|vip1.

Install:

cd /workspaces/GPT-VOXEL-3D

git fetch origin
git checkout origin/main -- phase4e4g1_secure_payment_qr.zip
unzip -o phase4e4g1_secure_payment_qr.zip

python3 patch_phase4e4g1_secure_payment_qr.py

Validate:

node --check worker.js

grep -n "0999999999\|PHASE_4E4G1_SECURE_PAYMENT_QR\|/payment-qr" \
  index.vps-test-v2.html worker.js | head -80

python3 audit_phase4e4g_payment_security.py | tail -80

If node --check succeeds and 0999999999 does not appear in index.vps-test-v2.html:

npx wrangler deploy

Then test:

curl -s -o /tmp/payment-qr.png -w "%{http_code} %{content_type}\n" \
  "https://voxel-run-v2-demo.hjinffv5426.workers.dev/payment-qr?type=speed"

Expected:
200 image/png
(or another image/* content type)

Finally open the game payment modal and verify the QR image renders.

IMPORTANT
- Do not send PromptPay receiver/account numbers, API secrets, or tokens in chat.
- If /payment-qr returns 503 "Payment receiver not configured", do not put the
  receiver number in HTML. Configure it as a Cloudflare Worker secret instead.
