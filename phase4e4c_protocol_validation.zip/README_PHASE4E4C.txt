Phase 4E.4C — Malformed Packet / Protocol Validation

ติดตั้ง:
cd /workspaces/GPT-VOXEL-3D

git fetch origin
git checkout origin/main -- phase4e4c_protocol_validation.zip
unzip -o phase4e4c_protocol_validation.zip

python3 patch_phase4e4c_protocol_validation.py

ตรวจ syntax:
node --check vps/game-server.js

grep -n -E "PHASE_4E4C_PROTOCOL_VALIDATION|phase4e4cParseMessage|ANTI-PROTOCOL|protocol_error" \
  vps/game-server.js index.vps-test-v2.html | head -100

Restart VPS พร้อม log ใหม่:
pkill -f "node vps/game-server.js" || true
rm -f vps/game-server.log

FIREBASE_PROJECT_ID=lucky-game-6936b \
ENTITLEMENTS_BASE=https://voxel-run-v2-demo.hjinffv5426.workers.dev \
nohup node vps/game-server.js > vps/game-server.log 2>&1 &

ตรวจ Server:
curl -s http://127.0.0.1:8080/health ; echo
curl -s http://127.0.0.1:8080/status ; echo

Normal Play Test ก่อน:
- เล่นปกติประมาณ 60 วินาที
- เดินต่อเนื่อง
- ข้าม Zone หลายครั้ง
- เก็บเหรียญ 5-10 เหรียญ
- ถ้ากล่องพร้อม ให้เก็บและหมุนตามปกติ

จากนั้น:
grep -n -A 10 "\[ANTI-PROTOCOL\]" vps/game-server.log | tail -100

ผลที่ต้องการ:
ไม่มี output

ถ้ามี [ANTI-PROTOCOL] ระหว่างการเล่นปกติ ให้หยุดก่อนและส่งภาพ Terminal มา
ยังไม่ต้องทำ Malformed Packet Attack Test จนกว่า Normal Play จะผ่าน
