from pathlib import Path
from datetime import datetime
import re
import json

SERVER = Path("vps/game-server.js")
CLIENT = Path("index.vps-test-v2.html")

if not SERVER.exists():
    raise SystemExit("ERROR: ไม่พบ vps/game-server.js")
if not CLIENT.exists():
    raise SystemExit("ERROR: ไม่พบ index.vps-test-v2.html")

server = SERVER.read_text(encoding="utf-8")
client = CLIENT.read_text(encoding="utf-8")

if "PHASE_4E4C_PROTOCOL_VALIDATION" in server:
    print("INFO: Phase 4E.4C already installed")
    raise SystemExit(0)

if "PHASE_4E4B_PACKET_RATE_LIMIT" not in server:
    raise SystemExit(
        "ERROR: ไม่พบ Phase 4E.4B ใน vps/game-server.js "
        "กรุณาใช้ไฟล์ Server ล่าสุดก่อน"
    )

stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
sb = SERVER.with_name(f"game-server.before-phase4e4c.{stamp}.js")
cb = CLIENT.with_name(f"index.vps-test-v2.before-phase4e4c.{stamp}.html")
sb.write_text(server, encoding="utf-8")
cb.write_text(client, encoding="utf-8")

types = set(re.findall(
    r"""msg\.type\s*={2,3}\s*['"]([A-Za-z0-9_:\-]+)['"]""",
    server
))
types.update(re.findall(
    r"""case\s+['"]([A-Za-z0-9_:\-]+)['"]\s*:""",
    server
))
types.update({"auth", "move", "coin_collect", "collect_box", "spin_box"})

allowed_types = sorted(types)
allowed_js = json.dumps(allowed_types, ensure_ascii=False)

marker = "// PHASE_4E4B_PACKET_RATE_LIMIT"
marker_pos = server.find(marker)
if marker_pos < 0:
    raise SystemExit("ERROR: ไม่พบตำแหน่ง Phase 4E.4B marker")

helpers = f"""
// PHASE_4E4C_PROTOCOL_VALIDATION
// Reject malformed / unexpected WebSocket protocol messages before gameplay
// handlers touch them. The VPS remains authoritative.
const PHASE4E4C_ALLOWED_TYPES = new Set({allowed_js});
const PHASE4E4C_MAX_KEYS = 24;
const PHASE4E4C_MAX_TYPE_LENGTH = 48;
const PHASE4E4C_MAX_STRING_LENGTH = 8192;
const PHASE4E4C_MAX_VIOLATIONS = 5;
const PHASE4E4C_DECAY_MS = 30000;

function phase4e4cIsPlainObject(value) {{
  return (
    value !== null &&
    typeof value === 'object' &&
    !Array.isArray(value) &&
    (Object.getPrototypeOf(value) === Object.prototype ||
      Object.getPrototypeOf(value) === null)
  );
}}

function phase4e4cFiniteNumber(value) {{
  return typeof value === 'number' && Number.isFinite(value);
}}

function phase4e4cValidateMessage(msg) {{
  if (!phase4e4cIsPlainObject(msg)) return 'NOT_OBJECT';

  const keys = Object.keys(msg);
  if (keys.length === 0 || keys.length > PHASE4E4C_MAX_KEYS) {{
    return 'BAD_KEY_COUNT';
  }}

  if (
    typeof msg.type !== 'string' ||
    msg.type.length < 1 ||
    msg.type.length > PHASE4E4C_MAX_TYPE_LENGTH ||
    !/^[a-z0-9_:\\-]+$/i.test(msg.type)
  ) {{
    return 'BAD_TYPE';
  }}

  if (!PHASE4E4C_ALLOWED_TYPES.has(msg.type)) {{
    return 'UNKNOWN_TYPE';
  }}

  for (const key of keys) {{
    const value = msg[key];
    if (
      typeof value === 'string' &&
      value.length > PHASE4E4C_MAX_STRING_LENGTH
    ) {{
      return 'STRING_TOO_LONG';
    }}
  }}

  if (msg.type === 'auth') {{
    if (
      typeof msg.token !== 'string' ||
      msg.token.length < 20 ||
      msg.token.length > PHASE4E4C_MAX_STRING_LENGTH
    ) {{
      return 'BAD_AUTH_TOKEN';
    }}

    if (
      msg.nickname !== undefined &&
      (typeof msg.nickname !== 'string' ||
        msg.nickname.length < 1 ||
        msg.nickname.length > 40)
    ) {{
      return 'BAD_NICKNAME';
    }}
  }}

  if (msg.type === 'move') {{
    if (
      !phase4e4cFiniteNumber(msg.x) ||
      !phase4e4cFiniteNumber(msg.y) ||
      !phase4e4cFiniteNumber(msg.z) ||
      !phase4e4cFiniteNumber(msg.r)
    ) {{
      return 'BAD_MOVE_NUMBER';
    }}

    if (
      Math.abs(msg.x) > 5000 ||
      Math.abs(msg.z) > 5000 ||
      msg.y < -1000 ||
      msg.y > 1000 ||
      Math.abs(msg.r) > 100000
    ) {{
      return 'BAD_MOVE_RANGE';
    }}
  }}

  if (msg.type === 'coin_collect') {{
    if (!Number.isInteger(msg.id) || msg.id < 0 || msg.id > 100000) {{
      return 'BAD_COIN_ID';
    }}

    for (const key of ['x', 'y', 'z', 'r']) {{
      if (msg[key] !== undefined && !phase4e4cFiniteNumber(msg[key])) {{
        return 'BAD_COIN_POSITION';
      }}
    }}
  }}

  if (msg.type === 'collect_box' || msg.type === 'spin_box') {{
    const forbidden = [
      'reward', 'score', 'amount', 'coins',
      'respawnAt', 'nextSpawnTimestamp',
      'winner', 'owner', 'uid'
    ];
    if (forbidden.some((key) => Object.prototype.hasOwnProperty.call(msg, key))) {{
      return 'FORBIDDEN_BOX_FIELD';
    }}
  }}

  return null;
}}

function phase4e4cReject(ws, player, reason) {{
  const now = Date.now();

  let state = ws.__phase4e4cProtocolState;
  if (!state) {{
    state = {{ violations: 0, lastAt: now }};
    ws.__phase4e4cProtocolState = state;
  }}

  if (now - state.lastAt >= PHASE4E4C_DECAY_MS) {{
    state.violations = Math.max(0, Number(state.violations || 0) - 2);
  }}

  state.lastAt = now;
  state.violations = Number(state.violations || 0) + 1;

  console.warn('[ANTI-PROTOCOL] rejected malformed packet', {{
    uid: player?.uid || null,
    nickname: player?.nickname || null,
    reason,
    violations: state.violations
  }});

  try {{
    if (ws?.readyState === WebSocket.OPEN) {{
      ws.send(JSON.stringify({{
        type: 'protocol_error',
        code: 'INVALID_MESSAGE',
        serverNow: now
      }}));
    }}
  }} catch (_) {{}}

  if (state.violations >= PHASE4E4C_MAX_VIOLATIONS) {{
    console.warn('[ANTI-PROTOCOL] repeated malformed packets - disconnecting', {{
      uid: player?.uid || null,
      nickname: player?.nickname || null,
      violations: state.violations
    }});
    try {{
      if (ws?.readyState === WebSocket.OPEN) {{
        ws.close(1008, 'Protocol violation');
      }}
    }} catch (_) {{}}
  }}

  return null;
}}

function phase4e4cParseMessage(ws, player, rawText) {{
  let msg;

  try {{
    msg = JSON.parse(rawText);
  }} catch (_) {{
    return phase4e4cReject(ws, player, 'INVALID_JSON');
  }}

  const reason = phase4e4cValidateMessage(msg);
  if (reason) {{
    return phase4e4cReject(ws, player, reason);
  }}

  return msg;
}}
"""

server = server[:marker_pos] + helpers + "\n" + server[marker_pos:]

message_start_candidates = [
    server.find("ws.on('message'"),
    server.find('ws.on("message"')
]
message_start_candidates = [x for x in message_start_candidates if x >= 0]
if not message_start_candidates:
    raise SystemExit("ERROR: ไม่พบ ws.on('message', ...)")

message_start = min(message_start_candidates)

close_candidates = [
    server.find("ws.on('close'", message_start),
    server.find('ws.on("close"', message_start)
]
close_candidates = [x for x in close_candidates if x >= 0]
message_end = min(close_candidates) if close_candidates else min(len(server), message_start + 12000)

segment = server[message_start:message_end]

parse_rx = re.compile(
    r"""(?P<prefix>\bmsg\s*=\s*)JSON\.parse\((?P<expr>[^;\n]+)\);"""
)
m = parse_rx.search(segment)
if not m:
    raise SystemExit(
        "ERROR: ไม่พบรูปแบบ msg = JSON.parse(...) ภายใน WebSocket message handler "
        "จึงยังไม่ได้แก้ไฟล์"
    )

replacement = (
    m.group("prefix")
    + "phase4e4cParseMessage(ws, player, "
    + m.group("expr")
    + ");\n"
    + "      if (!msg) return;"
)

segment = segment[:m.start()] + replacement + segment[m.end():]
server = server[:message_start] + segment + server[message_end:]

if "case 'protocol_error':" not in client:
    idx = client.find("case 'rate_limited':")
    if idx < 0:
        idx = client.find("case 'movement_correction':")
    if idx < 0:
        idx = client.find("case 'zone_change':")
    if idx < 0:
        raise SystemExit(
            "ERROR: ไม่พบตำแหน่งสำหรับเพิ่ม protocol_error ใน client"
        )

    client_case = """case 'protocol_error': {
          console.warn('Server rejected an invalid protocol message.');
          break;
        }

        """
    client = client[:idx] + client_case + client[idx:]

SERVER.write_text(server, encoding="utf-8")
CLIENT.write_text(client, encoding="utf-8")

print("OK: Phase 4E.4C Malformed Packet / Protocol Validation installed")
print("Server backup:", sb)
print("Client backup:", cb)
print("Allowed protocol types:", ", ".join(allowed_types))
print("Malformed-packet disconnect threshold: 5")
print("NOTE: Run node --check before restarting VPS")
