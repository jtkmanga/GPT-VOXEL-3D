Phase 4E.4C — Controlled Malformed Packet Test

Install:
cd /workspaces/GPT-VOXEL-3D
python3 patch_phase4e4c_malformed_test.py

Verify:
grep -n "PHASE_4E4C_MALFORMED_PACKET_TEST" index.vps-test-v2.html

Open:
https://<PORT-3000-HOST>/index.vps-test-v2.html?protocol_test=1

Test:
1. เข้า Free Server ตามปกติ
2. ยืนนิ่งประมาณ 3 วินาที
3. กด TEST MALFORMED x5 เพียง 1 ครั้ง
4. ระบบจะส่ง malformed packet 5 แบบ โดยเว้นช่วง 180ms:
   - INVALID_JSON
   - NOT_OBJECT
   - UNKNOWN_TYPE
   - BAD_MOVE_NUMBER
   - FORBIDDEN_BOX_FIELD

Expected:
- เกมไม่ crash
- score ไม่เพิ่ม
- Lucky Box reward ไม่ถูกปลอม
- VPS log มี [ANTI-PROTOCOL]
- violations ไล่ 1 ถึง 5
- ที่ violation 5 มี:
  [ANTI-PROTOCOL] repeated malformed packets - disconnecting
- WebSocket หลุด/กลับหน้า Server เป็นผลที่คาดไว้

Check:
grep -n -A 8 "\[ANTI-PROTOCOL\]" vps/game-server.log | tail -120

หากเห็นเหตุผลทั้ง 5 และ disconnect ที่ violations: 5 ถือว่าผ่าน Phase 4E.4C Attack Test

หมายเหตุ:
ปุ่มนี้เป็น test helper ชั่วคราว ต้องลบก่อน production
