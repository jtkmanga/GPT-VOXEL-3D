from pathlib import Path
from datetime import datetime

p = Path("index.vps-test-v2.html")
if not p.exists():
    raise SystemExit("ERROR: ไม่พบ index.vps-test-v2.html")

s = p.read_text(encoding="utf-8")

if "PHASE_4E4C_MALFORMED_PACKET_TEST" in s:
    print("INFO: Phase 4E.4C malformed-packet test already installed")
    raise SystemExit(0)

stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
backup = p.with_name(f"index.vps-test-v2.before-phase4e4c-test.{stamp}.html")
backup.write_text(s, encoding="utf-8")

marker = "</body>"
if marker not in s:
    raise SystemExit("ERROR: ไม่พบ </body>")

snippet = r'''
<!-- PHASE_4E4C_MALFORMED_PACKET_TEST
     Temporary controlled protocol-validation test.
     Visible only with ?protocol_test=1.
     Remove before production. -->
<script>
(() => {
  const params = new URLSearchParams(location.search);
  if (params.get('protocol_test') !== '1') return;

  window.addEventListener('load', () => {
    const wrap = document.createElement('div');
    wrap.style.cssText =
      'position:fixed;right:12px;bottom:92px;z-index:100002;' +
      'display:flex;flex-direction:column;gap:7px;align-items:flex-end;';

    const status = document.createElement('div');
    status.textContent = 'Protocol test ready';
    status.style.cssText =
      'background:#111;color:#fff;padding:7px 10px;border-radius:8px;' +
      'font:12px sans-serif;max-width:280px;';

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.textContent = 'TEST MALFORMED x5';
    btn.style.cssText =
      'background:#7c3aed;color:#fff;border:2px solid #fff;' +
      'padding:10px 12px;border-radius:10px;font-weight:700;';

    btn.addEventListener('click', async () => {
      try {
        if (
          !secureGameSocket ||
          secureGameSocket.readyState !== WebSocket.OPEN ||
          !secureGameReady
        ) {
          status.textContent = 'Game Server ยังไม่พร้อม';
          return;
        }

        btn.disabled = true;
        status.textContent = 'กำลังส่ง malformed packet 5 แบบ...';

        const tests = [
          '{"type":',
          '["not","an","object"]',
          JSON.stringify({
            type: 'totally_fake_protocol_message'
          }),
          JSON.stringify({
            type: 'move',
            x: 'NaN',
            y: 0,
            z: 0,
            r: 0
          }),
          JSON.stringify({
            type: 'spin_box',
            reward: 9999,
            score: 999999
          })
        ];

        for (let i = 0; i < tests.length; i++) {
          if (
            !secureGameSocket ||
            secureGameSocket.readyState !== WebSocket.OPEN
          ) break;

          secureGameSocket.send(tests[i]);
          console.warn('[TEST] malformed packet', i + 1);
          await new Promise(resolve => setTimeout(resolve, 180));
        }

        status.textContent =
          'ส่งครบแล้ว — VPS ควรบันทึก ANTI-PROTOCOL และ disconnect ที่ violation 5';
      } catch (err) {
        status.textContent = 'TEST ERROR: ' + (err?.message || err);
        console.error(err);
      } finally {
        setTimeout(() => { btn.disabled = false; }, 3000);
      }
    });

    wrap.append(status, btn);
    document.body.appendChild(wrap);
  });
})();
</script>
'''

s = s.replace(marker, snippet + "\n" + marker, 1)
p.write_text(s, encoding="utf-8")

print("OK: Phase 4E.4C controlled malformed-packet test installed")
print("Backup:", backup)
print("Open with ?protocol_test=1")
print("Button: TEST MALFORMED x5")
