Phase 4E.4C Cleanup

Run:
cd /workspaces/GPT-VOXEL-3D
python3 cleanup_phase4e4c_malformed_test.py

Verify temporary helper is gone:
grep -n -E "PHASE_4E4C_MALFORMED_PACKET_TEST|TEST MALFORMED x5"   index.vps-test-v2.html

Expected: no output.

Verify core protection still exists:
grep -n -E "PHASE_4E4C_PROTOCOL_VALIDATION|ANTI-PROTOCOL|phase4e4cParseMessage"   vps/game-server.js | head -50

Expected: output should still be present.

This removes only the temporary purple test button/script.
