from pathlib import Path
from datetime import datetime

SERVER = Path("vps/game-server.js")
CLIENT = Path("index.vps-test-v2.html")

if not SERVER.exists():
    raise SystemExit("ERROR: ไม่พบ vps/game-server.js")
if not CLIENT.exists():
    raise SystemExit("ERROR: ไม่พบ index.vps-test-v2.html")

stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
sb = SERVER.with_name(f"game-server.before-phase4e4a.{stamp}.js")
cb = CLIENT.with_name(f"index.vps-test-v2.before-phase4e4a.{stamp}.html")
sb.write_text(SERVER.read_text(encoding="utf-8"), encoding="utf-8")
cb.write_text(CLIENT.read_text(encoding="utf-8"), encoding="utf-8")

server = SERVER.read_text(encoding="utf-8")
client = CLIENT.read_text(encoding="utf-8")

port_marker = "const PORT = Number(process.env.PORT || 8080);"
constants = """const PORT = Number(process.env.PORT || 8080);

// Phase 4E.4A — server-authoritative movement anti-cheat
const MOVE_NORMAL_MAX_SPEED = 9.5;
const MOVE_BUFF_MAX_SPEED = 19.0;
const MOVE_PACKET_DT_MIN = 0.05;
const MOVE_PACKET_DT_MAX = 0.50;
const MOVE_DISTANCE_GRACE = 2.25;
const MOVE_STRIKES_TO_KICK = 8;
"""
if "MOVE_NORMAL_MAX_SPEED" not in server:
    if port_marker not in server:
        raise SystemExit("ERROR: ไม่พบ marker PORT")
    server = server.replace(port_marker, constants, 1)

if "Phase 4E.4A movement validation" not in server:
    start = server.find("if (msg.type === 'move') {")
    if start < 0:
        raise SystemExit("ERROR: ไม่พบ move handler")
    pos = server.find("player.x = x;", start)
    if pos < 0:
        raise SystemExit("ERROR: ไม่พบ player.x = x;")

    guard = """// Phase 4E.4A movement validation
      const moveNow = Date.now();
      const previousX = Number(player.x);
      const previousZ = Number(player.z);
      const rawDt = Number(player.lastAcceptedMoveAt || 0) > 0
        ? (moveNow - Number(player.lastAcceptedMoveAt)) / 1000
        : 0.20;

      const moveDt = Math.min(
        MOVE_PACKET_DT_MAX,
        Math.max(MOVE_PACKET_DT_MIN, Number.isFinite(rawDt) ? rawDt : 0.20)
      );

      const speedBuffActive =
        Number(player.entitlements?.speedExpires || 0) > moveNow;
      const allowedSpeed =
        speedBuffActive ? MOVE_BUFF_MAX_SPEED : MOVE_NORMAL_MAX_SPEED;
      const maxHorizontalDistance =
        allowedSpeed * moveDt + MOVE_DISTANCE_GRACE;

      const horizontalDistance =
        Number.isFinite(previousX) && Number.isFinite(previousZ)
          ? Math.hypot(x - previousX, z - previousZ)
          : 0;

      if (horizontalDistance > maxHorizontalDistance) {
        player.moveViolations = Number(player.moveViolations || 0) + 1;

        send(ws, {
          type: 'movement_correction',
          reason: 'SPEED_OR_TELEPORT',
          x: Number.isFinite(previousX) ? previousX : player.x,
          y: player.y,
          z: Number.isFinite(previousZ) ? previousZ : player.z,
          r: player.r,
          strikes: player.moveViolations,
          serverNow: moveNow
        });

        console.warn('[ANTI-CHEAT] movement rejected', {
          uid: player.uid,
          nickname: player.nickname,
          distance: Number(horizontalDistance.toFixed(3)),
          allowed: Number(maxHorizontalDistance.toFixed(3)),
          dt: Number(moveDt.toFixed(3)),
          strikes: player.moveViolations
        });

        if (player.moveViolations >= MOVE_STRIKES_TO_KICK) {
          try { ws.close(1008, 'Movement validation failed'); } catch (_) {}
        }
        return;
      }

      player.moveViolations = Math.max(
        0,
        Number(player.moveViolations || 0) - 0.25
      );
      player.lastAcceptedMoveAt = moveNow;

      """
    server = server[:pos] + guard + server[pos:]

if "case 'movement_correction':" not in client:
    marker = "case 'zone_change':"
    idx = client.find(marker)
    if idx < 0:
        marker = "case 'box_state':"
        idx = client.find(marker)
    if idx < 0:
        raise SystemExit("ERROR: ไม่พบ switch case สำหรับแทรก movement_correction")

    case_code = """case 'movement_correction': {
          const cx = Number(message.x);
          const cy = Number(message.y);
          const cz = Number(message.z);
          const cr = Number(message.r);

          if (Number.isFinite(cx) && Number.isFinite(cy) && Number.isFinite(cz)) {
            playerPos.set(cx, cy, cz);
            if (Number.isFinite(cr)) playerRotation = cr;

            if (typeof playerVel !== 'undefined' && playerVel) {
              if ('x' in playerVel) playerVel.x = 0;
              if ('z' in playerVel) playerVel.z = 0;
            }

            if (playerGroup) {
              playerGroup.position.copy(playerPos);
              playerGroup.rotation.y = playerRotation;
            }

            secureLastMoveSentAt = 0;
            if (typeof secureRememberStablePosition === 'function') {
              secureRememberStablePosition();
            }
          }

          console.warn(
            'Movement corrected by server:',
            message.reason || 'SPEED_OR_TELEPORT',
            'strikes:',
            message.strikes ?? '?'
          );
          break;
        }

        """
    client = client[:idx] + case_code + client[idx:]

SERVER.write_text(server, encoding="utf-8")
CLIENT.write_text(client, encoding="utf-8")

print("OK: Phase 4E.4A anti-cheat installed")
print("Server backup:", sb)
print("Client backup:", cb)
