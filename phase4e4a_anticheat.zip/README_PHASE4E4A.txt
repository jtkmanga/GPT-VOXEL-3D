Phase 4E.4A — Speed Hack / Teleport Anti-Cheat

Run:
cd /workspaces/GPT-VOXEL-3D
python3 patch_phase4e4a_anticheat.py

Validate:
node --check vps/game-server.js
grep -n -E "Phase 4E.4A|movement_correction|MOVE_NORMAL_MAX_SPEED" vps/game-server.js index.vps-test-v2.html

Restart:
pkill -f "node vps/game-server.js" || true

FIREBASE_PROJECT_ID=lucky-game-6936b ENTITLEMENTS_BASE=https://voxel-run-v2-demo.hjinffv5426.workers.dev nohup node vps/game-server.js > vps/game-server.log 2>&1 &

Check:
curl -s http://127.0.0.1:8080/health ; echo
curl -s http://127.0.0.1:8080/status ; echo

If the patch reports "marker not found", stop and send a screenshot.
