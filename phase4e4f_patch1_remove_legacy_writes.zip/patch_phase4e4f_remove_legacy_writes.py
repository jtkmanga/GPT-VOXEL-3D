from pathlib import Path
from datetime import datetime

TARGET = Path("index.vps-test-v2.html")

if not TARGET.exists():
    raise SystemExit("ERROR: ไม่พบ index.vps-test-v2.html")

s = TARGET.read_text(encoding="utf-8")

MARK = "PHASE_4E4F_REMOVE_LEGACY_FIREBASE_WRITES"
if MARK in s:
    print("INFO: Phase 4E.4F Patch 1 already installed")
    raise SystemExit(0)

stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
backup = TARGET.with_name(
    f"index.vps-test-v2.before-phase4e4f-patch1.{stamp}.html"
)
backup.write_text(s, encoding="utf-8")

def remove_js_call(source, needle, label):
    """
    Remove one JavaScript call expression that starts at `needle`.
    Finds matching ')' while respecting strings/template literals/comments
    well enough for the current HTML source.
    """
    starts = []
    pos = 0
    while True:
        i = source.find(needle, pos)
        if i < 0:
            break
        starts.append(i)
        pos = i + 1

    if len(starts) != 1:
        raise SystemExit(
            f"ERROR: {label}: expected exactly 1 occurrence, found {len(starts)}"
        )

    start = starts[0]
    open_paren = source.find("(", start + len(needle) - 1)
    if open_paren < 0:
        raise SystemExit(f"ERROR: {label}: opening '(' not found")

    depth = 0
    i = open_paren
    quote = None
    escape = False
    line_comment = False
    block_comment = False

    while i < len(source):
        ch = source[i]
        nxt = source[i+1] if i + 1 < len(source) else ""

        if line_comment:
            if ch == "\n":
                line_comment = False
            i += 1
            continue

        if block_comment:
            if ch == "*" and nxt == "/":
                block_comment = False
                i += 2
                continue
            i += 1
            continue

        if quote is not None:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == quote:
                quote = None
            i += 1
            continue

        if ch == "/" and nxt == "/":
            line_comment = True
            i += 2
            continue

        if ch == "/" and nxt == "*":
            block_comment = True
            i += 2
            continue

        if ch in ("'", '"', "`"):
            quote = ch
            i += 1
            continue

        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth == 0:
                end = i + 1
                # consume optional whitespace + semicolon
                j = end
                while j < len(source) and source[j] in " \t":
                    j += 1
                if j < len(source) and source[j] == ";":
                    j += 1

                replacement = (
                    f"/* {MARK}: {label} removed. "
                    f"VPS/WebSocket is authoritative. */"
                )
                return source[:start] + replacement + source[j:], (start, j)
        i += 1

    raise SystemExit(f"ERROR: {label}: matching ')' not found")


# 1) Legacy browser leaderboard write.
leaderboard_needle = (
    "database.ref(`servers/${state.selectedServerId}/leaderboard/${myId}`).set("
)
s, _ = remove_js_call(
    s,
    leaderboard_needle,
    "legacy leaderboard client write"
)

# 2) Legacy browser Lucky Box state write.
s, _ = remove_js_call(
    s,
    "luckyBoxServerRef.set(",
    "legacy Lucky Box client write"
)

# Insert a clear marker near </body> for audit traceability.
marker = "</body>"
if marker not in s:
    raise SystemExit("ERROR: ไม่พบ </body>")

audit_note = f"""
<!-- {MARK}
     Browser-side Firebase writes removed:
     - servers/<server>/leaderboard/<uid>
     - servers/<server>/world/luckyBox
     Score/leaderboard/Lucky Box remain VPS-authoritative.
-->
"""
s = s.replace(marker, audit_note + marker, 1)

TARGET.write_text(s, encoding="utf-8")

print("OK: Phase 4E.4F Patch 1 installed")
print("Backup:", backup)
print("Removed:")
print(" - legacy client leaderboard Firebase write")
print(" - legacy client Lucky Box Firebase write")
print("VPS/WebSocket remains authoritative")
