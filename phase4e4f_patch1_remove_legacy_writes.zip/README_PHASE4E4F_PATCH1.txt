Phase 4E.4F Patch 1 — Remove Legacy Client Firebase Writes

Purpose
-------
Remove the two direct Firebase RTDB writes found in the active client:
1) servers/<server>/leaderboard/<uid>
2) servers/<server>/world/luckyBox

The VPS/WebSocket remains authoritative for score, leaderboard, and Lucky Box.

Install
-------
cd /workspaces/GPT-VOXEL-3D

git fetch origin
git checkout origin/main -- phase4e4f_patch1_remove_legacy_writes.zip
unzip -o phase4e4f_patch1_remove_legacy_writes.zip

python3 patch_phase4e4f_remove_legacy_writes.py

Basic verification
------------------
grep -n -E "PHASE_4E4F_REMOVE_LEGACY_FIREBASE_WRITES|leaderboard/\$\{myId\}.*\.set|luckyBoxServerRef\.set"   index.vps-test-v2.html | head -80

Expected:
- PHASE_4E4F_REMOVE_LEGACY_FIREBASE_WRITES should appear.
- direct leaderboard .set and luckyBoxServerRef.set should NOT appear.

Re-run focused audit
--------------------
python3 audit_phase4e4f_active_client.py | tee phase4e4f-active-client-after-patch1.txt

tail -180 phase4e4f-active-client-after-patch1.txt

Expected:
ACTIVE_CLIENT_WRITE_STATUS: PASS_NO_DIRECT_RTDB_WRITES_FOUND

Runtime regression test
-----------------------
Open the game normally (no test query parameter), then:
- enter Free Server
- walk across zones
- collect 5-10 coins
- confirm score increases
- confirm leaderboard updates from VPS
- if Lucky Box is ready, collect/spin it once
- leave to menu and re-enter

If all work normally, Patch 1 passes.

IMPORTANT
---------
This patch does NOT change Firebase Console Rules yet.
Rules will be locked down after the active client is confirmed to have no
direct RTDB writes.
