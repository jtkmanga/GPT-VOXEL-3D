#!/usr/bin/env python3
from pathlib import Path
import re

ROOT = Path(".")
SKIP_DIRS = {".git", "node_modules", ".wrangler", ".next", "dist", "build"}
TEXT_EXTS = {
    ".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx", ".html", ".htm",
    ".json", ".jsonc", ".txt", ".md", ".py", ".env", ".yaml", ".yml"
}

ACTIVE_CLIENT = Path("index.vps-test-v2.html")
WORKER = Path("worker.js")
VPS = Path("vps/game-server.js")
WRANGLER = Path("wrangler.jsonc")

def read(p):
    try:
        return p.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return ""

def line_hits(text, pattern, flags=0):
    rx = re.compile(pattern, flags)
    return [i for i, line in enumerate(text.splitlines(), 1) if rx.search(line)]

def yn(v):
    return "YES" if v else "NO"

print("=== Phase 4E.4G Payment/VIP Security Audit ===")
print("This script changes NOTHING.")
print("It does NOT print secret values.\n")

missing = [str(p) for p in (ACTIVE_CLIENT, WORKER, VPS, WRANGLER) if not p.exists()]
if missing:
    print("WARNING: missing expected files:", ", ".join(missing))

client = read(ACTIVE_CLIENT)
worker = read(WORKER)
vps = read(VPS)
wrangler = read(WRANGLER)

print("=== ACTIVE CLIENT ===")
checks = [
    ("verify-slip endpoint referenced", r"/verify-slip"),
    ("entitlements endpoint referenced", r"/entitlements"),
    ("Firebase ID token requested", r"getIdToken\s*\("),
    ("legacy grantPurchasedItem function present", r"function\s+grantPurchasedItem\s*\("),
    ("client-side Slip2Go URL present", r"connect\.slip2go\.com"),
    ("client-side Authorization header present", r"Authorization\s*[:=]"),
    ("PromptPay QR target variable present", r"promptpay(Target|Receiver|Number)|promptpay\.io"),
]
for label, pat in checks:
    hits = line_hits(client, pat, re.I)
    print(f"{label}: {yn(bool(hits))}" + (f" lines={hits[:12]}" if hits else ""))

placeholder_hits = line_hits(client, r'["\']0999999999["\']')
print("KNOWN PLACEHOLDER 0999999999 present:", yn(bool(placeholder_hits)),
      (f"lines={placeholder_hits}" if placeholder_hits else ""))
print()

print("=== CLOUDFLARE WORKER ===")
worker_checks = [
    ("server-side item price map", r"\bITEMS\b.*\{|price\s*:"),
    ("verify-slip route", r"/verify-slip"),
    ("entitlements route", r"/entitlements"),
    ("Firebase auth verification", r"verifyFirebase|accounts:lookup|Bearer"),
    ("Slip2Go secret from env", r"env\.SLIP2GO_API_SECRET"),
    ("receiver/account from env", r"env\.(PAYMENT_RECEIVER_ACCOUNT|PROMPTPAY_TARGET)"),
    ("Slip2Go duplicate check", r"checkDuplicate\s*:\s*true"),
    ("receiver verification", r"checkReceiver"),
    ("amount verification", r"checkAmount"),
    ("transaction id/reference used", r"transactionId|transRef|referenceId"),
    ("payment DB/table", r"voxel_payments"),
    ("entitlement DB/table", r"voxel_entitlements"),
    ("VIP cap 100 logic", r"vip1.*100|>=\s*100|VIP.*100"),
    ("internal grant route", r"/_internal/grant-payment"),
]
for label, pat in worker_checks:
    hits = line_hits(worker, pat, re.I)
    print(f"{label}: {yn(bool(hits))}" + (f" lines={hits[:12]}" if hits else ""))

cors_wild = bool(re.search(r'ALLOWED_ORIGIN\s*\|\|\s*["\']\*["\']|allowOrigin\s*=\s*["\']\*["\']', worker))
print("CORS can fall back to wildcard '*':", yn(cors_wild))
print()

print("=== VPS / VIP ACCESS ===")
vps_checks = [
    ("entitlements service used", r"ENTITLEMENTS_BASE|/entitlements"),
    ("VIP access checked server-side", r"vip1|vip.*entitlement|entitlement.*vip"),
    ("server maxPlayers 100 appears", r"maxPlayers\s*[:=]\s*100|VIP Server 1.*100"),
    ("Firebase token auth exists", r"Firebase|idToken|auth_refresh|verify"),
]
for label, pat in vps_checks:
    hits = line_hits(vps, pat, re.I)
    print(f"{label}: {yn(bool(hits))}" + (f" lines={hits[:12]}" if hits else ""))
print()

print("=== WRANGLER CONFIG ===")
env_names = sorted(set(re.findall(r'\b([A-Z][A-Z0-9_]{3,})\b', wrangler)))
safe_names = [n for n in env_names if any(k in n for k in (
    "FIREBASE", "SLIP", "PAYMENT", "PROMPTPAY", "ALLOWED_ORIGIN", "ROOM"
))]
print("Relevant variable/binding names only:", safe_names)

secret_literal_patterns = [
    ("Slip2Go literal secret assignment", r'SLIP2GO_API_SECRET\s*["\']?\s*[:=]\s*["\'][^"\']{8,}'),
    ("Private key", r"BEGIN (?:RSA )?PRIVATE KEY"),
    ("Ably Root key", r"\bRoot\s*=\s*[A-Za-z0-9_.:-]{12,}"),
    ("ABLY_API_KEY literal", r'ABLY_API_KEY\s*[:=]\s*["\'][^"\']{8,}'),
]

print("\n=== REPOSITORY SECRET-LEAK SCAN ===")
print("Scanning source/backups too, because old backup files can still leak secrets.")
findings = []
for p in ROOT.rglob("*"):
    if not p.is_file():
        continue
    if any(part in SKIP_DIRS for part in p.parts):
        continue
    if p.suffix.lower() not in TEXT_EXTS and p.name not in {".env", ".env.local"}:
        continue
    text = read(p)
    if not text:
        continue
    for label, pat in secret_literal_patterns:
        if re.search(pat, text, re.I):
            findings.append((str(p), label))

if findings:
    print(f"RISK: {len(findings)} file/pattern findings")
    for path, label in findings[:80]:
        print(f" - {path}: {label}")
    if len(findings) > 80:
        print(f" ... plus {len(findings)-80} more")
else:
    print("No obvious literal-secret pattern found in scanned text files.")

print("\n=== CLASSIFICATION ===")
risks = []
if not re.search(r"/verify-slip", worker):
    risks.append("Worker verify-slip route not found")
if not re.search(r"checkDuplicate\s*:\s*true", worker):
    risks.append("Slip duplicate verification not found")
if not re.search(r"checkReceiver", worker):
    risks.append("Receiver verification not found")
if not re.search(r"checkAmount", worker):
    risks.append("Amount verification not found")
if not re.search(r"voxel_payments", worker):
    risks.append("Server payment ledger not found")
if placeholder_hits:
    risks.append("Client still contains PromptPay placeholder 0999999999")
if re.search(r"connect\.slip2go\.com", client, re.I):
    risks.append("Active client appears to call Slip2Go directly")
if findings:
    risks.append("Repository contains possible literal secret(s)")
if cors_wild:
    risks.append("Worker CORS may allow wildcard origin")

if risks:
    print("REVIEW_REQUIRED")
    for r in risks:
        print(" -", r)
else:
    print("PASS_BASELINE")

print("\n=== NEXT OUTPUT TO SEND ===")
print("Send screenshots/text of this audit output ONLY.")
print("Do NOT send any secret values, API keys, PromptPay account numbers, or tokens.")
