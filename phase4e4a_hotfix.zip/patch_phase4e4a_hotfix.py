from pathlib import Path
from datetime import datetime

p = Path("vps/game-server.js")
if not p.exists():
    raise SystemExit("ERROR: ไม่พบ vps/game-server.js")

s = p.read_text(encoding="utf-8")
stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
backup = p.with_name(f"game-server.before-phase4e4a-hotfix.{stamp}.js")
backup.write_text(s, encoding="utf-8")

replacements = {
    "const MOVE_NORMAL_MAX_SPEED = 9.5;": "const MOVE_NORMAL_MAX_SPEED = 28.0;",
    "const MOVE_BUFF_MAX_SPEED = 19.0;": "const MOVE_BUFF_MAX_SPEED = 56.0;",
    "const MOVE_DISTANCE_GRACE = 2.25;": "const MOVE_DISTANCE_GRACE = 2.0;",
    "Number(player.moveViolations || 0) - 0.25": "Number(player.moveViolations || 0) - 1.0",
}

for old, new in replacements.items():
    if old not in s:
        raise SystemExit(f"ERROR: ไม่พบ marker ที่ต้องแก้: {old}")
    s = s.replace(old, new, 1)

p.write_text(s, encoding="utf-8")

print("OK: Phase 4E.4A Hotfix installed")
print("Backup:", backup)
print("MOVE_NORMAL_MAX_SPEED = 28.0")
print("MOVE_BUFF_MAX_SPEED = 56.0")
print("MOVE_DISTANCE_GRACE = 2.0")
print("Valid movement heals 1 strike")
