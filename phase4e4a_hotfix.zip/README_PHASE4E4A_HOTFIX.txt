Phase 4E.4A Hotfix — mobile movement calibration

Why:
The log showed normal movement around 20–23 world-units/sec, while the
anti-cheat allowed only 9.5. That caused false positives and eventually
WebSocket disconnects.

Run:
cd /workspaces/GPT-VOXEL-3D
python3 patch_phase4e4a_hotfix.py

Validate:
node --check vps/game-server.js
grep -n -E "MOVE_NORMAL_MAX_SPEED|MOVE_BUFF_MAX_SPEED|MOVE_DISTANCE_GRACE|moveViolations" vps/game-server.js | head -30

Restart with a fresh log:
pkill -f "node vps/game-server.js" || true
rm -f vps/game-server.log

FIREBASE_PROJECT_ID=lucky-game-6936b ENTITLEMENTS_BASE=https://voxel-run-v2-demo.hjinffv5426.workers.dev nohup node vps/game-server.js > vps/game-server.log 2>&1 &

Check:
curl -s http://127.0.0.1:8080/health ; echo
curl -s http://127.0.0.1:8080/status ; echo

Then test normal movement for 30–60 seconds, including several Zone crossings.
Afterward:
grep -n -A 8 "\[ANTI-CHEAT\] movement rejected" vps/game-server.log | tail -80
