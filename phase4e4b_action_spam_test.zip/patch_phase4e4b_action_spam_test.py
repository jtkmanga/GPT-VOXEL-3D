from pathlib import Path
from datetime import datetime

p = Path("index.vps-test-v2.html")
if not p.exists():
    raise SystemExit("ERROR: ไม่พบ index.vps-test-v2.html")

s = p.read_text(encoding="utf-8")

if "PHASE_4E4B_ACTION_SPAM_TEST" in s:
    print("INFO: Phase 4E.4B test helper already installed")
    raise SystemExit(0)

stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
backup = p.with_name(f"index.vps-test-v2.before-phase4e4b-test.{stamp}.html")
backup.write_text(s, encoding="utf-8")

marker = "</body>"
if marker not in s:
    raise SystemExit("ERROR: ไม่พบ </body>")

snippet = r'''
<!-- PHASE_4E4B_ACTION_SPAM_TEST
     Temporary controlled action-spam test.
     Visible only with ?antispam_test=1.
     Remove before production. -->
<script>
(() => {
  const params = new URLSearchParams(location.search);
  if (params.get('antispam_test') !== '1') return;

  window.addEventListener('load', () => {
    const wrap = document.createElement('div');
    wrap.style.cssText =
      'position:fixed;right:12px;bottom:92px;z-index:100000;' +
      'display:flex;flex-direction:column;gap:7px;align-items:flex-end;';

    const status = document.createElement('div');
    status.textContent = 'Anti-Spam test ready';
    status.style.cssText =
      'background:#111;color:#fff;padding:7px 10px;border-radius:8px;' +
      'font:12px sans-serif;max-width:250px;';

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.textContent = 'TEST MOVE SPAM x55';
    btn.style.cssText =
      'background:#b45309;color:#fff;border:2px solid #fff;' +
      'padding:10px 12px;border-radius:10px;font-weight:700;';

    btn.addEventListener('click', () => {
      try {
        if (
          !secureGameSocket ||
          secureGameSocket.readyState !== WebSocket.OPEN ||
          !secureGameReady
        ) {
          status.textContent = 'Game Server ยังไม่พร้อม';
          return;
        }

        const x = Math.round(Number(playerPos.x) * 100) / 100;
        const y = Math.round(Number(playerPos.y) * 100) / 100;
        const z = Math.round(Number(playerPos.z) * 100) / 100;
        const r = Math.round((Number(playerRotation) || 0) * 1000) / 1000;

        // Same position each time: action-rate test, not a speed-hack test.
        for (let i = 0; i < 55; i++) {
          secureGameSocket.send(JSON.stringify({
            type: 'move',
            x, y, z, r
          }));
        }

        status.textContent =
          'ส่ง move spam 55 packet แล้ว — VPS ควร rate-limit และตัดการเชื่อมต่อ';
        console.warn('[TEST] Phase 4E.4B sent 55 move packets');
      } catch (err) {
        status.textContent = 'TEST ERROR: ' + (err?.message || err);
        console.error(err);
      }
    });

    wrap.append(status, btn);
    document.body.appendChild(wrap);
  });
})();
</script>
'''

s = s.replace(marker, snippet + "\n" + marker, 1)
p.write_text(s, encoding="utf-8")

print("OK: Phase 4E.4B controlled action-spam test installed")
print("Backup:", backup)
print("Open with ?antispam_test=1")
print("Button: TEST MOVE SPAM x55")
