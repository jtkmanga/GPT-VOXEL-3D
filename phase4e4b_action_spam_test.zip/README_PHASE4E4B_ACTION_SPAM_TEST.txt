Phase 4E.4B — Controlled Action Spam Test

Install:
cd /workspaces/GPT-VOXEL-3D
python3 patch_phase4e4b_action_spam_test.py

Verify:
grep -n "PHASE_4E4B_ACTION_SPAM_TEST" index.vps-test-v2.html

Open the game:
https://<PORT-3000-HOST>/index.vps-test-v2.html?antispam_test=1

Test:
1. Enter Free Server normally.
2. Stand still ~3 seconds.
3. Tap TEST MOVE SPAM x55 exactly once.
4. Expected:
   - no teleport / no strange movement;
   - VPS rate-limits the move action after 30 packets in one second;
   - repeated rejected packets reach the kick threshold;
   - WebSocket may disconnect. That is expected for this attack test.

Check the log:
grep -n -A 12 "\[ANTI-SPAM\]" vps/game-server.log | tail -100

Expected:
- [ANTI-SPAM] action rate limited
- action: 'move'
- count around 31
- max: 30
- [ANTI-SPAM] repeated action spam - disconnecting
- rejected around 20

This helper is temporary. Remove it before production.
